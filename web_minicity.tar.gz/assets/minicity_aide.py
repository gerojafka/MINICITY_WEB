"""In-game manual shared by the desktop and browser editions."""
import pygame
import minicity_lang as LNG


def _brut(font):
    """Police sans traduction : le manuel est deja ecrit dans la langue voulue."""
    return getattr(font,'f',font)


GUIDE = [
    ("Bien commencer", [
        "Une nouvelle ville commence avec 97 500 de budget. REGLAGES choisit la taille de la prochaine carte ; NOUVEAU demande confirmation avant de remplacer la ville.",
        "Commencez par quelques routes, une source d'electricite et des logements. Ajoutez commerces, emplois et services en surveillant le budget et le bonheur.",
        "Les batiments alimentes accueillent davantage d'habitants. Les routes et les autres elements conducteurs prolongent le reseau electrique.",
        "La molette ou - dezoome jusqu'a voir toute la carte d'un coup, quelle que soit sa taille ; V y revient directement. A ce zoom, feux et panneaux sont masques.",
        "BILAN detaille recettes et charges. Le budget evolue chaque jour : les services coutent de l'entretien, les habitants et entreprises apportent des revenus.",
        "PAUSE suspend la simulation sans interdire la construction. Sauvegardez votre ville avant d'en ouvrir ou d'en creer une autre.",
    ]),
    ("Construire et amenager", [
        "Choisissez un element dans Terrains, Voies, Maisons ou Services. L'apercu indique son emplacement et son cout ; un emplacement bloque ne peut pas etre construit.",
        "Pour un batiment, visez une case libre, faites tourner l'apercu avec R sur PC ou ROT sur iPad, puis validez sa position. Un glisser-relacher pose plusieurs exemplaires alignes, comme le trottoir. Gardez assez de place pour toute leur emprise.",
        "Rue commercante (menu Economie) et rue residentielle (menu Maisons) : glissez le long d'un trottoir pour poser une suite de batiments tous differents (immeubles, commerces, cafes, magasins, lofts ; ou maisons, cottages, pavillons, villas). Les facades se tournent seules vers la rue. R sur PC, ou ROT sur iPad, tire un autre melange avant de poser.",
        "Dans Terrains, glissez sur un rectangle pour poser herbe, foret, eau, champ ou sable sur une zone (le sable est sans jointure visible entre les carreaux). Les arbres de foret et les champs sont regroupes par blocs.",
        "L'outil curseur selectionne une zone en glissant. Suppr sur PC ou EFF sur iPad efface la selection. Sans selection, X ou EFF active la gomme.",
        "Ctrl+Z sur PC, ou ANN sur iPad, annule jusqu'a 25 operations. Ctrl+Y retablit. Ctrl+C puis Ctrl+V copie et colle une selection sur PC.",
    ]),
    ("Routes, rails et ponts", [
        "Les rues, routes, autoroutes, rails et TGV utilisent le meme systeme : deux clics, depart puis arrivee, ou un glisser-relacher.",
        "Virages et raccordements aux extremites sont automatiques. L'apercu montre le trace, le prix et les obstacles.",
        "Aucun troncon incomplet n'est construit si la construction est impossible. R change le coude propose.",
        "Pendant la construction d'une voie, un carre vert ou rouge indique l'emprise reelle : 1 x 1 pour Trottoir, 2 x 2 pour Route, 3 x 3 pour Rail et TGV, 4 x 4 pour Rue et Autoroute. Deux lignes fines suivant les axes du quadrillage isometrique passent par son centre. Pour Rue, le carre devient rouge si le trace, ses trottoirs ou son raccord sont impossibles.",
        "Clic droit ou Echap termine le trace ; sur iPad, utilisez FIN. Le trace reste sur la grille isometrique.",
        "Deux routes forment un carrefour. Route et rail forment un passage a niveau. Les croisements avec autoroute ou TGV sont deniveles ; le pont doit ressortir de l'autre cote. L'outil Pont routier se pose aussi sur un passage a niveau : la route passe alors au-dessus de la voie ferree, sans barriere ; cliquer sur le passage a niveau, la demolition d'une de ses cases retire tout l'ouvrage. Une Rue qui croise une voie ferree ou une autoroute (ou l'inverse) cree automatiquement son pont ; il n'y a pas de trottoir sur les rails.",
        "Fermez un circuit ferre, meme en plusieurs troncons, pour y faire circuler des trains dans les deux sens. Leur nombre pair depend de la longueur du circuit. Un reseau equipe d'aiguillages recoit des trains selon sa longueur, repartis entre les sens de circulation.",
        "Dans Voies, les entrees et sorties d'autoroute se posent d'abord sur une autoroute. Choisissez une bretelle perpendiculaire ou parallele, tournez-la avec R ou ROT, puis tracez une route depuis son raccord vert.",
    ]),
    ("Rue, route et rond-point", [
        "Rue utilise le meme constructeur que Route : deux clics ou glisser-relacher, virages et raccordements automatiques. R ou ROT change le coude. Elle construit deux files de circulation avec un trottoir de chaque cote, soit quatre cases de large. L'apercu montre tout le trace et son prix ; un obstacle empeche toute la pose.",
        "Les feux sont reserves aux rues : Rue x Rue et Rue x Route creent des feux aux carrefours. Un croisement Route x Route reste sans feu. Une Rue peut se raccorder directement a une Route.",
        "Une Rue ne peut ni toucher ni traverser une autoroute. Pour rejoindre une autoroute, prolongez d'abord la Rue avec une Route, puis utilisez une bretelle d'entree ou de sortie.",
        "Route reste la voie polyvalente : elle accepte les raccordements aux rues, aux bretelles d'autoroute et aux quatre acces d'un rond-point.",
        "Rond-point pose un anneau aux angles arrondis, avec un ilot central fleuri et quatre acces de deux files. Laissez une zone libre de 10 x 10 cases, posez le rond-point, puis partez de l'un de ses acces avec l'outil Route. Les anciens ronds-points gardent leur taille.",
        "Le rond-point s'adapte tout seul au carrefour : pose sur un croisement en T, il ne garde que trois acces et son ilot recoit une fontaine a jet d'eau ; sur un croisement a quatre branches, une route droite ou un terrain libre, il a quatre acces et la statue au centre.",
        "Les voitures circulent dans un seul sens autour de l'ilot et choisissent progressivement l'une des sorties. La gomme retire le rond-point complet lorsqu'une de ses cases est effacee.",
    ]),
    ("Embranchements autoroutiers", [
        "Construisez d'abord une portion droite d'autoroute. Dans Voies, Sortie autoroute et Entree autoroute rejoignent une route perpendiculaire ; Sortie parallele et Entree parallele rejoignent une route qui longe l'autoroute.",
        "Placez l'apercu sur une voie de l'autoroute, puis appuyez sur R / ROT jusqu'a ce que la zone bleue recouvre l'autoroute. La rampe et son raccord routier sont verts. Cliquez ou touchez pour les construire.",
        "Choisissez ensuite l'outil Route. Cliquez sur le raccord vert situe a l'extremite de la rampe, puis cliquez a l'endroit ou la route doit aller. La route se raccorde automatiquement a la bretelle.",
        "Le raccord entre la bretelle et la route reste sans feu : les vehicules s'y inserent directement.",
        "Les fleches rouges indiquent le sens de circulation de la bretelle : vers l'autoroute pour entrer, vers la route pour sortir. Pour les entrees comme pour les sorties, une voiture sur dix passant dans la file qui dessert la rampe est selectionnee. Elle conserve son choix et attend si la rampe est occupee.",
        "Les pieces paralleles demandent une emprise de 11 x 11 cases au lieu de 9 x 9.",
    ]),
    ("Aiguillages ferroviaires", [
        "Construisez d'abord une voie ferree droite, Rail ou TGV, d'au moins 14 cases. Dans Voies, choisissez l'un des quatre aiguillages : Aig. D bas, Aig. G haut, Aig. G bas ou Aig. D haut. D ou G indique le cote de la branche a l'ecran ; bas ou haut, la direction qu'elle prend.",
        "Placez l'apercu sur la voie : la zone bleue recouvre la voie existante, la zone verte la branche a construire, le rouge signale un obstacle. Cliquez ou touchez pour poser la piece.",
        "La piece pose deux courbes paralleles et un court troncon de voie double. Choisissez ensuite Rail ou TGV, cliquez sur l'extremite de ce troncon puis a l'endroit voulu : la branche se prolonge automatiquement, comme une route depuis une bretelle d'autoroute.",
        "Les trains qui roulent dans le sens de la branche peuvent bifurquer ; ceux qui en reviennent rejoignent l'autre voie de la ligne. Une branche en impasse sert de terminus : le train y fait demi-tour. Pour desservir une branche dans les deux sens, posez un second aiguillage oriente dans l'autre direction.",
        "Avec le Curseur, cliquez sur la pastille ronde placee a cote de l'aiguille pour changer de mode : alterne (un train sur deux bifurque), tout droit ou bifurcation. Fleche jaune : la branche ; fleche blanche : la voie directe ; les deux : alterne.",
        "Un seul convoi a la fois traverse le croisement de l'aiguillage ; les autres attendent sans faire demi-tour. La gomme sur les courbes retire la piece et conserve le troncon de branche.",
    ]),
    ("Aeroport", [
        "Dans Services, Aeroport occupe 20 x 12 cases (2 500 S). Laissez un terrain libre et tournez la piece avec R ou ROT avant de la poser. Il emploie 30 personnes, ameliore le bonheur et rapporte des redevances chaque jour.",
        "Trois postes de stationnement fonctionnent en decale. Chaque avion atterrit, roule jusqu'a son poste, puis l'escalier mobile vient se placer a la porte avant : les passagers descendent et rejoignent le terminal.",
        "Pendant l'escale, le train de bagages fait deux passages a la soute, puis de nouveaux passagers embarquent. Le tracteur de repoussage vient alors se placer devant le nez et pousse l'avion en arriere jusqu'a la voie de circulation.",
        "L'avion roule ensuite jusqu'au seuil de piste et decolle au-dessus de la ville. Les compagnies changent d'une rotation a l'autre.",
        "La nuit, la piste, les vitrages, la balise de la tour et les feux de navigation des avions s'allument. La manche a air et le radar tournent en permanence. Le tableau de bord indique le nombre d'arrivees par jour.",
    ]),
    ("Trains et gares", [
        "Six modeles de trains circulent, chacun a l'echelle des voitures : Intercites (locomotive et voitures Corail), TER regional, train a vapeur (locomotive, tender et voitures en bois), train de marchandises (diesel, conteneurs, citernes, tombereaux), TGV et TGV Duplex a deux niveaux. Chaque nouveau convoi en tire un au hasard.",
        "Les voitures suivent la voie une par une dans les courbes et les aiguillages. La vapeur et le fret roulent moins vite ; un convoi rapide attend le train lent qui le precede. La nuit, phares, feux rouges de queue et fenetres s'allument.",
        "Posez une Gare, une Grande gare ou une Gare TGV a trois cases au plus d'une voie droite : le quai et sa marquise se tournent automatiquement vers elle. Gare et Grande gare desservent les rails ; la Gare TGV (4 x 10, 900 S) les voies TGV.",
        "Chaque train de voyageurs s'arrete environ neuf secondes en gare, sur chacune des voies longees, la tete en bout de quai. Les voyageurs descendent et rejoignent le hall, ceux qui attendaient montent, puis le quai se remplit de nouveau. Les trains de marchandises passent sans s'arreter.",
        "Quand un train doit repartir en sens inverse sur la meme voie, le conducteur change de cabine : la rame repart sans traverser ses propres voitures. Le tableau de bord indique les gares desservies et les trains a quai.",
    ]),
    ("Electricite et services", [
        "Chaque producteur alimente son reseau, c'est-a-dire tout ce qu'il touche par les routes, rails et batiments voisins : centrale 500 MW, centrale nucleaire 2 000 MW, parc solaire 300 MW, eolienne 60 MW, moulin 30 MW. Plusieurs reseaux separes ne se partagent pas leur production.",
        "Eolienne : glissez une zone avec la souris, comme pour l'herbe, pour poser tout un champ d'eoliennes (une toutes les deux cases). Un simple clic pose une seule eolienne.",
        "Chaque batiment consomme : maison 0,5 MW, immeuble 2 MW, commerce 2 MW, usine 12 MW, Auchan 15 MW, aeroport 40 MW... Si un reseau manque de puissance, les batiments les plus eloignes des sources sont coupes : un eclair clignote au-dessus d'eux et leurs habitants partent peu a peu.",
        "Police, pompiers, commerces, hopital, gares et metro servent les logements situes dans leur rayon et dans la limite de leur capacite : commissariat 14 cases et 400 habitants, caserne 16 cases et 500 habitants, cafe 7 cases, commerce 10, magasin 12, Auchan, hopital, grande gare et gare TGV 100 cases (1 200, 5 000 et 900 habitants).",
        "Les logements proches sont servis en premier et le service s'affaiblit avec la distance : vingt casernes collees ne protegent pas un quartier eloigne. Repartissez les equipements dans la ville. Pendant la pose, un cercle jaune montre la zone servie.",
        "Des commerces trop serres se partagent les memes clients : chacun rapporte un fixe plus une part par client servi. Le bonheur depend de la part des habitants reellement servis ; les grands equipements (stade, zoo, parc...) ont un effet qui s'attenue quand on les multiplie.",
        "BILAN affiche la production et le besoin en MW, la part des batiments alimentes et la couverture de chaque service.",
    ]),
    ("Supermarche Auchan", [
        "Deplacer un objet deja pose : avec le Curseur, cliquez sur un batiment pour le selectionner (un cadre apparait ; un rectangle selectionne plusieurs objets), puis cliquez sur le bouton Deplacer, appuyez sur Entree, ou glissez-deposez le batiment selectionne. Un apercu vert montre l'emprise ; rouge si l'emplacement est occupe. Echap ou clic droit annule, Ctrl+Z revient en arriere. Les voies et les terrains ne se deplacent pas, et le deplacement est gratuit.",
        "Portee des grandes structures : au moins 100 cases. Stade, parc d'attractions, grande roue et zoo agrandissent le bien-etre de tous les logements situes dans ce rayon. La centrale nucleaire et la centrale classique alimentent aussi, sans cable, les batiments proches (le plus proche d'abord, dans la limite de leur production) ; un cercle jaune montre la portee pendant la pose.",
        "Dans Economie, Auchan occupe 14 x 12 cases (3 000 S). Tournez-le avec R ou ROT avant de le poser, parking du cote de la rue. Il emploie 60 personnes, sert les habitants dans un rayon de 100 cases et rapporte selon le nombre de clients.",
        "L'hypermarche a son enseigne a l'oiseau sur la tour d'entree, un sas vitre a portes automatiques, un Drive, des affiches, un quai de livraison et des groupes de ventilation sur le toit. Le parking compte quatre rangees, des places PMR, des ilots plantes, un abri a chariots, des lampadaires et un totem.",
        "Les voitures entrent par la voie de droite, cherchent une place, se garent ; le client marche jusqu'aux portes, qui s'ouvrent a son approche, fait ses courses puis revient avec son chariot. La voiture recule et repart par la voie de gauche. Le parking se remplit en fin de matinee et en fin d'apres-midi, et se vide a la fermeture (8h30 - 21h30).",
        "Un camion de livraison remonte jusqu'au quai, y recule, decharge puis repart. La nuit, l'enseigne, le totem, la vitrine et les phares des voitures s'allument.",
    ]),
    ("Quartier d'affaires", [
        "Dans Economie, le quartier d'affaires occupe 14 x 12 cases, comme Auchan (5 000 S). Tournez-le avec R ou ROT avant de le poser : le parvis et ses deux marches s'ouvrent du cote de la rue. Il emploie 250 personnes, rapporte 40 S par jour (loyers et taxes des bureaux) et consomme 25 MW.",
        "Sept tours entourent une place pietonne : Altair, en verre bleu, avec sa couronne de lames ; Vega, aux ailettes blanches, avec son heliport ; Orion, la tour ronde ; Lyra, en pierre, avec son jardin sur le toit ; Deneb, a resille diagonale ; Cassiopee, en brique, et Polaris, blanche, avec son antenne. Chaque tour a son hall vitre, un auvent et son nom au-dessus de l'entree.",
        "Au centre, un bassin a jets d'eau entoure de bancs ; autour, des arbres en bacs, des lampadaires, une sculpture rouge, des drapeaux, le totem du quartier et la terrasse d'un cafe. Les employes circulent entre les halls et la rue, surtout le matin, a midi et en fin de journee.",
        "La nuit, une partie des bureaux reste allumee, les halls, le bassin et la couronne d'Altair s'eclairent, et les feux rouges de balisage clignotent au sommet des tours.",
        "Sur la facade avant d'Altair, un ascenseur panoramique en verre monte du rez-de-chaussee a la terrasse du 25e etage en s'arretant aux paliers intermediaires ; on voit sa cabine, ses passagers et son cable dans la gaine vitree. La nuit, la cabine reste eclairee.",
        "Un helicoptere stationne sur l'heliport de Vega. Toutes les deux minutes et demie environ, son rotor se lance, il decolle a la verticale, fait le tour du quartier puis revient se poser. En vol, ses feux de position et son phare d'atterrissage s'allument la nuit.",
    ]),
    ("Zoo", [
        "Dans Services, Zoo occupe 16 x 14 cases (2 200 S). Tournez-le avec R ou ROT avant de le poser. Il emploie 25 personnes, ameliore nettement le bonheur et rapporte une billetterie quotidienne.",
        "Six enclos bordent les allees : girafes et zebres dans la savane, elephants et leur bassin, rhinoceros, lions et lionnes autour du rocher, pandas dans les bambous et panthere noire sur son arbre. Flamants roses et singes animent l'entree.",
        "Les animaux se deplacent, broutent, se couchent ou mangent. Les familles entrent par le portail, font le tour des allees et s'arretent devant les enclos ; de petits groupes s'attroupent aux meilleurs points de vue. Certains enfants tiennent un ballon.",
        "La nuit, les lampadaires des allees et l'enseigne de l'entree s'allument. Le tableau de bord indique le nombre de visiteurs par jour.",
    ]),
    ("Monuments et services", [
        "Dans Services : Hopital (12 x 10, 2 500 S), Mairie (6 x 6, 900 S), Cathedrale Notre-Dame (10 x 18, 4 000 S), Grande mosquee (10 x 10, 1 600 S), Synagogue (8 x 8, 1 200 S) et Port (24 x 20, 3 500 S). Tournez-les avec R ou ROT avant de les poser.",
        "Hopital : tour d'hospitalisation avec heliport sur le toit, hall d'accueil vitre, urgences et leur auvent, garage des ambulances, jardin therapeutique et parking. Les ambulances sortent gyrophare allume, reviennent sous l'auvent ou le brancard est conduit aux urgences ; l'helicoptere sanitaire se pose et repart ; patients en fauteuil au jardin. 40 emplois.",
        "Mairie : drapeaux qui flottent, fontaine, horloge, et un mariage qui sort regulierement sur le perron sous une pluie de riz.",
        "Grande mosquee : minaret carre a lanterneau, toits de tuiles vertes, coupole, patio a arcades avec jardin, canaux et fontaine, porte monumentale et salon de the sous les arbres. Appel a la priere au minaret, ablutions, puis les fideles entrent dans la salle. Synagogue : facade a trois arcs, rosace a etoile de David, Tables de la Loi, deux tourelles a coupoles, maison communautaire, cour fermee par une grille avec gardien, menorah allumee la nuit ; les fideles se rassemblent sur le parvis avant l'office.",
    ]),
    ("Port et Notre-Dame", [
        "Port : la mer occupe les deux cotes arriere, en L. Un porte-conteneurs entre par le large avec ses remorqueurs, accoste, est decharge puis recharge par trois portiques (fleches abaissees a quai, relevees sinon) et des camions de terminal, puis repart en marche arriere vers le large. Parc a conteneurs et son portique sur pneus, entrepot, silos et portail du terminal.",
        "Gare maritime : le ferry accoste, debarque ses voitures, deploie sa passerelle passagers et embarque la file d'attente avant de repartir. Marina avec pontons et voiliers, bateau de peche suivi des mouettes, capitainerie, restaurants et terrasses, phare sur la digue. Pas de route : le port et la cathedrale ne se raccordent pas au reseau routier. La nuit : mats d'eclairage, feux des grues et des navires, faisceau du phare. 60 emplois, 25 S par jour.",
        "Cathedrale Notre-Dame : grand parvis avec le point zero, la statue de Charlemagne et l'entree de la crypte ; facade a trois portails, galerie des rois, grande rose et deux tours ; nef a arcs-boutants, transept et ses roses, fleche entouree des apotres, chevet et ses arcs-boutants rayonnants. Square Jean-XXIII et fontaine de la Vierge a l'est, rue du Cloitre au nord. File de visiteurs, groupe guide, photographes, pigeons qui s'envolent, petit train touristique qui fait le tour du parvis ; les cloches sonnent chaque minute et la facade est illuminee la nuit.",
        "Un port ou une cathedrale poses avant la version 4.6 gardent leur ancienne taille et leur ancien dessin ; raser puis reposer le batiment donne la nouvelle version.",
    ]),
    ("Metro aerien", [
        "Dans Voies, choisissez Metro aerien puis glissez du point de depart au point d'arrivee : la ligne est droite ou en L avec un coude arrondi ; R choisit le coude. L'apercu montre le trace, les stations et le prix (40 S par case et 300 S par station).",
        "Partez du bout d'une ligne (a une case pres, cercle jaune) pour la prolonger. Si le trace relie les bouts de deux lignes, elles n'en font plus qu'une : les rames parcourent toute la ligne.",
        "Le viaduc passe au-dessus des routes, rails et TGV ; il ne peut pas traverser un batiment. Une ligne fait au moins 10 cases. Les piles ne se posent que sur des cases libres.",
        "Les stations sont reparties automatiquement. Les rames de trois voitures font la navette sur deux voies, marquent l'arret en station et s'eclairent la nuit. Plus la ligne est longue, plus elle compte de rames.",
        "La gomme sur une case du viaduc retire toute la ligne. Ctrl+Z / ANN annule. Chaque station rapporte des billets et le metro ameliore le bonheur.",
    ]),
    ("Densites et vitesses", [
        "Les vehicules apparaissent automatiquement. REGLAGES regle trois densites : voitures (avec bus et camions, selon les reseaux routiers et le nombre d'habitants), trains et TGV.",
        "Densite des trains : 0 % supprime les trains, 200 % double le nombre de rames. Densite des TGV : 100 % met un TGV sur chaque voie, 200 % en met deux sur les grandes boucles, places a mi-boucle l'un de l'autre : jamais un TGV juste derriere un autre. 0 % les retire.",
        "Vitesse voitures et trains agit sur les vehicules deja presents. Le TGV roule 2,5 fois plus vite que le train, a reglage identique et lorsque la voie est libre.",
    ]),
    ("Circulation, jour et nuit", [
        "Au bout d'une route a deux files ou d'une voie ferree double coupee, une boucle de retournement est dessinee sur l'herbe libre : voitures et trains y font demi-tour en suivant la courbe. Si la place manque, ils tournent dans les cases d'extremite.",
        "Sans trottoirs, un carrefour n'a pas de feux : la route la plus longue est prioritaire, l'autre porte un cedez-le-passage.",
        "Sur autoroute, les vehicules routiers roulent 1,6 fois plus vite que sur route. Voitures, bus et camions ont la meme vitesse cible sur une meme voie.",
        "Feux rouges, passages a niveau, pietons et vehicules precedents peuvent imposer un ralentissement ou un arret. Le reglage de vitesse ne supprime pas ces priorites.",
        "A vitesse du temps 1x, une heure de jeu dure une minute reelle : 12 heures durent 12 minutes. Ce reglage, distinct de la vitesse des vehicules, monte jusqu'a 100x.",
        "Cochez Jour permanent dans REGLAGES pour conserver l'eclairage de jour. L'horloge et l'economie continuent. Decochez pour retrouver le cycle jour/nuit a l'heure courante.",
        "Les parametres sont enregistres automatiquement. Le mode jour permanent est aussi conserve dans les sauvegardes de ville.",
    ]),
    ("Commandes PC et iPad", [
        "Sur PC : molette pour zoomer ; fleches ou ZQSD pour deplacer la carte. Avec le Curseur, cliquez dans la mini-carte pour viser un quartier. Maintenez les deux boutons de souris pour deplacer la grande carte, quel que soit l'outil actif. V donne la vue d'ensemble, H centre la ville.",
        "Sur iPad : deplacez la carte avec deux doigts et pincez pour zoomer. Un doigt sert a viser, selectionner ou tracer. Utilisez les boutons du clavier virtuel pour les commandes.",
        "R / ROT : tourner. COUDE : autre coude de voie. FIN : finir le trace. CURS : selection. EFF : effacer la selection ou activer la gomme. ANN : annuler.",
        "Espace / PAUSE : suspendre ou reprendre. F11 / PLEIN : plein ecran. AIDE ou F1 ouvre ce manuel. Les fleches en bas changent de page ; X ou Echap ferme l'aide.",
        "Sur PC, l'image passe par la carte graphique (NVIDIA si presente) : lancez le jeu avec LANCER_MINICITY.bat pour que Windows lui attribue le processeur graphique haute performance. Le titre de la fenetre indique alors carte graphique.",
        "Raccourcis de construction sur PC : 2 route, O autoroute, 3 rail, K TGV, T trottoir, 4 arbre, 5 maison. Les menus donnent acces a tous les elements sans clavier.",
        "Le trottoir se pose en surface comme l'herbe : glissez de l'angle d'une zone a l'angle oppose pour remplir tout le rectangle (jaune = deja pose, rouge = case occupee). Le cout est de 5 S par case.",
    ]),
    ("Sauvegarder et retrouver une ville", [
        "SAUVER ou Ctrl+S enregistre la ville. F5 propose un autre nom ; OUVRIR ou F9 ouvre une sauvegarde existante. Ctrl+N demande une nouvelle carte.",
        "Sur PC, les sauvegardes sont des fichiers JSON dans le dossier villes a cote du programme. Ne deplacez pas uniquement le script : gardez ses modules et le dossier villes.",
        "Sur iPad, SAUV conserve la ville dans le stockage du navigateur. EXP exporte une copie JSON ; IMP permet de la reimporter. Faites des exports avant de vider les donnees de Safari.",
        "Le fichier BAT se lance sur le PC, jamais sur iPad. Pour jouer sur iPad, ouvrez dans Safari l'adresse du serveur MINICITY_WEB du PC, sur le meme reseau Wi-Fi.",
        "Le numero de version apparait dans le titre et pres du nom de la ville. Une nouvelle version peut ouvrir vos anciennes villes ; conservez une copie avant une mise a jour.",
    ]),
]


class GuideJeu:
    def __init__(self, world):
        self.g = world
        self.page = 0
        self.pages = []
        self.key = None
        self.buttons = {}
        self.scroll = 0          # decalage vertical du texte (en lignes)
        self.drag_y = None       # glisser du doigt / de la souris pour defiler

    def lignes_visibles(self):
        panel = self.layout()
        h = self.g['F_MENU'].get_linesize()+6
        return max(3,(panel.bottom-56-(panel.y+88))//h)

    def defiler(self, delta):
        _, lines = self.pages[self.page]
        maxi = max(0,len(lines)-1-self.lignes_visibles())
        self.scroll = max(0,min(maxi,self.scroll+delta))

    def layout(self):
        g = self.g
        panel = g['rect_aide_commandes']()
        font = g['F_MENU']
        key = (tuple(panel), font.get_height(), LNG.LANG)
        if key == self.key: return panel
        self.key = key; self.scroll = 0
        self.pages = []
        line_h = font.get_linesize()+6
        menu_width = min(250,max(185,panel.w//4))
        content_width = max(180,panel.w-menu_width-68)
        for title, paragraphs in LNG.guide(GUIDE):
            lines = []
            for paragraph in paragraphs:
                line = ''
                for word in paragraph.split():
                    candidate = (line+' '+word).strip()
                    if line and _brut(font).size(candidate)[0] > content_width:
                        lines.append(line); line = word
                    else: line = candidate
                lines.extend((line,''))
            self.pages.append((title,lines))
        self.page = min(self.page,len(self.pages)-1)
        menu_x = panel.x+18
        menu_y = panel.y+62
        menu_h = min(40,max(20,(panel.h-128)//max(1,len(self.pages))))
        self.buttons = {
            'close': pygame.Rect(panel.right-56,panel.y+10,42,38),
            'prev': pygame.Rect(panel.x+menu_width+18,panel.bottom-51,60,38),
            'next': pygame.Rect(panel.right-80,panel.bottom-51,60,38),
        }
        for i in range(len(self.pages)):
            self.buttons['title_'+str(i)] = pygame.Rect(menu_x,menu_y+i*menu_h,menu_width-18,menu_h-5)
        self.menu_rect = pygame.Rect(menu_x,panel.y+48,menu_width-18,panel.h-108)
        self.content_x = panel.x+menu_width+18
        return panel

    def handle(self, event):
        g = self.g
        if not g['aide_commandes']: return False
        panel = self.layout()
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE,pygame.K_F1): g['aide_commandes'] = False
            elif event.key in (pygame.K_RIGHT,pygame.K_PAGEDOWN): self.page = min(len(self.pages)-1,self.page+1); self.scroll = 0
            elif event.key in (pygame.K_LEFT,pygame.K_PAGEUP): self.page = max(0,self.page-1); self.scroll = 0
            elif event.key == pygame.K_DOWN: self.defiler(3)
            elif event.key == pygame.K_UP: self.defiler(-3)
            return True
        if event.type == pygame.MOUSEWHEEL:
            lines = self.pages[self.page][1]
            if len(lines)-1 > self.lignes_visibles(): self.defiler(-3*event.y)
            else: self.page = min(len(self.pages)-1,max(0,self.page-event.y)); self.scroll = 0
            return True
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if not panel.collidepoint(event.pos) or self.buttons['close'].collidepoint(event.pos):
                    g['aide_commandes'] = False
                else:
                    for i in range(len(self.pages)):
                        if self.buttons['title_'+str(i)].collidepoint(event.pos):
                            self.page = i; self.scroll = 0
                            return True
                    if self.buttons['prev'].collidepoint(event.pos): self.page = max(0,self.page-1); self.scroll = 0
                    elif self.buttons['next'].collidepoint(event.pos): self.page = min(len(self.pages)-1,self.page+1); self.scroll = 0
                    elif event.pos[0] >= self.content_x: self.drag_y = (event.pos[1],self.scroll)
            return True
        if event.type == pygame.MOUSEMOTION and self.drag_y is not None and event.buttons[0]:
            h = self.g['F_MENU'].get_linesize()+6
            self.scroll = self.drag_y[1]
            self.defiler(int(round((self.drag_y[0]-event.pos[1])/h)))
            return True
        if event.type == pygame.MOUSEBUTTONUP: self.drag_y = None
        return event.type in (pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION,
                              pygame.FINGERDOWN,pygame.FINGERMOTION,pygame.FINGERUP)

    def draw(self):
        g = self.g
        if not g['aide_commandes']: return
        panel = self.layout()
        screen = g['ecran']
        shade = pygame.Surface(screen.get_size(),pygame.SRCALPHA)
        shade.fill((0,0,0,150)); screen.blit(shade,(0,0))
        acc = g.get('UI_ACCENT',g['ACCENT']); acc_f = g.get('UI_ACCENT_FONCE',g['PANEL_CLAIR'])
        if 'ui_panneau' in g: g['ui_panneau'](panel,None,acc)
        else:
            pygame.draw.rect(screen,g['PANEL'],panel,border_radius=8); pygame.draw.rect(screen,g['OR'],panel,2,border_radius=8)
        if 'ui_icone' in g: screen.blit(g['ui_icone']("aide",22,acc),(panel.x+20,panel.y+16))
        screen.blit(g['F_TITRE'].render("Mode d'emploi",True,g['TEXTE']),(panel.x+50,panel.y+9))
        screen.blit(g['F_BTN'].render("SOMMAIRE",True,g['TEXTE_FAIBLE']),(panel.x+20,panel.y+45))
        pygame.draw.line(screen,g['BORDURE'],(self.content_x-10,panel.y+48),(self.content_x-10,panel.bottom-18),1)
        mouse = pygame.mouse.get_pos()
        for i,(menu_title,_) in enumerate(self.pages):
            rect = self.buttons['title_'+str(i)]
            selected = i == self.page
            if selected: pygame.draw.rect(screen,acc_f,rect,border_radius=6)
            elif rect.collidepoint(mouse): pygame.draw.rect(screen,g['PANEL_CLAIR'],rect,border_radius=6)
            label = _brut(g['F_BTN']).render(menu_title,True,g['TEXTE'] if selected else g['TEXTE_FAIBLE'])
            screen.blit(label,label.get_rect(midleft=(rect.x+10,rect.centery)))
        title, lines = self.pages[self.page]
        screen.blit(_brut(g['F_MENU']).render(title,True,acc),(self.content_x,panel.y+58))
        y = panel.y+88
        font = g['F_MENU']
        zone = pygame.Rect(self.content_x,panel.y+84,panel.right-self.content_x-22,max(10,panel.bottom-56-(panel.y+84)))
        ancien = screen.get_clip(); screen.set_clip(zone)
        h_ligne = font.get_linesize()+6
        self.scroll = max(0,min(self.scroll,max(0,len(lines)-1-self.lignes_visibles())))
        for line in lines[self.scroll:]:
            if y > zone.bottom: break
            if line: screen.blit(_brut(font).render(line,True,g['TEXTE']),(self.content_x,y))
            y += h_ligne
        screen.set_clip(ancien)
        if len(lines)-1 > self.lignes_visibles():     # barre de defilement
            rail = pygame.Rect(panel.right-16,zone.y,5,zone.h)
            pygame.draw.rect(screen,g['BORDURE'],rail,border_radius=3)
            part = self.lignes_visibles()/float(len(lines)-1)
            haut = int(rail.h*part); pos = int((rail.h-haut)*self.scroll/max(1,len(lines)-1-self.lignes_visibles()))
            pygame.draw.rect(screen,acc,(rail.x,rail.y+pos,rail.w,max(18,haut)),border_radius=3)
        for name,label in (('close','X'),('prev','<'),('next','>')):
            rect = self.buttons[name]
            enabled = name == 'close' or (self.page > 0 if name == 'prev' else self.page < len(self.pages)-1)
            if 'ui_bouton' in g: g['ui_bouton'](rect,label,desactive=not enabled)
            else:
                pygame.draw.rect(screen,g['PANEL_CLAIR'],rect,border_radius=4)
                image = g['F_BTN'].render(label,True,g['TEXTE'] if enabled else g['TEXTE_FAIBLE'])
                screen.blit(image,image.get_rect(center=rect.center))
        label = g['F_BTN'].render(str(self.page+1)+' / '+str(len(self.pages)),True,g['TEXTE_FAIBLE'])
        screen.blit(label,label.get_rect(center=((self.content_x+panel.right)//2,panel.bottom-32)))
