"""MINICITY - langue de l'interface (francais / anglais americain).

Les textes du jeu sont ecrits en francais dans le code. Quand la langue est
"en", chaque texte passe par tr() avant d'etre dessine : le dictionnaire
minicity_en.EN donne l'equivalent anglais (phrase entiere ou fragment).
"""
import os, re, sys

LANG = "fr"
LANGUES = ("fr", "en")
_brut = 0            # >0 : le texte est deja dans la langue voulue (manuel)
_cache = {}
_rx = None
_exact = {}
_hooks = []          # fonctions appelees quand la langue change


def _charger():
    """Prepare le dictionnaire (une seule fois, a la premiere traduction)."""
    global _rx, _exact
    if _rx is not None: return
    import minicity_en
    frag = {}
    for cle, val in minicity_en.EN.items():
        if cle.startswith("="): _exact[cle[1:]] = val
        else: frag[cle] = val
    _exact.update(frag)
    motifs = []
    for cle in sorted(frag, key=len, reverse=True):
        p = re.escape(cle)
        if cle[:1].isalnum(): p = r"(?<![A-Za-z0-9À-ÿ])" + p
        if cle[-1:].isalnum(): p = p + r"(?![A-Za-z0-9À-ÿ])"
        motifs.append(p)
    _rx = re.compile("|".join(motifs)) if motifs else re.compile(r"(?!x)x")
    _frag.update(frag)


_frag = {}
_RX_ARGENT = re.compile(r"(?<![A-Za-z0-9$])([+-]?)(\d+(?:[   ,]\d{3})*(?:\.\d+)?)(?: ?)S(?![A-Za-z0-9])")
_RX_NOMBRE = re.compile(r"(?<=\d) (?=\d{3}(?!\d))")
_RX_DOLLAR = re.compile(r"(?<![\w$])(\d+(?:[ ,]\d{3})*) \$")


def _argent(m):
    n = m.group(2).replace(" ", ",").replace(" ", ",").replace(" ", ",")
    if re.fullmatch(r"\d{4,}", n): n = "{:,}".format(int(n))
    return m.group(1) + "$" + n


def _traduire(s):
    _charger()
    r = _exact.get(s)
    if r is not None: return r
    # Les montants d'abord : "120S", "5 000 S" -> "$120", "$5,000".
    s2 = _RX_ARGENT.sub(_argent, s)
    s2 = _RX_DOLLAR.sub(lambda m: "$" + m.group(1).replace(" ", ","), s2)
    r = _exact.get(s2)
    if r is not None: return r
    if not re.search(r"[A-Za-zÀ-ÿ]{2}", s2): return s2
    out = _rx.sub(lambda m: _frag[m.group(0)], s2)
    if out != s2: out = out.replace(" : ", ": ").replace(" ;", ";").replace(" !", "!").replace(" ?", "?")
    return out


def tr(s):
    """Texte francais -> texte dans la langue courante."""
    if LANG == "fr" or _brut or not isinstance(s, str) or not s: return s
    r = _cache.get(s)
    if r is None:
        r = _traduire(s)
        if len(_cache) > 8000: _cache.clear()
        _cache[s] = r
    return r


class brut:
    """with brut(): les textes ne sont pas retraduits (ils le sont deja)."""
    def __enter__(self):
        global _brut; _brut += 1
    def __exit__(self, *a):
        global _brut; _brut -= 1


class TFont:
    """Enveloppe d'une pygame.font.Font : traduit les textes avant de les dessiner."""
    __slots__ = ("f",)
    def __init__(self, f): self.f = f
    def render(self, text, *a, **k): return self.f.render(tr(text), *a, **k)
    def size(self, text): return self.f.size(tr(text))
    def __getattr__(self, nom): return getattr(self.f, nom)


def installer_polices(pygame):
    """Toutes les polices creees ensuite par le jeu traduisent leurs textes."""
    if getattr(pygame.font, "_mc_installe", False): return
    sysfont0 = pygame.font.SysFont; font0 = pygame.font.Font
    pygame.font.SysFont = lambda *a, **k: TFont(sysfont0(*a, **k))
    pygame.font.Font = lambda *a, **k: TFont(font0(*a, **k))
    pygame.font._mc_installe = True


def detecter():
    """Langue du systeme : 'fr' pour un systeme francais, sinon 'en'."""
    code = ""
    try:
        if sys.platform == "emscripten":
            import platform as _p
            try: code = str(_p.window.navigator.language)
            except Exception: code = ""
        else:
            import locale
            code = locale.getlocale()[0] or ""
            if not code:
                import ctypes
                buf = ctypes.create_unicode_buffer(85)
                if ctypes.windll.kernel32.GetUserDefaultLocaleName(buf, 85): code = buf.value
    except Exception:
        code = ""
    code = code.lower()
    return "fr" if code.startswith("fr") or code.startswith("french") else "en"


def definir(code, notifier=True):
    """Change la langue ('fr' ou 'en') et previent les modules qui gardent des images."""
    global LANG
    if code not in LANGUES: return False
    if code == LANG: return True
    LANG = code
    _cache.clear()
    if notifier:
        for h in _hooks:
            try: h()
            except Exception: pass
    return True


def sur_changement(fonction):
    _hooks.append(fonction)


def guide(guide_fr):
    """Manuel dans la langue courante (liste de (titre, [paragraphes]))."""
    if LANG == "fr": return guide_fr
    import minicity_en
    return minicity_en.GUIDE_EN


# --- memorisation du choix de langue ----------------------------------------------
def _fichier():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "_langue.txt")


def charger():
    """Langue memorisee (fichier a cote du jeu, ou stockage du navigateur) ; sinon langue du systeme."""
    code = os.environ.get("MINICITY_LANG")   # force la langue (tests)
    try:
        if code: pass
        elif sys.platform == "emscripten":
            import platform as _p
            code = _p.window.localStorage.getItem("minicity_lang")
            code = str(code) if code else None
        else:
            with open(_fichier(), encoding="utf-8") as f: code = f.read().strip()
    except Exception:
        code = None
    if code not in LANGUES: code = detecter()
    definir(code, notifier=False)
    _prevenir_page()
    return LANG


def enregistrer():
    try:
        if sys.platform == "emscripten":
            import platform as _p
            _p.window.localStorage.setItem("minicity_lang", LANG)
        else:
            with open(_fichier(), "w", encoding="utf-8") as f: f.write(LANG)
    except Exception:
        pass
    _prevenir_page()


def _prevenir_page():
    """Navigateur : la page HTML (boutons tactiles) suit la langue du jeu."""
    if sys.platform != "emscripten": return
    try:
        import platform as _p
        _p.window.eval("window.mcSetLang && window.mcSetLang('%s')" % LANG)
    except Exception:
        pass
