"""MINICITY: shared, transactional network construction for desktop and touch."""
from dataclasses import dataclass, field

VERSION = "4.7.81"
ROUTE, RAIL, AUTOROUTE, TGV, TROTTOIR = 1, 2, 24, 25, 3
RUE = 604
MIL = {RAIL: 26, TGV: 27}
WIDTH = {ROUTE: 2, RAIL: 3, AUTOROUTE: 4, TGV: 3, TROTTOIR: 1, RUE: 4}
VECTORS = ((1, 0), (-1, 0), (0, 1), (0, -1))
OPPOSITE = (1, 0, 3, 2)


def roundabout_plan(ax, ay, size=10, missing=None):
    """missing : cote sans branche (0 haut/N, 1 droite/E, 2 bas/S, 3 gauche/W) pour
    le rond-point a trois branches ; None = quatre branches."""
    lo, hi, mid = 2, size-3, size//2
    roads = {}
    def add(x, y, heading): roads[(ax+x, ay+y)] = heading
    # Circulation a droite : l'anneau tourne dans le sens inverse des aiguilles
    # d'une montre (on entre en tournant a droite, l'ilot reste a gauche).
    for x in range(hi, lo, -1): add(x, lo, 1)
    for y in range(lo, hi): add(lo, y, 2)
    for x in range(lo, hi): add(x, hi, 0)
    for y in range(hi, lo, -1): add(hi, y, 3)
    for p in (0, 1):
        if missing != 0: add(mid-1, p, 2); add(mid, p, 3)
        if missing != 3: add(p, mid, 0); add(p, mid-1, 1)
    for p in (size-2, size-1):
        if missing != 1: add(p, mid-1, 1); add(p, mid, 0)
        if missing != 2: add(mid, p, 3); add(mid-1, p, 2)
    island = {(ax+x, ay+y) for y in range(lo+1, hi) for x in range(lo+1, hi)}
    exits = {}
    if missing != 0: exits[(ax+mid, ay+lo)] = (ax+mid, ay+lo-1)
    if missing != 1: exits[(ax+hi, ay+mid)] = (ax+hi+1, ay+mid)
    if missing != 2: exits[(ax+mid-1, ay+hi)] = (ax+mid-1, ay+hi+1)
    if missing != 3: exits[(ax+lo, ay+mid-1)] = (ax+lo-1, ay+mid-1)
    return roads, island, exits


def draw_roundabout(g, ax, ay, size=10, missing=None):
    import math
    import pygame
    screen, zoom = g['ecran'], g['zoom']
    mid = size/2
    def project(x, y):
        return g['grid_to_screen'](ax+x, ay+y)
    def polygon(points, color, width=0):
        pygame.draw.polygon(screen, color, [project(x,y) for x,y in points], width)
    def rounded(low, high, radius):
        points = []
        for cx,cy,angle in ((high-radius,low+radius,-90),(high-radius,high-radius,0),
                            (low+radius,high-radius,90),(low+radius,low+radius,180)):
            for i in range(13):
                a = math.radians(angle+i*7.5)
                points.append((cx+radius*math.cos(a),cy+radius*math.sin(a)))
        return points
    def disk(cx,cy,r,color):
        polygon([(cx+r*math.cos(i*math.tau/40),cy+r*math.sin(i*math.tau/40)) for i in range(40)],color)
    edge, asphalt = (204,209,207), (83,88,95)
    polygon(rounded(2,size-2,.85),edge)
    polygon(rounded(2.08,size-2.08,.80),asphalt)
    # Two-lane mouths line up exactly with the four grid connection ports.
    for turn in range(4):
        if turn == missing: continue
        def rotate(p):
            x,y=p
            for _ in range(turn): x,y=size-y,x
            return x,y
        polygon([rotate(p) for p in ((mid-1,0),(mid+1,0),(mid+1,2.65),(mid-1,2.65))],asphalt)
        for offset in (-1,1):
            pygame.draw.lines(screen,edge,False,[project(*rotate(p)) for p in ((mid+offset,0),(mid+offset,1.5))],max(1,round(3*zoom)))
        for start in (.15,.85):
            pygame.draw.line(screen,(239,238,224),project(*rotate((mid,start))),project(*rotate((mid,start+.42))),max(1,round(2*zoom)))
        for j in range(3):
            x=mid-.88+j*.29
            polygon([rotate(p) for p in ((x,1.80),(x+.18,1.80),(x+.18,1.91),(x,1.91))],(242,239,224))
        polygon([rotate(p) for p in ((mid-.73,.90),(mid-.27,.90),(mid-.5,1.28))],(242,239,224),max(1,round(2*zoom)))
    polygon(rounded(2.92,size-2.92,.8),(139,150,147))
    polygon(rounded(3.02,size-3.02,.76),(226,228,215))
    polygon(rounded(3.17,size-3.17,.7),(71,124,72))
    polygon(rounded(3.27,size-3.27,.65),(110,166,85))
    if missing is not None:
        _ilot_fontaine(g, ax, ay, size, project, polygon, disk)
        return
    # Low planting keeps vehicles visible on the far side of the island.
    disk(mid,mid,.65,(179,186,164))
    disk(mid,mid,.53,(68,115,62))
    for i in range(12):
        angle=i*math.tau/12
        disk(mid+.42*math.cos(angle),mid+.42*math.sin(angle),.12,(234,199,83) if i%2 else (216,115,139))
    disk(mid,mid,.25,(53,107,64)); disk(mid-.06,mid-.06,.18,(139,185,96))
    if size >= 10:
        for dx,dy in ((-1,-1),(1,-1),(-1,1),(1,1)):
            disk(mid+dx,mid+dy,.29,(66,114,63))
            disk(mid+dx-.045,mid+dy-.06,.21,(145,184,95))


def _ilot_fontaine(g, ax, ay, size, project, polygon, disk):
    """Ilot du rond-point a trois branches : massifs fleuris, buis tailles et
    bassin circulaire (le jet d'eau anime est dessine par draw_fontaine)."""
    import math
    mid = size/2
    h = (size-6.54)/2          # demi-largeur de la pelouse de l'ilot
    rb = .48*h
    # Allee de dalles claires autour du bassin.
    disk(mid,mid,rb+.24*h,(214,210,192))
    disk(mid,mid,rb+.19*h,(196,191,170))
    # Massifs fleuris dans les quatre coins, bordure de buis.
    fleurs = ((222,72,92),(246,196,64),(246,246,240),(176,96,200),(255,140,60))
    d = .70*h; rm = .22*h; nf = 9 if size >= 10 else 6
    for k,(cx,cy) in enumerate(((-1,-1),(1,-1),(1,1),(-1,1))):
        px,py = mid+cx*d,mid+cy*d
        disk(px,py,rm,(58,104,56))
        disk(px-.02*h,py-.025*h,rm*.86,(96,150,74))
        for i in range(nf):
            a = i*math.tau/nf+k
            disk(px+rm*.55*math.cos(a),py+rm*.55*math.sin(a),rm*.19,fleurs[(i+k) % len(fleurs)])
        disk(px,py,rm*.22,fleurs[(k+2) % len(fleurs)])
    # Buis ronds sur les axes, entre les massifs.
    for cx,cy in ((0,-1),(1,0),(0,1),(-1,0)):
        px,py = mid+cx*.86*h,mid+cy*.86*h
        disk(px,py,.12*h,(48,92,52))
        disk(px-.02*h,py-.03*h,.086*h,(112,162,86))
    # Bassin : margelle de pierre et eau.
    disk(mid,mid,rb,(170,166,154))
    disk(mid,mid,rb*.91,(226,222,206))
    disk(mid,mid,rb*.82,(58,126,170))
    disk(mid,mid,rb*.72,(84,160,206))
    disk(mid-.07*h,mid-.08*h,rb*.32,(126,194,228))


def draw_fontaine(g, ax, ay, size=10, t_ms=0):
    """Fontaine du rond-point a trois branches : buis tailles en boule, vasque
    sur un fut et jet d'eau anime (dessines a la profondeur de l'ilot)."""
    import math
    import pygame
    zoom = g['zoom']; ecran = g['ecran']
    mid = size/2; hh = (size-6.54)/2
    cx, cy = g['grid_to_screen'](ax+mid, ay+mid)
    if cx < -300 or cx > ecran.get_width()+300 or cy < -400 or cy > ecran.get_height()+300: return
    t = t_ms/1000.0
    P = lambda x,y: g['grid_to_screen'](ax+x, ay+y)
    # Buis tailles en boule (volume, ombre portee), sur les axes entre les massifs.
    rbuis = max(2,round(.10*hh*g['TILE_W']*zoom))
    buis = sorted(((mid+dx*.86*hh, mid+dy*.86*hh) for dx,dy in ((0,-1),(1,0),(0,1),(-1,0))), key=lambda q: q[0]+q[1])
    for bx,by in buis:
        sx,sy = P(bx,by)
        pygame.draw.ellipse(ecran,(52,92,50),(round(sx-rbuis*1.1),round(sy-rbuis*.35),round(rbuis*2.2),max(2,round(rbuis*.8))))
        pygame.draw.circle(ecran,(46,96,50),(round(sx),round(sy-rbuis*.9)),rbuis)
        pygame.draw.circle(ecran,(84,146,72),(round(sx-rbuis*.18),round(sy-rbuis*1.05)),round(rbuis*.78))
        pygame.draw.circle(ecran,(132,188,100),(round(sx-rbuis*.38),round(sy-rbuis*1.3)),max(1,round(rbuis*.34)))
    # Vasque sur son fut.
    rv = .17*hh*g['TILE_W']*zoom/2
    hv = 20*hh*zoom
    pygame.draw.rect(ecran,(184,178,162),(round(cx-rv*.24),round(cy-hv),max(2,round(rv*.48)),round(hv)))
    pygame.draw.rect(ecran,(214,208,192),(round(cx-rv*.24),round(cy-hv),max(1,round(rv*.18)),round(hv)))
    pygame.draw.ellipse(ecran,(150,146,136),(round(cx-rv),round(cy-hv-rv*.24),round(2*rv),max(2,round(rv*.66))))
    pygame.draw.ellipse(ecran,(226,222,208),(round(cx-rv),round(cy-hv-rv*.38),round(2*rv),max(2,round(rv*.62))))
    pygame.draw.ellipse(ecran,(92,168,212),(round(cx-rv*.80),round(cy-hv-rv*.30),round(1.6*rv),max(2,round(rv*.44))))
    # Jet d'eau : colonne translucide qui respire, gerbe au sommet, retombees.
    haut = 78*hh*zoom*(0.93+0.07*math.sin(t*2.3))
    base_y = cy-hv-rv*.12
    W = int(rv*5+40*zoom)+8; H = int(haut+hv+rv*2+30*zoom)+8
    calque = pygame.Surface((W,H),pygame.SRCALPHA)
    ox,oy = W/2, haut+12*zoom+4            # origine du jet dans le calque
    for w,a in ((10,70),(7,120),(4,200),(2,255)):
        lw = max(1,round(w*zoom))
        pygame.draw.line(calque,(225,242,255,a),(round(ox),round(oy)),(round(ox),round(oy-haut)),lw)
    # Gerbe : filets paraboliques animes qui retombent dans la vasque puis le bassin.
    n = 18
    for i in range(n):
        ang = i*math.tau/n
        cs,sn = math.cos(ang),math.sin(ang)
        pts = []
        for k in range(9):
            f = k/8.0
            rx = cs*rv*1.55*f; ry = sn*rv*.62*f
            z = haut*(1.0-f*f)*.22
            pts.append((ox+rx, oy-haut+haut*.22-z+ry+f*f*(haut*.78+rv*.2)))
        pygame.draw.lines(calque,(232,246,255,150),False,[(round(x),round(y)) for x,y in pts],max(1,round(1.4*zoom)))
        for j in range(3):
            ph = (t*1.1+j/3.0+i*.071) % 1.0
            k = ph*8; k0 = int(k); fr = k-k0
            if k0 >= 8: continue
            x = pts[k0][0]+(pts[k0+1][0]-pts[k0][0])*fr; y = pts[k0][1]+(pts[k0+1][1]-pts[k0][1])*fr
            pygame.draw.circle(calque,(250,253,255,230),(round(x),round(y)),max(1,round(1.7*zoom)))
    # Panache au sommet.
    pygame.draw.circle(calque,(240,250,255,170),(round(ox),round(oy-haut)),max(2,round(6*zoom)))
    pygame.draw.circle(calque,(255,255,255,230),(round(ox),round(oy-haut)),max(1,round(3*zoom)))
    ecran.blit(calque,(round(cx-ox),round(base_y-oy)))
    # Petits jets en couronne au bord du bassin, inclines vers la vasque.
    rb = .40*hh
    for i in range(8):
        a = i*math.tau/8
        bx,by = P(mid+rb*math.cos(a), mid+rb*math.sin(a))
        h2 = 13*hh*zoom*(0.8+0.2*math.sin(t*3+i))
        pts = []
        for k2 in range(7):
            f = k2/6.0
            px = bx+(cx-bx)*.62*f; py = by+(cy-by)*.62*f-4*h2*f*(1-f)
            pts.append((round(px),round(py)))
        pygame.draw.lines(ecran,(214,238,252),False,pts,max(1,round(2*zoom)))
        pygame.draw.circle(ecran,(240,250,255),pts[-1],max(1,round(1.6*zoom)))
    # Ecume a la retombee.
    for i in range(10):
        a = i*math.tau/10+t*0.8
        ex,ey = P(mid+.26*hh*math.cos(a), mid+.26*hh*math.sin(a))
        pygame.draw.circle(ecran,(236,248,255),(round(ex),round(ey)),max(1,round(2*zoom)))


def direction(a, b):
    if a[0] != b[0]:
        return 0 if b[0] > a[0] else 1
    return 2 if b[1] > a[1] else 3


def axis(s):
    return 0 if s in (0, 1) else 2


def rectangle_distance(p, q, w):
    return max(q[0]-p[0], 0, p[0]-q[0]-w+1) + max(q[1]-p[1], 0, p[1]-q[1]-w+1)


@dataclass(frozen=True)
class Port:
    anchor: tuple
    outward: int


@dataclass
class Plan:
    kind: int
    start: tuple
    end: tuple
    path: list = field(default_factory=list)
    cells: dict = field(default_factory=dict)
    corners: dict = field(default_factory=dict)
    writes: dict = field(default_factory=dict)
    auto_bridges: dict = field(default_factory=dict)
    rail_bridges: dict = field(default_factory=dict)
    road_bridges: dict = field(default_factory=dict)   # case -> axe : rue qui enjambe une voie ferree classique
    junctions: set = field(default_factory=set)
    errors: dict = field(default_factory=dict)
    cost: int = 0
    snapped: bool = False

    @property
    def valid(self):
        return bool(self.cells) and not self.errors

    @property
    def reason(self):
        return next(iter(self.errors.values()), "")


class NetworkPlanner:
    """Plan against the live world; previews never mutate the city."""

    def __init__(self, world):
        self.g = world

    def tile(self, p):
        x, y = p
        if not (0 <= x < self.g['GRID_N'] and 0 <= y < self.g['GRID_N']):
            return -1
        return self.g['grille'][y][x]

    def heading(self, p):
        return self.g['SENS'].get(p)

    def family(self, p):
        t = self.tile(p)
        return RAIL if t == 26 else TGV if t == 27 else t

    def cell_axis(self, p):
        s = self.heading(p)
        if s is not None:
            return axis(s)
        x, y = p
        kind = self.family(p)
        if kind in MIL:
            for dx, dy in VECTORS:
                q = x+dx, y+dy
                if self.family(q) == kind and self.heading(q) is not None:
                    return axis(self.heading(q))
        if kind in (ROUTE, AUTOROUTE):
            return self.g['_axe_chaussee_case'](x, y)
        return None

    def strip(self, q, kind, a, position):
        w = WIDTH[kind]
        for i in range(w):
            p = (position, q[1]+i) if a == 0 else (q[0]+i, position)
            if kind in MIL and i == 1:
                yield p, (MIL[kind], None, a)
            else:
                s = (1 if i < w/2 else 0) if a == 0 else (2 if i < w/2 else 3)
                yield p, (kind, s if kind != TROTTOIR else None, a)

    def straight_cap(self, q, kind, a):
        w = WIDTH[kind]
        orientations = set()
        for k in range(w):
            pos = q[0]+k if a == 0 else q[1]+k
            for p, (t, s, _) in self.strip(q, kind, a, pos):
                if self.tile(p) != t:
                    return False
                actual = self.heading(p)
                if s is not None and actual is not None:
                    if actual == s: orientations.add(False)
                    elif kind in MIL and actual == OPPOSITE[s]: orientations.add(True)
                    else: return False
        if len(orientations) > 1: return False
        return True

    def find_port(self, point, kind, exclude=None, radius=1):
        """Snap to a complete end cap, never to the middle of a running line."""
        if kind == RUE:
            core_exclude = (exclude[0]+1, exclude[1]+1) if exclude else None
            port = self.find_port(point, ROUTE, core_exclude, radius)
            return Port((port.anchor[0]-1, port.anchor[1]-1), port.outward) if port else None
        w = WIDTH[kind]
        found = []
        for y in range(point[1]-w-radius+1, point[1]+radius+1):
            for x in range(point[0]-w-radius+1, point[0]+radius+1):
                q = x, y
                if q == exclude:
                    continue
                distance = rectangle_distance(point, q, w)
                if distance > radius:
                    continue
                for a in (0, 2):
                    if not self.straight_cap(q, kind, a):
                        continue
                    for s in ((0, 1) if a == 0 else (2, 3)):
                        base = x if a == 0 else y
                        outside = base+w if s in (0, 2) else base-1
                        inside = base-1 if s in (0, 2) else base+w
                        out = list(self.strip(q, kind, a, outside))
                        inn = list(self.strip(q, kind, a, inside))
                        if any(self.family(p) == kind for p, _ in out):
                            continue
                        if not all(self.tile(p) == v[0] for p, v in inn):
                            continue
                        longitudinal = abs((point[0] if a == 0 else point[1]) - (base+w-1 if s in (0, 2) else base))
                        found.append((distance, longitudinal, x, y, s))
        if not found:
            return None
        _, _, x, y, s = min(found)
        return Port((x, y), s)

    def snap_band(self, point, kind):
        if kind == RUE:
            anchor = self.snap_band(point, ROUTE)
            return (anchor[0]-1, anchor[1]-1) if anchor else None
        w = WIDTH[kind]
        offset = (w-1)//2
        if kind not in (ROUTE, TROTTOIR) or self.family(point) != kind:
            return None
        a = self.cell_axis(point)
        if a is None:
            return None
        for i in range(w):
            q = (point[0]-offset, point[1]-i) if a == 0 else (point[0]-i, point[1]-offset)
            pos = point[0] if a == 0 else point[1]
            if all(self.tile(p) == t and self.heading(p) in (s, None) for p, (t, s, _) in self.strip(q, kind, a, pos)):
                return q
        return None

    def start(self, point, kind):
        port = self.find_port(point, kind)
        offset = (WIDTH[kind]-1)//2
        q = port.anchor if port else self.snap_band(point, kind)
        return (q if q is not None else (point[0]-offset, point[1]-offset)), port

    def corner(self, kind, q, before, after, reverse=False):
        """Two independent flows, with no crossover between opposing lanes."""
        w = WIDTH[kind]
        arms = {OPPOSITE[before], after}
        h = next(s for s in arms if s in (0, 1))
        v = next(s for s in arms if s in (2, 3))
        cells = {(q[0]+x, q[1]+y): (MIL.get(kind, kind), None, 0) for y in range(w) for x in range(w)}
        lanes = (0, w-1) if kind in MIL else range(w)
        for row in lanes:
            hs = 1 if row < w/2 else 0
            incoming = hs == OPPOSITE[h]
            # Each L joins its own lateral offset at the vertical arm.
            col = w-1-row if (h == 1 and v == 2) or (h == 0 and v == 3) else row
            vs = v if incoming else OPPOSITE[v]
            edge_x = 0 if h == 1 else w-1
            edge_y = 0 if v == 3 else w-1
            start = (edge_x, row) if incoming else (col, edge_y)
            pivot = col, row
            end = (col, edge_y) if incoming else (edge_x, row)
            path = []
            for a, b in ((start, pivot), (pivot, end)):
                if a == b:
                    if not path: path.append(a)
                    continue
                s = direction(a, b); dx, dy = VECTORS[s]
                for j in range(abs(b[0]-a[0])+abs(b[1]-a[1])+1):
                    p = a[0]+dx*j, a[1]+dy*j
                    if not path or path[-1] != p: path.append(p)
            if reverse: path.reverse()
            for j, p in enumerate(path):
                s = direction(p, path[j+1]) if j+1 < len(path) else (vs if incoming else hs)
                if kind in MIL:
                    entry = OPPOSITE[vs if incoming else hs] if reverse else (hs if incoming else vs)
                    s = direction(path[j-1], p) if j else entry
                cells[q[0]+p[0], q[1]+p[1]] = kind, s, axis(s)
        return cells, ('E' if h == 0 else 'W', 'S' if v == 2 else 'N')

    def geometry(self, kind, path, start_port=None, end_port=None):
        if kind == RUE:
            core_path = [(x+1,y+1) for x,y in path]
            def core_port(port):
                return Port((port.anchor[0]+1,port.anchor[1]+1),port.outward) if port else None
            plan = self.geometry(ROUTE, core_path, core_port(start_port), core_port(end_port))
            sidewalks = {}
            for a,b in zip(core_path,core_path[1:]):
                if a == b: continue
                horizontal = a[1] == b[1]
                lo,hi = sorted((a[0],b[0]) if horizontal else (a[1],b[1]))
                for pos in range(lo,hi+2):
                    for edge in (-1,2):
                        cell = (pos,a[1]+edge) if horizontal else (a[0]+edge,pos)
                        sidewalks[cell] = (TROTTOIR,None,0 if horizontal else 2)
            for x,y in plan.corners:
                for j in range(-1,3):
                    for i in range(-1,3):
                        sidewalks[x+i,y+j] = (TROTTOIR,None,0)
            for cell,value in sidewalks.items():
                if cell not in plan.cells: plan.cells[cell] = value
            plan.kind = RUE
            plan.start,plan.end,plan.path = path[0],path[-1],path
            return plan
        plan = Plan(kind, path[0], path[-1], path)
        w = WIDTH[kind]
        for a, b in zip(path, path[1:]):
            if a == b: continue
            ax = axis(direction(a, b))
            lo, hi = (sorted((a[0], b[0])) if ax == 0 else sorted((a[1], b[1])))
            for pos in range(lo, hi+w):
                plan.cells.update(self.strip(a, kind, ax, pos))
        turns = []
        for a, b, c in zip(path, path[1:], path[2:]):
            turns.append((b, direction(a, b), direction(b, c)))
        if start_port and len(path) > 1:
            turns.append((path[0], start_port.outward, direction(path[0], path[1])))
        if end_port and len(path) > 1:
            turns.append((path[-1], direction(path[-2], path[-1]), OPPOSITE[end_port.outward]))
        for q, sin, sout in turns:
            if sin == sout: continue
            if sin == OPPOSITE[sout]:
                plan.errors[q] = "Demi-tour impossible"
                continue
            cells, arms = self.corner(kind, q, sin, sout)
            plan.cells.update(cells)
            plan.corners[q] = arms
        if kind in MIL:
            corner_cells = {(q[0]+i,q[1]+j) for q in plan.corners for j in range(w) for i in range(w)}
            orientations = set()
            for p,(t,s,a) in plan.cells.items():
                if t != kind or s is None or p in corner_cells: continue
                dx,dy = VECTORS[s]
                for q in (p,(p[0]+dx,p[1]+dy),(p[0]-dx,p[1]-dy)):
                    if q != p and q in plan.cells: continue
                    actual = self.heading(q)
                    if self.tile(q) == kind and actual in (s,OPPOSITE[s]):
                        orientations.add(actual != s)
            if orientations == {True}:
                plan.cells = {p:(t,OPPOSITE[s] if s is not None else None,a) for p,(t,s,a) in plan.cells.items()}
                for q,sin,sout in turns:
                    if q in plan.corners:
                        cells,_ = self.corner(kind,q,sin,sout,reverse=True)
                        plan.cells.update(cells)
            elif len(orientations) > 1:
                plan.errors[plan.end] = "Les extremites ont des sens de circulation incompatibles"
        return plan

    def plan(self, start, point, kind, start_port=None, alternate=False, snap=True):
        w = WIDTH[kind]; offset = (w-1)//2
        target_port = self.find_port(point, kind, exclude=start) if snap else None
        end = target_port.anchor if target_port else (self.snap_band(point, kind) if snap else None)
        snapped = end is not None
        end = end if end is not None else (point[0]-offset, point[1]-offset)
        if not snapped:
            dx, dy = end[0]-start[0], end[1]-start[1]
            if abs(dx) <= 1 and abs(dy) >= w+2: end = start[0], end[1]
            if abs(dy) <= 1 and abs(dx) >= w+2: end = end[0], start[1]
        if start == end:
            return Plan(kind, start, end)
        paths = []
        if start[0] == end[0] or start[1] == end[1]:
            paths.append([start, end])
        else:
            hfirst = abs(end[0]-start[0]) >= abs(end[1]-start[1])
            if start_port: hfirst = axis(start_port.outward) == 0
            if alternate: hfirst = not hfirst
            bends = [(end[0], start[1]), (start[0], end[1])]
            if not hfirst: bends.reverse()
            paths.extend([[start, bend, end] for bend in bends])
        plans = []
        for path in paths:
            p = self.geometry(kind, path, start_port, target_port)
            p.snapped = snapped
            self.validate(p)
            plans.append(p)
        # Show an available bend by default. R explicitly chooses the other bend.
        return plans[0] if alternate else min(plans, key=lambda p: (len(p.errors), len(p.corners)))

    def validate(self, plan):
        g = self.g; street = plan.kind == RUE
        kind = ROUTE if street else plan.kind; w = WIDTH[kind]
        validation_path = [(x+1,y+1) for x,y in plan.path] if street else plan.path
        for i, q in enumerate(validation_path):
            if q not in plan.corners: continue
            for other in validation_path[max(0,i-1):i]+validation_path[i+1:i+2]:
                if abs(q[0]-other[0])+abs(q[1]-other[1]) < w:
                    plan.errors[q] = "Prolonger le virage : %s cases minimum" % w
        side_names = {0: 'E', 1: 'W', 2: 'S', 3: 'N'}
        for q, arms in list(plan.corners.items()):
            existing_arms = set()
            for s in range(4):
                edge = [(q[0]+w if s == 0 else q[0]-1, q[1]+i) for i in range(w)] if s < 2 else [(q[0]+i, q[1]+w if s == 2 else q[1]-1) for i in range(w)]
                if all(self.family(p) == kind for p in edge): existing_arms.add(side_names[s])
            if existing_arms-set(arms):
                if kind == ROUTE:
                    del plan.corners[q]
                    for y in range(q[1], q[1]+w):
                        for x in range(q[0], q[0]+w):
                            plan.cells[x,y] = ROUTE, None, 0
                            plan.junctions.add((x,y))
                else:
                    plan.errors[q] = "Decaler le virage hors de la voie existante"
        if kind == ROUTE:
            # Adding a third arm to an existing bend turns that entire bend
            # into one junction, rather than keeping its old turning arrows.
            for x, y in set(plan.cells) & g['COINS_ROUTE']:
                for qx in (x-1,x):
                    for qy in (y-1,y):
                        block = {(qx+i,qy+j) for j in range(2) for i in range(2)}
                        if (qx,qy) in plan.corners or not block <= g['COINS_ROUTE'] or not block <= plan.cells.keys(): continue
                        if any(self.heading(p) != plan.cells[p][1] for p in block):
                            plan.junctions.update(block)
        corners = {p for q in plan.corners for p in ((q[0]+i, q[1]+j) for j in range(w) for i in range(w))}
        crossings = {}
        for p, (t, s, a) in plan.cells.items():
            old = self.tile(p); family = self.family(p); old_s = self.heading(p)
            old_a = self.cell_axis(p)
            if old == -1:
                plan.errors[p] = "Hors de la carte"; continue
            if street:
                if old in (RAIL,TGV,AUTOROUTE) + tuple(MIL.values()) and g['paysages'].get(p) in (None,'herbe'):
                    # Une rue traverse une voie ferree : pas de trottoir sur les rails, la chaussee
                    # passe au-dessus (pont routier) ; le TGV est deja deniveles automatiquement.
                    if t == TROTTOIR: continue
                elif old not in (0,TROTTOIR,ROUTE) or g['paysages'].get(p) not in (None,'herbe'):
                    plan.errors[p] = "Rue : emplacement occupe"; continue
                if t == ROUTE and old != AUTOROUTE and any(self.family((p[0]+dx,p[1]+dy)) == AUTOROUTE
                                     for dx,dy in ((0,0),)+VECTORS) and not any(self.tile(q) == AUTOROUTE and self.cell_axis(q) != a for q in ((p[0]+dx,p[1]+dy) for dx,dy in VECTORS)):
                    plan.errors[p] = "Rue incompatible avec l'autoroute"; continue
                if p in g.get('ROND_POINT_CELLS',set()) or p in g['PONTS_AUTO'] or p in g.get('PONTS_ROUTE',{}):
                    plan.errors[p] = "Utiliser Route pour ce raccord"; continue
                if t == TROTTOIR:
                    if old in (TROTTOIR,ROUTE): continue
                    if old != 0 or g['paysages'].get(p) not in (None,'herbe'):
                        plan.errors[p] = "Trottoir : emplacement occupe"; continue
                    plan.writes[p] = (TROTTOIR,None)
                    plan.cost += g['COUTS'][TROTTOIR]
                    continue
                if old == TROTTOIR:
                    plan.writes[p] = (ROUTE,s)
                    plan.cost += g['COUTS'][ROUTE]
                    continue
            if old == 0:
                if g['paysages'].get(p) not in (None, 'herbe', 'eau'):
                    plan.errors[p] = "Terrain occupe"; continue
                plan.writes[p] = (t, s)
                plan.cost += g['COUTS'].get(t, 0)
                continue
            if kind == TROTTOIR:
                if old != TROTTOIR: plan.errors[p] = "Emplacement occupe"
                continue
            if kind in MIL and old == TROTTOIR and any((p[0]+dx,p[1]+dy) in g['RUE_CELLS'] for dx,dy in VECTORS):
                # Une voie ferree traverse le trottoir d'une rue : le rail remplace le trottoir.
                plan.writes[p] = (t, s); plan.cost += g['COUTS'].get(t, 0); continue
            if family not in (ROUTE, AUTOROUTE, RAIL, TGV):
                plan.errors[p] = "Emplacement occupe"; continue
            if p in plan.junctions and family == ROUTE:
                plan.writes[p] = ROUTE, None
                continue
            if p in corners:
                if family != kind or p in g['PONTS_AUTO'] or p in g['PONTS_RAIL'] or p in g['CROISEMENTS'] or p in g['SOUTERRAINS']:
                    plan.errors[p] = "Virage trop proche du croisement"; continue
                plan.writes[p] = (t, s)
                continue
            if p in g['COINS_CELLS'] or p in g['COINS_ROUTE'] or any(abs(p[0]-q[0])+abs(p[1]-q[1]) <= 1 for q in g['COINS_RAIL']):
                if old == t and old_s == s: continue
                plan.errors[p] = "Raccorder a une extremite droite"; continue
            if p in g['PONTS_RAIL']:
                bridge = g['PONTS_RAIL'][p]
                match = any(bridge.get(layer+'_tt', bridge.get('tt')) == kind and bridge.get(layer+'_axe') == a and bridge.get(layer+'_tag') == ('mil' if t in MIL.values() else 'rail') and (s is None or bridge.get(layer+'_s') == s) for layer in ('bas', 'haut'))
                if not match: plan.errors[p] = "Un pont occupe deja ce croisement"
                continue
            if p in g['PONTS_AUTO']:
                if kind != AUTOROUTE or s not in g['PONTS_AUTO'][p].values(): plan.errors[p] = "Un pont occupe deja ce croisement"
                continue
            if family == kind and old_a in (None, a):
                if old == t and old_s in (None, s):
                    if p not in g['CAR_ID']: plan.writes[p] = (t, s)
                else:
                    plan.errors[p] = "Aligner les deux voies"
                continue
            if old_a is None or old_a == a:
                plan.errors[p] = "Reseaux paralleles incompatibles"; continue
            if kind == ROUTE and family == ROUTE:
                plan.writes[p] = (ROUTE, None); plan.junctions.add(p)
                continue
            crossings[p] = (family, old_a, a)
            if street and family == RAIL and p not in g['CROISEMENTS'] and p not in g['SOUTERRAINS']: plan.road_bridges[p] = a
            if kind == RAIL and family == ROUTE and p in g['RUE_CELLS'] and p not in g['SOUTERRAINS']: plan.road_bridges[p] = old_a
            if kind in MIL and family in MIL:
                plan.rail_bridges[p] = {'bas_tt': family, 'haut_tt': kind,
                    'bas_tag': 'mil' if old in MIL.values() else 'rail', 'haut_tag': 'mil' if t in MIL.values() else 'rail',
                    'bas_s': old_s, 'haut_s': s, 'bas_axe': old_a, 'haut_axe': a}
            elif kind == AUTOROUTE and family == AUTOROUTE:
                plan.auto_bridges[p] = {'bas': old_s, 'haut': s}
            elif kind in MIL or (kind == ROUTE and family == AUTOROUTE):
                plan.writes[p] = (t, s)
            # At mixed crossings the rail (or the ordinary road above the
            # motorway) remains the visible layer, regardless of build order.
            already = (kind == ROUTE and p in g['CROISEMENTS']) or (kind in (ROUTE, AUTOROUTE) and p in g['SOUTERRAINS']) or (kind == AUTOROUTE and p in g['PONTS_ROUTE'])
            if not already: plan.cost += g['COUTS'].get(t, 0)
        if plan.rail_bridges:
            bridges = dict(g['PONTS_RAIL']); bridges.update(plan.rail_bridges)
            valid = g['_ponts_rail_valides'](bridges)
            for p in plan.rail_bridges:
                if p not in valid: plan.errors[p] = "Prolonger au-dela du croisement"
        if plan.auto_bridges:
            bridges = dict(g['PONTS_AUTO']); bridges.update(plan.auto_bridges)
            valid = g['_ponts_auto_valides'](bridges)
            for p in plan.auto_bridges:
                if p not in valid: plan.errors[p] = "Prolonger au-dela du croisement"
        # A bridge or level crossing needs both approaches. This also rejects
        # stopping in the middle of the lower carriageway.
        for p, (family, old_a, a) in crossings.items():
            dx, dy = VECTORS[a]
            for sign in (-1, 1):
                q = p
                for _ in range(WIDTH[family]+1):
                    q = q[0]+dx*sign, q[1]+dy*sign
                    if self.family(q) != family: break
                if q not in plan.cells and self.family(q) != kind:
                    plan.errors[p] = "Prolonger au-dela du croisement"
        if plan.road_bridges:
            # Un pont routier par franchissement (cases voisines du meme axe).
            reste = set(plan.road_bridges); nb = 0
            while reste:
                d = reste.pop(); nb += 1; pile = [d]
                while pile:
                    x,y = pile.pop()
                    for q in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                        if q in reste and plan.road_bridges[q] == plan.road_bridges[d]: reste.discard(q); pile.append(q)
            plan.cost += nb*g['COUTS'].get(g.get('PONT_ROUTIER',650),400)
        if plan.cost > g['argent']:
            plan.errors[plan.end] = "Argent insuffisant : %s $" % plan.cost

    def commit(self, plan):
        if not plan.valid: return False
        g = self.g
        # Revalidate against the current city (undo, load, or another segment).
        checked = self.geometry(plan.kind, plan.path)
        checked.cells = dict(plan.cells); checked.corners = dict(plan.corners)
        checked.junctions = set(plan.junctions)
        self.validate(checked)
        if not checked.valid: return False
        checked.road_bridges = dict(plan.road_bridges)
        if not checked.writes and not checked.auto_bridges and not checked.rail_bridges and not checked.road_bridges:
            return True
        g['begin_gesture']()
        g['argent'] -= checked.cost
        for p, (t, s) in checked.writes.items():
            g['grille'][p[1]][p[0]] = t
            if s is None: g['SENS'].pop(p, None)
            else: g['SENS'][p] = s
            g['VOIES_V4'][p] = (t, s)
        g['PONTS_AUTO'].update(checked.auto_bridges)
        g['PONTS_RAIL'].update(checked.rail_bridges)
        g['PONTS_ROUTIER_RAIL'].update(checked.road_bridges)
        for q, arms in checked.corners.items():
            if plan.kind == AUTOROUTE:
                g['COINS_AUTO'][q] = g['COIN_PAR_COTE'][arms]
            elif plan.kind in (ROUTE,RUE):
                g['COINS_ROUTE'].update((q[0]+i, q[1]+j) for j in range(2) for i in range(2))
            elif plan.kind in MIL:
                g['COINS_RAIL'][(q[0]+1, q[1]+1)] = plan.kind
        g['COINS_ROUTE'].difference_update(checked.junctions)
        if plan.kind == RUE:
            g['RUE_CELLS'].update(p for p,(t,s,a) in checked.cells.items() if t == ROUTE and g['grille'][p[1]][p[0]] == ROUTE)
        g['_coins_rebuild']()
        g['marquer_reseau'](); g['_modif'](); g['end_gesture']()
        if checked.cost:
            g['float_text']('-%s $' % checked.cost, *g['grid_to_screen'](*plan.end), g['ROUGE'])
        return True

    def restore_directions(self):
        g = self.g
        for p, (t, s) in list(g['VOIES_V4'].items()):
            if self.tile(p) != t:
                g['VOIES_V4'].pop(p, None)
            elif s is None:
                g['SENS'].pop(p, None)
            else:
                g['SENS'][p] = s


class ConstructeurVoies(NetworkPlanner):
    """One input controller for click-click, dragging, mouse, and touch."""

    def __init__(self, world):
        super().__init__(world)
        self.reset()

    def reset(self):
        self.anchor = None
        self.port = None
        self.preview = None
        self.point = None
        self.pressed = None
        self.chained = False
        self.alternate = False
        self.kind = None
        self.cache_key = None

    def update(self, point):
        self.point = point
        key = (self.anchor, self.port, point, self.kind, self.alternate, self.g['argent'], self.g.get('_reseau_revision', 0))
        if key != self.cache_key:
            self.preview = self.plan(self.anchor, point, self.kind, self.port, self.alternate)
            self.cache_key = key

    def flip(self):
        self.alternate = not self.alternate
        self.cache_key = None
        if self.anchor is not None and self.point is not None: self.update(self.point)

    def cancel(self):
        pending = self.anchor is not None
        self.reset()
        return pending

    def handle(self, event):
        g = self.g; pg = g['pygame']
        kind = g['TOOLS'][g['outil_actif']]['type']
        if kind != self.kind and self.anchor is not None: self.reset()
        if kind not in WIDTH or kind == TROTTOIR or g['MODE_COLLAGE']:   # le trottoir se pose en zone, comme l'herbe
            return False
        if len(g.get('TOUCHES', {})) >= 2:
            self.cancel()
            return event.type in (pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION)
        if event.type in g['_EVT_DRAG_STOP']:
            self.cancel(); return False
        if g['saisie'] is not None or g['aide_commandes'] or g['dashboard'] or g['parametres_ouverts']:
            self.cancel(); return False
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE and self.cancel(): return True
            if event.key == pg.K_r:
                self.flip(); return True
            if event.mod & pg.KMOD_CTRL and event.key in (pg.K_z, pg.K_y):
                self.cancel(); return False
        if event.type not in (pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION): return False
        pos = event.pos
        in_game = g['zone_jeu'](*pos) and not g['parametres_ouverts']
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 3 and in_game:
                self.cancel(); return True
            if event.button != 1: return False
            if not in_game:
                self.cancel(); return False
            point = g['screen_to_grid'](*pos)
            self.kind = kind
            if self.anchor is None:
                self.anchor, self.port = self.start(point, kind)
                self.chained = False
            else:
                self.chained = True
            self.pressed = pos
            self.update(point)
            return True
        if event.type == pg.MOUSEMOTION and self.anchor is not None:
            if in_game: self.update(g['screen_to_grid'](*pos))
            return True
        if event.type == pg.MOUSEBUTTONUP and event.button == 1 and self.pressed is not None:
            distance = abs(pos[0]-self.pressed[0])+abs(pos[1]-self.pressed[1])
            self.pressed = None
            if not in_game:
                self.cancel(); return True
            self.update(g['screen_to_grid'](*pos))
            if self.chained or distance >= 6:
                p = self.preview
                if p and self.commit(p):
                    if self.chained and not p.snapped:
                        self.anchor = p.end
                        h = direction(p.path[-2], p.path[-1])
                        self.port = Port(p.end, h)
                        self.preview = None; self.cache_key = None
                    else:
                        self.reset()
                elif p and p.reason:
                    g['float_text'](p.reason, *pos, g['ROUGE'])
            return True
        return False

    def draw(self, gx, gy, tw2, th2):
        g = self.g; pg = g['pygame']; kind = g['TOOLS'][g['outil_actif']]['type']
        if kind not in WIDTH or kind == TROTTOIR: return False
        if self.anchor is not None and kind != self.kind: self.reset()
        if len(g.get('TOUCHES', {})) == 1 and self.point is not None:
            gx, gy = self.point
        if self.anchor is None:
            anchor, port = self.start((gx, gy), kind)
            w = WIDTH[kind]
            points = [g['grid_to_screen'](x, y) for x, y in (anchor, (anchor[0]+w, anchor[1]), (anchor[0]+w, anchor[1]+w), (anchor[0], anchor[1]+w))]
            pg.draw.lines(g['ecran'], g['BLEU'] if port else g['VERT'], True, points, 2)
            return True
        self.update((gx, gy))
        p = self.preview
        if not p: return True
        color = g['VERT'] if p.valid else g['ROUGE']
        overlays = {}
        for (x, y) in p.cells:
            sx, sy = g['grid_to_screen'](x, y)
            if sx+tw2 < 0 or sx-tw2 > g['LARGEUR'] or sy+2*th2 < g['HUD_H'] or sy > g['TOOLBAR_Y']: continue
            c = g['ROUGE'] if (x, y) in p.errors else color
            if c not in overlays:
                ov = pg.Surface((int(tw2*2)+4, int(th2*2)+4), pg.SRCALPHA)
                pg.draw.polygon(ov, (*c, 78), [(tw2+2, 2), (tw2*2+2, th2+2), (tw2+2, th2*2+2), (2, th2+2)])
                overlays[c] = ov
            g['ecran'].blit(overlays[c], (int(sx-tw2)-2, int(sy)-2))
            for dx, dy, edge in ((0,-1,((sx,sy),(sx+tw2,sy+th2))), (1,0,((sx+tw2,sy+th2),(sx,sy+2*th2))), (0,1,((sx,sy+2*th2),(sx-tw2,sy+th2))), (-1,0,((sx-tw2,sy+th2),(sx,sy)))):
                if (x+dx, y+dy) not in p.cells: pg.draw.line(g['ecran'], c, *edge, 2)
        w = WIDTH[kind]
        points = [g['grid_to_screen'](x+w/2, y+w/2) for x, y in p.path]
        if len(points) >= 2: pg.draw.lines(g['ecran'], color, False, points, 2)
        for point in points[:1]+points[-1:]: pg.draw.circle(g['ecran'], g['BLEU'] if p.snapped else color, (int(point[0]), int(point[1])), 5, 2)
        label = p.reason if p.reason else ('%s $' % p.cost if p.cells else '')
        if label:
            text = g['F_AIDE'].render(label, True, color)
            mx, my = pg.mouse.get_pos()
            x = max(8, min(mx+20, g['LARGEUR']-text.get_width()-16))
            y = max(g['HUD_H']+6, min(my-30, g['TOOLBAR_Y']-text.get_height()-8))
            pg.draw.rect(g['ecran'], g['PANEL'], (x-6, y-4, text.get_width()+12, text.get_height()+8), border_radius=4)
            g['ecran'].blit(text, (x, y))
        return True


# ---------------------------------------------------------------------------
# David de Michel-Ange au centre des ronds-points.
# Rendu 3D precalcule (marbre, ombres, piedestal) a l'echelle du zoom maximal ;
# reduit ensuite selon le zoom courant et mis en cache.
# ---------------------------------------------------------------------------
DAVID_ANCRE = (209, 484)        # pixel du centre du socle au sol dans l'image
DAVID_PX_PAR_CASE = 311.5795320620403        # pixels par case (cote) a la resolution de l'image
_DAVID = {"img": None, "cache": {}}
DAVID_PNG = (
    "iVBORw0KGgoAAAANSUhEUgAAAjQAAAJOCAYAAACgMp2kAAAgAElEQVR4nOy9eZBl133f9znnbm/pbWa6Z0MPBkMQCwEQ3Ck1WbYo"
    "iVoZqSiFw8SOy5WKoqSSlFIaSCm5UuUkVXYqdhQOtFiWFEu2Y7usBIgVJ4pky7HjuExxCFIEiX0ZzGCWnpneu99613NO/jjn3vd6"
    "CJKSOCAGg/Mp3urX/V6/d9+tN+gvf7/v7/cVeDyeb4lJ109jzGlgGSFWEAKEAAymUlRVhVKaqqpWy6o8V+Tlubwonjz5wIdW3+pz"
    "93g8nncC4q0+AY/ndsSk68sEwQpwGsEKiGUwoM3kX41SFHlBUZZUlSIMJDIIwBjKqqLIC8Zpdm4wGP7cez/yiXNv5fvxeDyeOx0v"
    "aDwehym3lgmj08BpYAWMu0e6Q7gjcD+vgBLynCzNGI3GFEVBFEXEcUQQBCilGI3G7Ozsndvc2v7s9/7wT/qKjcfj8bwJeEHjecdj"
    "8s1lAnmWID49ESsaK2gMVsyE7Bc19WMUUIIqoawo8pzxOKWqKoSUtJKEIJAopRkMh5Rl9fhgODz78Af/vBc2Ho/HcwvxgsbzjsaM"
    "184SR2cIQiDCihawQqYWNWAFTcD+fzL1/YpG3GgFZUmeZmRZjjEGGUiEECilybKMvb0ee3v9x5eWFp989yPf5VtRHo/Hcwvwgsbz"
    "jkUNrz8ho+A0YQgyAmL2C5r6gK+vzpibDidojIKqwpQlaZZjtCYIAmQQYIyhyHP6/SEbm1ukWUan3V41cPaDK598/Dv1vj0ej+dO"
    "xAsazzsOM76xDJxDsEwU22klGfP1FZr6EFM/Z+r+uuXkvioFWoObeirLEiEEQSCR0gmaomCcpgwGQ9bWN8mznLm5WYQQq0VRfva7"
    "P/GjvmLj8Xg8fwZu/q+0x3NHU/SurgDnCAIrZoIQ5HTlpUZMfX2jA5p2kyogzVBpSpVllGWJNhopBdI9d1VVFGWBMYYwDEmShNmZ"
    "LsPhiJ2dXZIkWZ6dnfnCH3/+D8+++VfB4/F47jy8oPG8YxhuXVwRUnyBIFgmDCGI3D3Tht9pbhYw8PWmYA3GVnK0MVSVsr4ZIZDS"
    "PqdSFZWqkFIShiFRGBJFIXEc0+l2WN/YIssykiRmdnbmzFP/5p9d/df//HeX37wr4fF4PHceXtB43hH01s8vt5L4ibDVgigCGUzd"
    "e7OQqcXNzePaYurnYvLYIIAoIgwChACtNcaAlBIhbB0nDEKiMCKKwkbUxFFEp9Oi2+2wtb1DmmVorYmTaBljrv7u7/zd02/qRfF4"
    "PJ47CC9oPO8Iup32E0EcL1sdUntj1NQjaj/MN9o9w023Q6yJOAQRQRgioggpA5TWKKVQSqO0RgpJ0koIkhgZho1JOIxCkjhhZqZD"
    "nufs7fbsyHdZWYeO1k/8+i//zZU39cJ4PB7PHUL4Vp+Ax/NmM9q6eFZKuYJ27aEQEMbebgo1Aitq6ttv1Ga6uZITuqOy9wXWN4Mx"
    "KKUwGKIoIgwj59PZ/4zSGYYDGaC1ZjgcUlYlUkrKsqAsSwaD4RPAiVt5PTwej+dOxFdoPHc0/Y3zK2EYnGl+YLSbRKqc9+Vm4VJX"
    "burD+WS+6UCg22Ejpau+2H9WUkjCIJiIGWPAuAgolwUlhEAbK6TyoqDIC8qiBKyhOI6j5Z/6y/+Bbz15PB7Pt8ALGs8dTRxFTwhh"
    "BYXRrsWkXSbTPt6o1TS9XO/mx78REqRdoofLrtTaCShj3FeNMWafPAoCWyaykQkxSZIQRxGtVotWq8XsTPfMG7+ex+PxeGq8oPHc"
    "sZT9q2eCIFg2xqC1RikNUkIgIQzs7YZasNSm3wC7l6beTyNuetw0N20VNmC0nXgqipKqrNBVhWpSuRVKW2EDNzl0hK3MhFFIq9Wi"
    "2+lw5Mjiyi//4l/349wej8fzTfCCxnNHMtx8bRk424gGYaeOCAIIQ3uAbUF9nUi5ecLp5vveCGOrL6peqleR5zl5nlNWJWVZUVU2"
    "lVtrW6GRUhAEAWEY0u10kEGAEIKiKO0uG62JopADC/O0260z//jv/bpvPXk8Hs83wAsazx2KeCIIArel17aBZFOVmRIqrg1khU19"
    "/Klfy36pKoqisEKmyMnynKKwnpiyKu1+GilcS0oghfXcdLsd5ufn6HbaSCmplGI8GpOmKUVRoI0hkBKl1BO//euPe1Hj8Xg8b4AX"
    "NJ47jv7G+ZUoCleEFBhj2ziAFTPCeWO0iylQLrKgqpiYgP9sqDxnNE4Zj1PSNCPPC3IncIw2SBk04spqGkEcR7TbbTqdNt1ulzAM"
    "kFJgwFV5CozWCCEoq5Kqqs7+j3/tr/qlex6Px3MTXtB47jgCKT8XhgFGG4wxGGMX3TXTTcpNONVG3fooK+wI9s37aQqg/OYvqlL6"
    "gyGD/oAsyymLEqUUVWWP2htTixmw2ioMAqJosj04iiICGSAQ1jws7FetFQJBVZbLMpCPvRnXzePxeN7OeEHjuaPYuf7yihByRWu7"
    "C0brWlRUqLK01RiE9dIEgVUVlcJUClOWkGdgRsAA6EG1C0UPlPueaurVlPu+R29ri729HmmW1ZUUALsROI4IQ/ta9rw0Wmm0m7Qy"
    "xsYmTPt9KlUxeQ+asrRhl2VZ0e8Pz3zm0z/mqzQej8czhV+s57mjMEafsQKgXlBnKyVCSqIwpB0ENAnargVVqQqltKvmGMR4TBDY"
    "jb62miIQSoMoIdYgW+7VCtRwxO7eHnt7PTIXXWAMRFFIEsfEcUwYhdQBlVopitJ6bYqymBIqJUVhb9em4izLKIqCLMspypIwCEmz"
    "jNFoBIbTwONv0WX2eDye2w4vaDx3FFVZnRYIgjAgCkOUUqRZhpQSE8fEcUTgwiTtPhpNVVXkRYlWyoofIZoNv/WivCiKwBh0miEj"
    "W30p0oxev8+gP6AsSwQ2kFJKSafTsWImDJBCorR97rIoKcqSwvlrrJAprXnYiZvMTUeNx2NGozEvv3oBgFP3nODCxcv0egOklF7Q"
    "eDwezxRe0HjuGF595vOnlVJY/8zEg+ImhKjcSHVQ1Qv2NFVZNUKint7W2rjKjiYMA2ZnZ6HVAUBWBShFnmWMhiPKsiSKI4IwQGuD"
    "0ZowimglMUFoF+YZY6jKygqYoqScmoYqitKOdpeVbS256kxRFIzGY1546Tw7O7too1nf2EJrRSADgiDwGU8ej8czhffQeO4Y0ixb"
    "oY4VwE4RhWFIHMcIJ2qKoqTIc1SWo4oCY7Stqgi7EyaKImvMDQKCIKDd7kC7Q7NkL2zZbcAIZBAQx7GbUurQabfodNq0WglhGDYj"
    "48ZYgZRnebObJs8L8rywY9lag3BemmaPTcn29i6bm1tkeeZ+N7PRCK4t9cOf/F4vajwej8fhKzSeO4Ysz5cFwuUlTRbgCSkQ4DKS"
    "QClFHMeNcEkSO0qtlK3chKHd0is6s0ALuzV4OufJtrTa7ZYz92qUVjYl2xiktC0qIQVaaVcZUq61VTSL8/I8t+fnMp0AVNMCK9jc"
    "3KYoC/Ist/4e7DK+JifT4I3BHo/H4/CCxnPHIIU8p7U+rbVC64lAqQWOUgpR1QvtFPXivSCQhGHYiIp2u+2qMm2m4rhplEQQELTa"
    "BLix70qRFznGgKoq67uRsqm6KFdxKVyVJs1zyqJoWlogMHoSz2CrOQVb2zvOc1M0I+hRHNn3ZWimojwej8fjBY3nDiKOo9WydFUY"
    "rdHGEEeRG5sO3eoZQxBaIWOMcSZgW6FJkhgZhBBH2G7sGwmGNsg2di9NYQ/hJqS0bl5baI0AKtfmqhfsjcYpY7cBOJASrSObuK21"
    "NQu7qab+YECaZnYCym0LtmZna3TWSiMDufodubAej8fzNsALGs8dQ5bl1gNTVrby0YEkttNKAN2upigrAindTj3bLgrdUjsRRSCn"
    "Qyu/2dZgF1gprODI3Wi1dlWhylV86qmlNM0YDsf0BwNGoxFFUZIkMXEUgRAYrSmKktF4zHA05srVa5RlyWhsjccgiOMY7YzMwOpT"
    "T33t3Jt3NT0ej+fthRc0njuGvb0eYEiShFYrIYqiZnmdEIIgCAndsrpm54zb4GtMiDBMtgdLha3CCKx4eSMqyHOyLCPNMvI8tz4a"
    "XMyBsLtnxmnGcDik1+uzu9ujPxhQlhXdTps4iQErroqiZDgasbGxxdXV66RpSpqmGLBj40BVVVRAGEifvu3xeDxTfKPoYI/nbckf"
    "/B//0Bw8sMDc3Cwz3S4zszN02i3qxXala+torTHY6IEkSWi3W1Y0CEkzKVWnc4sE6Nz0SgbULsPdPQaDgRU145TcPbcUbmlfVZGm"
    "Kf3+kJ3dXbZ3dunt9UmzjIMHF2glCQBKafIiZ3e3xzPPvcRwMHSVndR6ZQQIrLk5CIInn3v51c9+Ry+sx+Px3Ob4Co3njmJjY+tc"
    "u9Va6XTazSSRFDbsUVUVVaXIsgy7ryZExFC4rcLWZCvctt+6eiOJkwJaCugy2XQwJOsPGLoWUppmjFxCdlVVjfumLEvG45Reb8DW"
    "1javnr/IhdcvEwQB9737Hg4szCMQ9AdD9np9rly5RlEWCAQzMzN2MWCaNgv/wiB47MXzF/xCPY/H47kJL2g8dxRr6xs/Nzc3+4WZ"
    "ma4VKUBVVlacBFaMNFNI2CV6qqrIgKpSgKGqbH5S/dikKGhXFUG7hCABU5H3e/R6fQaDIcPR2HpfBkMGw1ETgVBHMAxHYzY2tnju"
    "hZfZ2dmz6dvG8PRXn2vOwwZQ2pFtKSXLy3YiO8syxuPxOWPM4xcuX33yO309PR6P5+2Cbzl57jj+4W/9ytnl5WNnkjghju2ivHar"
    "RaudNLtnMAalNWVR2mQn19LR2u6NUcqmW0dRSJzEtFst4jgmCELKqmQ0HNHvD+gPhgyHQwauwtLr9RkOR3b7b1UxHI64unqd1Ws3"
    "XLyBDZhUSjUxCQA4T0+n0+HkPSdpt9sEQcD29jbra2snnn7uRT/R5PF4PN8EX6Hx3HHs7OyebbdbZ9qtxLaM4pgDBxYIo5AkTggD"
    "G1OgtUFpReYW1ymlUEpP2jthiNIRlVKUZUUU2n8uZVk6o++IwWBArz+g1+uzvbPL+vomFy5eZn19g7FrFVWVQjsjMq6NBbjXq7AT"
    "TBGHlw5z+PBhklZCFFohdvLkSU6dOnX66ede9G0mj8fj+Sb4Co3njuQ3f+VvnI3j6Iwxdurp+LGjHDt2hLm5WRdaqSnKgnSc0h8M"
    "baZTVVFVFUIKojAiSdw2YSnttmEhMAaKorBj2KMR/f6QXq/H9s4uV69e54UXX6HXH1gvTWmrP/Xm4W63S7vdavbO2IRvTRAEtNpt"
    "up0OrVaLMAxtdEJo4xekkGijUZV67Dd+6+95YePxeDxvgK/QeO5Irl1fOxuF4Wlt9HLoPDNzszNEUUQZhtY3k+eMxymDwYDKtZiM"
    "MW7cW5NluU3RFsJVdGy1pRE0wxG9/oDd3T1ev3SVl145T5pmLtLAsHBggZmZ2WaEPAxDZC2OmORNSSmb7Kja3yPdY2zkgbaPF5z9"
    "D//SX1z5+//oH/sJJ4/H47kJX6Hx3LH8Fz/9l5dfv3TlXKXU8gP33cunfuSTLC0tEoahG6fOGI/HZHmO0ZooiputwlLKxtSrXGBk"
    "nhdkeU6RF6SZXZS3tb3NK69eZG19kyzLKMsCKSWLi0vMzc0SxzFhGNi9NE7MSCFAWMEirHmnuS2EaKpBQkyEj8Ggla5303zsn/yf"
    "/7dfqufxeDxT+AqN547l1/7OP1h99KEHVpTSj62u3ji9uHho+cMffJQoiqygyTKyNKdSNn9ppgtRFLp2kEK7QMiqqhiNxvQHQ/r9"
    "AcPRiPE45crVa6xeW2M0GlMUBUpVRFHMkSOHmZ2bpZUkBGHoWlY20dvGLMDX/3+JqZgFY9DG2LwmzFTOk6oTu30opcfj8dyEFzSe"
    "O5pnX3xlFXgMeCyJo+ULFy+fa7eSZaUUWZ6T5QVKKTrtNrik7CAMmmynKIxJYpu3VCm3w6aneOXVi6xeu0FZFm5SytDtdjl8+DCz"
    "szMkSYswCglkgAzkvkRtYCJWjCEMAubmZjiwMI+qFJtbO8024VrI1EsBszQjzdK36nJ6PB7PbYsXNJ53DH/lv/0bqz/+oz/45KED"
    "82eEEJRVxebmNkopFhbm+PCH3kdZKZI4dpuDQ8IwIAwTZ9INCYMAISSPPGwYj8ds7+yilSaKYytm5mZpt1pE8cRQPDPT5e4Td9Fp"
    "txindsmeNoZWEjM/N8vS4kFmZroEQYCqKoajEddvbPD661e4vrZu22JZRpZmZFmGEMKPcHs8Hs9NeEHjeUdh4Mm1je0z/X6f3d1d"
    "tLZTRrt7PfZ6Az78wUdZXDzIgYUFgkBid9nELqLAVli0C7Z89L0P8cUvPQ0I2u027U6bxAmZOI6IwoiPrXyYH/mBTzAz06Vwm4vz"
    "LLfZT1lOmrksqDQjd5lQw8EIYzQL87NsbG6ys7PDcDiiLAuAx5976VXvn/F4PJ6b8ILG847i9/7gX5z71A9/cnXhwMLywsJC0ypK"
    "XKbSa69f5fKVVe5/97sACKMIKe1OGmMM0sYPEEUR3U4HKQPAhkdGYYh0U0pCSD7zk5/i49/7CShTijRrhEyapozH1pA8HqeMmwwo"
    "xXicsru3x7Xrazz/witsbGxSlAWdTodOp0OR5z6U0uPxeN4AL2g87ziMNk8CZ+rvk8SOVUshaCUJaZrxpa88w87eHu/nYcqiJEli"
    "tDZkWcZobKMObqxtuM2/JVEUIoTNg9LG8MM/8D18/Hu/D+iALBiPxo2ZeDQaM3Lf17eltNWf8Thlb6/P0197np2dXcBwYnmZOEnq"
    "bKoVwEcgeDwez014QeN5x2GMOWuMOQMgpCBwwZRG1HtoQg4cOMCVq2sURclDD95Hu91CKU2aZvT7A85feJ3zr71OmmYIIYjjGGM0"
    "qqo4fnKZ7//Ex4DSvqDSDEdjNje2GAxHdsPwcMjQ3c6Lgk7bLtQripJev0+W5WiluPvkCd597yl2dvbY2t6h3e6cxQsaj8fj+TqC"
    "t/oEPJ7vNK9dfL3/rntOzhvMShInJEmMMYaZboejh5cQUjIYDhFCsNfrc+PGOjfW1lldvcErr17g2edf4tq1G42YWVpapNPp2AV8"
    "RvNjP/L9HDiwgCkKdD5gc32DjY1NVq+vsb62wfrGJleuXuPCxUu8duF1yrJ0W4ITt7NGcvH1KwRhyNEjh3nw/nvJi4LrN9YQQsy9"
    "/9H3zr/w0st/+FZfR4/H47md8BUazzsSbfRZDGdO3bPMo488xNzcLHefuIs4jugPBnz+j77M1559ESkkWV7Q6w/Z29uj1+shpaTV"
    "anFwbpaZbpdWK0FIgVKK2U6XKAxZXb1OHEdUlWIwGLG1tc3V1eu8duF1Lly8zM7uLkpppBC0Wy2SJGZ2dsYt9Qs4emSJG2vr7Ozu"
    "sba+zvnzF9jb63H48BJaqzM/+WOfOvu7v/f7ftrJ4/F4HL5C43lHcvHSlf6pk3fP33338srHVz7M/Pxsk9OU5wWzMx2UVgyGIxtM"
    "GUXMzM6wuLjIwYMHmZubo9tpE8UxgQub1FqzeOgAM90Ovb0e2zt7bKxvcu3aDc5fuMgXn/oKL7z0CsPhqMlzCqOQh95zPydO3MXi"
    "ITu+HUYhaZpx8fVLjEYjLr5+me3tXQSwsHAAAKXU6ivnX/viW3gJPR6P57bCV2g871jiODqb5/mZPC+adlFVVozTjHGacs/dyxw5"
    "vMTzL77C2vomxhgEIIQESZ2vhLuFkIIwDNje3mZre4ciL+n1B2xv73L12nXKsuK9Dz/Io48+jNGGz5/7EoPBkNnZGRbm55ibmyVJ"
    "EpIk4eGHHuCpLz/N9vYOWZYRBJJDhw4ihE3pLqtqBfBBlR6Px+PwFRrPO5bXLl7qf/rHfnj+0KEDK1opVKUoipI0Td3el5LDi4c4"
    "sXycKAxdxEGJC19qxE0TLhkGnLrnbk7dczdbW9s898IrXHz9Mr3+gKXFQ3zqRz7JJ7/vz7O0eIiqqlhdXSPPC+bnZ3nkoQeYnZ2h"
    "2+kQhiEYw2A4YmNjiziOWVhYoNvtorWutwa/ePHSZW8O9ng8Hoev0Hje0ZRl+WSWZmeCIMAY7QRNxnA0pixKut2uFRwPP8Cxo4d5"
    "5vmXuX5jHQwIKQkCuS8l+6EH7+fE8jEOLy3y0Q9/gDTNMEC73abb7bhog22u31hnbX2dOI4ZjlKXyB0SxREA3ZkuH/nQ+3jtwiWK"
    "wlaQqqrCaEOlKsqifGsvnMfj8dxmyLf6BDyet5K/+td+8dxoPF4dpymjccpoPGY4HNLv9dnr9UnTFK00AsHhpUVWPvoBTp44jpQC"
    "WYsZF4vwrlMnefS9D3H48BLHjh7h4MEDzM/PMTPTRQC7u3tcvrLKq69e4I/OfZnRaEQURS5eIbSiSNglfu1WiwMHFrj/3adcRaai"
    "KEryIifLcsqy9IZgj8fjmcJXaDzveHq9wZNxHJ0xRpPnBb1en9Xra/T7A44eWaJSlfXNADPdDt/9kQ/S6bzMpcurCCEJpGT5+FE+"
    "8xM/yuGlRYzRJHFMmmVsbm6zvbPDaDRmMBxx+fIqr5y/SK/XJ4pC4iQmiWO01s35yEASxzEz3S4feN8jPP/iK1ZYaY2qbFClDKRv"
    "N3k8Hs8UXtB43vFs7+ycjaLojJSCLMvZ3NzmmWdfwBj4ro9+AFUppDTYfGxJd6bDn/v4R3n3u+5hY2ubE3cd58Mfeh9Hjx4mTmJn"
    "FhYsLMwzNzfrxrUv8dzzL7O716MsS4IgYGFhAVwu1HA4YsZ5ZGQQEEUh7XaLhQML3H/fu/jyH38NrRVVWSGEOPelrz7j85w8Ho9n"
    "Cm8K9rzj+f/+7bn++9/78A9dubJ64vr1NV58+Tyj0Zg4Cnn/+x5ucp4sNsup3Wpx4q5jPPSe+3n3u08xN9slkNJmOwmoygpVVQRB"
    "gADyvGBnd5fhcESStDh06BBJkqC1ptVKuOuuI3S7HduCCkKEsEJHKUW30+FrzzxPmqZ20kqIj91Y3+i/VdfL4/F4bke8oPF4gM98"
    "+kfnZCB/6Nr1Nfb2egghiOKY+959inar5XK2LYGUBKENqEzi2C3DkwjAGE1VKYqiIMtziqIgDENmZ2ZYXj7Ogw+8m7nZGXr9AUop"
    "giBgdnaWH/zk9xBF1hBcP58xoJSNU+j1+lxdvYYQ4rNPP/eC3z/j8Xg8N+EFjccD/Luf/pSYnen+1Inl43Y0W0qSOOHggXnm5+eo"
    "57SNMSAEQgiklO6wckdrQ1VV5EVBlmakadakaWdZZoMsi5I4ioiikNE4Y3Z2lg+8/718+jM/TjuOGI9ThBAEMsBgd85UlV3s9/RX"
    "n3n8q8+/5HfPeDwezxvgPTQeD/Cf/swvnPu7v/45yrLinpMn2NrexQhDaieKAIMxhiCwQZZgmt81xrhtwiECuwG4KEubzD1K7dRU"
    "f0hvMKDfHzAajWklCR/50KMcPXqUH/93fgBkl7m5kt3dHkVeYLCvUZYl/cGQ6zfWOHz4yDl46a26RB6Px3Nb4wWNx+OI4/jJVis5"
    "fejQAebmbFuoLEsqpQAw2qB1gFLKbustK6qyoigKksTukQHbJipLu89mNJ4Imn5/wPrGJpeurNLtdviuD3+AD33gEaqqYuvqa4zH"
    "Y7IsoyhKhqMRg8GQjc0trl69zjPPvkiapn5U2+PxeL4BXtB4PI4oDFfb7TZ5XnDvqZN87dkXMMaglabUxmYvmboyYyswaZoyGtm4"
    "giAMEdg2UeEEzXicMhgO2dnZ48LFy2xt76CUptfr88UvfYXhaMQHP/BeMFCWJUIIDIY8KxgMh1y7vsazz73E2tr6qp9s8ng8nm+M"
    "FzQejyOKwnNSijNlWXL0yBInlo8TBrYiU4dJaq2RUroIAoXSCiklkVuMBwKtFXlhBc94nHLl6nWu31gnyzK00nb4W0gWFuYB+J3/"
    "7Z/SHwwwWpMkCYcOHsBg2NnZY3X1BmVZIqX47Ft7dTwej+f2xgsaj6dGCOIkptvtUKmKe0+dpNfvo41uLDNK14ZdQ1GW5FlGnhdo"
    "F1xZG3l7vQFb2ztsb++S5XkjhjAgpeR9H3iYv/DZn+DQoQN84Ytf4fd+//+hUhqVFay//Bp5npFlGQJBp9Phy1971ldnPB6P55vg"
    "BY3H4/jJv/AfP/n7/+Qf0EoSynYbfUATRiFhYIcBDQajDcp5ajAGpTVZnnP5yjV2dnYZjsYYYyaHNmijqTtVUkpa7RbtdpsjR5YA"
    "OHZkiSNHFrl69Rp5VlAUBVpp5ubm6XY75FnuxYzH4/F8C7yg8XimkFISxRFJklCWJcZYAWMFicEYnFjRzcRTWVYkScxgOEK5NpTW"
    "9jG1kLGj2HbEOwxDtnd2uXbtOuM04/kXX+b6tRvsbO8ghGBmdoZOp4PWmvFojDbGm4E9Ho/nW+AFjcczjbCL7eI4Io5jqspNONm7"
    "3Mh2LWrsY+tgyVYr4eVXLpCOUzAKjUAI3M4am8gdhiFKKa5fv8Ef/PN/yerqDV67eJk4jjh46CBxHNtR7X6fLMuRQpC0Wm/d9fB4"
    "PJ63CV7QeDxTSCHOSSlXojBySdiFbTEZg5QCgQRhF+nVbSUrgGI67RaHlxa5dn2NK1evMR6ngBM0Qjbp3K1WCyEEr19eJc9yHnrP"
    "A+zs9sjzjJ2dXYqioKpKBIK5uTkM+CBKj8fj+RZ4QePxTCGEXJVSEoZBM7lUTzgZIxBSWGEjBG51MNoYgiAgjiO63S4LC/McObzI"
    "8y+8Qprl7nmtqEGAkAKBbT2duPcYr124xPbOHmVZoJRGAGEU0Wm3EVKANt/0nD0ej8fjBY3HcxO2EhMEgTUEhyFCiGaZXt02CgIr"
    "aoQQthWlNQBJIghDG14ppOTlVy6QOVFTV3SqsmraShcuXKKqKlsBCiStVkK71SaMQvvYquLzT33ZV2g8Ho/nW+AFjecdjxpeP41g"
    "RQqx/PRXnzk9GAwIAluhiaKw2TtTlhVSSuJYN74Zm+NkW1CNwBGSIDAcP3oErTTnL1wiyzLA3m99OG5IyT8AACAASURBVIKiKJuc"
    "pk6nTavVIgiCZpmf0hqt/+yG4F/4+Z89E0i5YoxZzfPi7Nlf+TVvLvZ4PHcs4ls/xOO5c8j3rixHUbgipDyNkCtIsYywraN8NOLL"
    "X/lqM5Zd5AXD0Yher89er89oNEYpReRMw2EYEYYBUsrm+Y2xG4WV1milKYqCq6s3uHz1GnleuE3AgKvW1CGXtdCpp6rqaIXZ2VlO"
    "nrz78d/87b//2J/k/f3Cz//silbqTFVVp7UxxHFMICXGmNWiKB97/Ff/tq/2eDyeOxIvaDx3PGa8tgzmNFKeJghWCO1G38kDDBQ5"
    "O1s7vPTyq1RVRRBIyrJiPB7T6w/Y3d1jb6/HaDzGaGsEjuKIyE05yUBO2k/GoLVpRE1VVaxvbrG+vsVwNEZr3VRzpqmX76lKUSnb"
    "ljp67Chzs3MIKZ78X/7R//qG24L/61/4ueWyKE5rrR8rynK5KAqKPAch6HTaxHFMFEYIIVGqevx/+qW/9ScSRx6Px/N2wgsazx2L"
    "KbdWgM8BKwgBQQBMixmXmq1L1HjM9vYur752gbIoSZIYpRRpljMcDNnd22N7e5fdvR7jcYpSLvLA+WwaA7Ez/BpjbMSBtJNNWmt2"
    "dvbY2NxhMBxSltX+c60rO0pZQVNVlFXFBz74fkbDEUVZEAbhk7/z5O82oua/euy/XNFKnSmr6nRRFJSFXcqX5wVploKB+YV5up0O"
    "rXabJI7rczlXVeqzn/vlv+VbUB6P547BCxrPHYcpNlcIw88hghWaQALt7g2BukWkAQVVQT4csbu3x8WLlxmPx3S7HTCQFwWj0Yhe"
    "f8D29g7bO7v0en2uX1/n4qUrRFFEt9tBSsHBAwvNVNSBhXkrdJzgCZ2o2esNrChKU4qiQrslfDYbqnKHoixLjh8/xqlTpwDIsoy9"
    "vT2iOH78yJGlq0qpx4q8WM6LgqLIKfKCvChcYGbGeDwmTTOOHTvCoYMHmZmdpd1u00oSwjAExGpVlY/94uO/6ltQHo/njiB4q0/A"
    "47mVmGr7LGH8W4j4hBUvAVbA1CJGTN12QqcsKYuCPMsZjkaMxmOSOHZ/+G1HqvbFVKpCKU0QBGxsbpFmOaPRiOFwzObWDpubW2xt"
    "7bB67QY7u3sopQhDG3CpzWT82sYiaNuaUoqiKCjLktJNQCmleODBB5pzCIOQbrdLK0lW0nT8Q4PBYG4wHDIYDBgMBvT6A3q9Hnt7"
    "e+zu7tHv91fH4/FvF0XxuDZmRQjmbIvLGpKFFHOBlKe/66MffvjcF7/kRY3H43nb46ecPHcEJls/TZKchWh50la6uQCpmYgZAANG"
    "g9Z28shtCcYYlNJEkSCKIpTWtKoW3aKgKGYwbi/Mex95Dy+9fJ5ef2AFi9bAxOhbVRX9/oDXLlzi6JElDh5coNvpoJWykQmVTeTO"
    "8nyfEVgrxal3nSIKIzcOLmyOlDFgIJAhZVmxubllQyzTnDSzYZZVVZ0zWj9+9cb6kwDX1jZ4j+FcWZZntdanq6qi1SpptVq2BRWG"
    "p3/+Z3/mqsGsfO6XfAvK4/G8ffEtJ8/bGpNvLBNFZxHR6a8XMtMfbwVUTDS8socq0VlOmqYMhkM2N7a4sb5BEke0220CKSmrijTN"
    "GAyH9PsDRqMxw+Go+f6VVy9y7foNqko1LSQAKevIA+lGvOWUGXji47EtJ9X8/uKhRR58zwNI6Tw5QjRp39Nm4n6/z0svv8zG+saq"
    "0vpJAWevXF9rRMkv/PzPrhhjvlvACogVMMtKaUajIXme02q3abdaxHFc+4E++9/99b/pqzUej+dtiRc0nrcUM15bJgxWUOo0CIz7"
    "w16WJXlRoJQ+p7VeVZU6d/ze9zV/rPXoxopoJaeR4ZmJL+bmj3MtHAxWzGis6NHuqKAsUXlOmmaMRiO2d3ZZX98EDJ1OhzC0C+6K"
    "omDohEyeZaRZzjhNGY1G9PtDNjY2efHl8wyH48YLU08zWWOwRMp6bw3NedVmYK01GDh67Cj33HMPMpBIKZFC2u3EQjbPZTcVy+m3"
    "e04K+aSQYhVYxrAiBKfrBpcUAiGlm8ACbTRFntPv9+nOdDm8tMSD97+bOI547cLr51avrf3cL//ab/iEb4/H87bCCxrPdxwzXlum"
    "lZwGHkMEy+6n9lAKKoWuSoqyRFXKxQ7YVk4YhiRJjGy3QCZMPDIwES/TSPezwn0NaKozWln/TF6Q5RnjUcre3h4bm9vY1kxCHMcI"
    "oFLKmm3TtNn0W5twRyNb3Tl//iIvvfIaeZ5TFAVFUTpRgxMiVnRpXRuUjTtrwfzCPEePHmVubq6p5tRfJ+JGNKJIuO9x1RtTv29j"
    "mqyp+opIKRFuV0696wZgPB5T5Dnf+4mP890f/RCbG5v88dPP8OLLF5BSnjPGfPbXfvO3fBvK4/G8LfAeGs93FGP2zoA8az960xUU"
    "VzVxNnWJIXKekcl2XSaL6bQBWVdcbm4zmaljWjzUt7X1ziiFqb0v7vllEBBFYbNcD2z2kjSSMAxpJQk6itCmRaeqKIoOnU5Gu20D"
    "J/d6fW6sbTTnU1UVAlelCUPrXUniZvtwtztDu92ym4fDAG0MwmhEs314egOx2L8+BxCmljKm/l/zXuon0MYgtKLeVFxnSs3PzSEl"
    "PPTAfZxYPs6g32dnZ5c4jgiCYKUoyqv/+X/yU5/92//zb/s2lMfjue3xgsbzHcHo3WWEPPf1pt1aeDSPtELFRQhYAWOavS4oEKVr"
    "owgBgcR+jOuPshvFbtpKTF5HT+1+0VbQ2OqPdr4XgxSC8Ca/ixASKW2lw2Y7gZQBYCjLiiSJCUOrxO6/7172eoNmFNs4QVanbMdx"
    "PBnlDidZUfVbx4m4uupi6p/vv0KNkDHTgqZ5rxMRJKfEkHAVHSEErSRh8dABup0W999/L9HMDEIIyrJECMmpe04wGo3p9fpP/Mx/"
    "9tOP/+qv/x2/jM/j8dzW+LFtz5uOqbZPI8NzEM9N/C5v5HmZqqzYWWmU0s0EkdaTUWdjjJVFgQARM/koC6xfpj6cuDG2lUVZ2rZW"
    "vZXXPb9SikopqrKiKEuqygZR2iwn+9zGaLefLyAMI+I4Io5CZGDv19oGW+7u9RgMh9iJJyuCklZCksREUdTkQNmWUuD8NVMCSrpU"
    "71qQyDoEU7CvSONEnm0jTa5iXdWRU94b3BZjhKCVxBw9ssg9d9/F8eNHuPehR8BUXL10hae+9FU+vvIRlu86xuxMl06nTRAEK4++"
    "9+H5c0/98R/e0g+Gx+Px3EK8oPG8qZhi8zRh9ARETPwubzSFNC1m3Ci1slM/taBRdUaSO4w2BBhEHADJ1HNloHIrXqYEDG4Tb1la"
    "025tyK0qNRE1lbtfVU7QRI2XBWgEShSFRFHkhAhNMna9Q2ZjcxutNVLa0W9bmYmmQi0lMgj2+WMQk5aQFSJyX3VFTIkSe6VqIWNc"
    "vcuqnYnw2e+lqUVNq9Xi2NHD3H3iLo4eXWJh8SR6vMfrl64wGo/5vk98nHa7RauVkCQJSRwhhFj54Pvf9+Lnv/DUi7f+U+LxeDzf"
    "Pl7QeN401Oj6aRHHTyBuFjNvdNRM/C3aCQyl1ETIKI1SFUrrploTCYOIWu41SihHVFlGWRTNxJHRyrWWtBuRrpqqTyOWbno9KSWx"
    "EyHSVUmCQBKGVuhEYYiQogmUrKqKsigxxjQRCXWbKoxCwiC01Zha0MiJmKnFyn4BQyNy9gsaYJ+YmWop4X7HiZs3XMcDzM7OcHjp"
    "EIuHDjKzcIR0sMXF1y/RHwx58IH7MHrSyqrN2EVRnv7wB9/325//wlP9W/tJ8Xg8nm8f76HxvCmMti4uC3gC+Y3GqeVN30+22Fof"
    "yWScWbutukZPfmZc3lHlqjdzQkB7Hiip3JI55RbYAZMqi8AFRipwWUtKKbSyryOkIAiDiVcmkARh0EwLGWMFRJPbpATKtads+ygg"
    "TmLuOnaUnZ09ytIGXYZB2CRz11NHshYtjsYTYwzaaIQWCGEwwrWWhBMZevJ4Aft1IrUQohE8N1MUBXu9Pnu9AUcO54CNVhiPU44d"
    "Pdxc8/paCylpt1scOXyIoiieAD72Z/pQeDwez5uI/NYP8Xj+LJgn6lHh/VNH8MbbAgTTwZFmX2tJ7zO+GmNQ2u6qydz+mL29Hmq4"
    "i0nH5HlOnudk7qi/twGOJZVSKFXtE0R1kGQY1O2kuqISEAZW4MSudRTH0b6MJjk9Xh1IwiBgYX6OAwfmCZ04CkMrdoJp/4wTQaLe"
    "TWPMPiGhzf7D1OKuGb02UxWcqfYUojEYG4MVgnXUgrEp4P3+gJ2dXfZ6fcBep/E45d533ePab5U7rPATwrbO5udmV/6bv/LYyq3/"
    "vHg8Hs+3h6/QeG45W1dfOC2kXLFFFw2iHpl+I+/MNO7nN5mBmxrDtGnW2H0upapQetKSSloJpUuqVlXV5CcFShOEmsCJrLplJeTE"
    "kGtc1cS46AOtNWEQEIQTD830xl6wYqFedlfvjgnDgKSVsHz8GGma2+cJQ4Iw3N9imjbr4hK3naCpX2O61WTPbyIL5b5Fe/u3D0+P"
    "cNtKjrFOG3c9RuMxW9u7bG3vQjkiz3JG45TZ2Rny3O7Qqf1ARk8WAAaBpCyrz+GrNB6P5zbDCxrPm8FZWfdStIGg3ulSV2G+EU74"
    "TBl0tZnKRxISEdAYXu0gVGXzj7SeyCRn0m1GpzFN/pIIbV6TDAKM1q5qYltKdVAkwoqlSqlJFaappIhGJBhn+m2EhZDNBFQrSVhc"
    "PEhelNxY25gsygtkM3kkpvpNzTlqta/lJKUEM8mHElhDsJSCQNrn2ydm6qrMzaKmCaa0lIVmr9ej1xuQjUZkeU6rFbuFgK6aVVbO"
    "iD0xZtvqkF75zKd/bOV//6e/57cJezye2wYvaDy3lNXzT68IKZaFEFbMaDVlmRFMdsO8ERWo0m7irVx1APt7UgChRBBY2aM1spRO"
    "iFhPTCFLoihidnaWKIoYDUdUVYkx2KpJYjf/RmGIDGRjCg6cKKjNvVJKK1ac/0UGAYHzvdSPM9qg6q289XSStN6aOI5otRKkFNx3"
    "7z1EUcTG1radXpqONJiewXYCrFIVqrICUApJIG2bqjYmA1bITEUgNFJlqh3V7KeZ+srUVwPkedG049I0QwjpflbYCpcTlsr5lWpP"
    "0tzcLEabM4AXNB6P57bBCxrPLUVrfdpWT6w4COqdMoFxxZla3dz80SuBDJMXjddFu6RpKYU15waB+2MuXFq1Hak2bsGdUpqytL83"
    "u7TM7FJB0dttjLlJkiDiCIIAhK18UFWgbBUIY5xZWDjviJhURsREhBgMCuWEjV3MZ5y4CdxUU5Ik1ncTRxw8eIDzFy5x/cYG1DEI"
    "LqOp8bw4VWLHyq2YC8LATlm50fF6oV896SSaPCj2iRhXRbHapV5I+AZbhNMsY35+jqqqGI3GbG3vkOe5FS+Vm/iqzdfVVJVGG5TW"
    "p9/UD5LH4/H8KfGCxnNLUVqdrsWMwaC1JDQGoY2t2ITGeWoUk5ylCnSOyXKyLCN37Y56CglhjblxnBDVgsQYkqqyHhcpKUuX/aQ1"
    "aZbRzXrQOkQ8HxFTsN907A4BRAqiClQFWhNiRYU17qqJSdeJlnrEWyvbiqn31ig1nTdlqzQQkcSxHZE+vMgrr17kwutXKMrypk3E"
    "k5HtKI5ot1uA0x6NANofe4ABjb2m+6oy9YZhNym2r1Izdbt+zmPHjqC1YjQec+TwEnNzc6ytrbvlgnavTulG35uKjVYYrfnxH/mh"
    "0//XP/tDH4vg8XhuC7yg8dwynv3S/7uslFquqoqikE3KtG3raKRSSFWBLK0oQVjTcFU1YY6Fq9AopewItTHNNFDUakHcxX5sK0SU"
    "0xaCOI4bI2/dshkOh7TKkjByAigIsH2r6Y3C0PwTCGoBwGSCKsv3t17U1OTVlIioKkVRFFROUAGuomIng8IoZG5ulsNLiywvH+PF"
    "l86ztb3bpHFPIgnseTVL8KZNws4IXVdgaoEyPb2EMYRRiAAb6lm3l9xjP/Kh93Hqnru5cuUaX3v2eQ4cmOeekyfIs5T5+Tl+8JOf"
    "QHa7LC4e5KkvfYWymIiZukpTVYrBYGQnr7Re/k58rjwej+dPghc0nluGEKwo98fdGOtNCYLATccEU+0b4bwouPgBKyDsYasC2tgY"
    "Ae1Goo0xTgS13atFICJI7LZghCQUguRbLu6rl7bIm+5ToI2t9OQFaZYxHI0onJ/EVmGqRtTARCjUra4sn5hp7fu3I9uqspEKMzNd"
    "Hn3kQU4sH+e1C5d4/dJVdnZ7lGW537g75XNpdsFQm4inWkvatpZqE7MUgk6nzUy3Q5rl9nndc3zsuz/Ev/cXPwNBm51rVyiKnGPH"
    "jrBw5Birr73K3SfuQiYx0EYrzcL8PJevXAVDs1m5rtZkWVaf1wrw+JvzafJ4PJ4/HV7QeG4ZSmlKUZHlOcqJmDCcCJrJiLIbeXY7"
    "Ueotu1VVUdWxBNCYbDG24hGPx4SzETDjXjEEGWJjFWK+rbVKqqJqdtZYY+x4nDIaja1Iqc9NqcleHCcstNaUZeXET4lSuqnOSCmJ"
    "3A4asOnbM502jz7yIHcdO8LqtTWur62zu9tj6F7Ltq/2t7iMMU08wmRYybjQy4RWnCClpNNOOLAwxwGgcMJKKcVdx4421+zAgQXu"
    "OXmC7kwHSMjzHKUqLr92kUOHDtJutzh65DBbW9vs7O5ZkVdYsVmVJTu7e7Wg8RUaj8dz2+AFjeeWUVUlda5QLWK0CtFKN6bWenlt"
    "U93QU+GQ1UTYwCSlWlXK+VUqWumYJE4Io9BON5UVSStBttogW3xzYVMrAY01IRdQFpRp2nh3irwgc1M/WZYxHA5Js7ryYkMrtdYT"
    "g4uw496Va5vVk0BSSqIoaiosRVkyTtNmYV+dAbV4aIEoCpjpdtje3rHBloMhaZo2XqL6OacrXLXYS+KYMJC0kph2q0W73WpymKSQ"
    "zsdk6A8GlKMR0dwMotPh/vvu5fkXXwFK8rxgc3OL2ZkOURxx6NAh5uZnOXHiLjY2t2w7sCwpSvt1ImiMX7Dn8XhuG7yg8dwyiqJs"
    "bhuMixRQrlrjWjxTkzj1H/sm8br2aagKOzRk/3AXQUBeFGRpRjhwLSisT6Qes6439QbTI9ZMFuDtW2AHje+kbnkp97pVWdnXyjKG"
    "ozFjt4k4TTM3zlyila3QCJeGDVApRVlMRs0DKQmjkDzP9wmZ6RHxxvdTlQyHY8bjMWmaMhqP2N3pkeUZWV6gKns96hZe3cqK45iq"
    "VWKM3YfTaiV2JF0KWkniRsdlk0G1s7PLkbmDQMLhpUOsr28w2LxBlmWkWcbDDz/A3Ows8fwBAhmQpil3HT/Giy+/inI5VVvbOzYm"
    "ovbteDwez22CFzSeW0ZeFMBErEghqAJJpCaCpk6ItkGRU4LipirNdEjCfu9NnWytnJG4cIbYiQCq98ZMAiCnowGYeuaJsbdeqle3"
    "v4qiIMtspWacpozHKeM0Jc8LN9I9ETSTttP0qLncJ0BqD5GYuj6Ve63xOGVjc4udnT1293rWr+JaXHV1phZQYRA0Sd9JYtOwSyck"
    "kyRmdqYLxrbrQjf2LaSk3Uq4unqdI8t3QRjT7XZ46MH7+aMvPMXJu+/iYysfYe7wUWxqeUg4qzmYH+Dee+9ha3uHGzfWUFqxtr7Z"
    "bFk2XtB4PJ7bCC9oPLeMLMuoRUIQqMb8W4V2DLpeADcREfsrNPUfeFWp/XlF0IiguhKS5wVplpJmeRMuWbdlguaPvstbCsNmq27d"
    "6pnerKunzqcWNWU5NXlVWJNwOrZtoKpSzbnVO2CGwxEbm9vs9QYsLMwhhODA/BwzM12SJLZbgmsPDJMtxmmacfXadfr9IZl7L1Wl"
    "mjZdp9uhlbQIAtlUjrTSlJX1x1jjryEMQ7rdjvPDuLgCbc8vEMLtkUkZ93p0DnUZuKWD/+pff55f/KX/nmb6y4ztbp6qIggD5ufn"
    "ePCB+9jr9RmOxoxG46bl5gWNx+O5nfCCxnPLyLJ8Fez0TRi6jAI37RMEYVMdqSsixuhmaqia2khbG2+ngxibaaiidEGK9o/rOM2a"
    "HSlgd7YkcWx9JO0WrantwHXitk0KmGz81XqyU6aZ5nHTVoUzxBZFQZpmFEXBzu4eu3v95o/6cDRuJoqEtK0dIQRFUdDtdprtwVHk"
    "jias0ragHnn4QbQxFLlNwd7a3mVtfROEcIv1QmeONqRpxmAwYJymjdcIJtNijQ9J2UNUAq0VnU4HBLzy6gXC8DJbW9t87ZkXuHT5"
    "Kq+/fJ5TDz6C9RYpUNpWp7IMrQ2zszO869RJer0+M90u/cGwed3v/54/t/yv/s2/Xf2OfMA8Ho/nm+AFjeeW8RP//k+d+93f+a1G"
    "0Ez7V8LAbtutqxq1B6NeUFf7WOq9LzYhWjdJ0dpVcOr9MLYFlJFlud2PF4W0O23mZmeYn59jdnaGVqtlBUFYe1dkrbEmbR/X3imL"
    "krwomiknKfNJFIJ7H8ItuUuShIMH5imKkuFwRLfTxpgWUkra7Rbzc3McPnyIdqtNp+OObodOu21Nu60WSSshccndNvjSCqz+YMj1"
    "G+tcuXqNq6s3yPIcsDEIUkpa7TbdbofhcMRoPKIsyqbyVO/QqXfmVC5CIausoDHa8NzzL7K1tcOVq9f4ytPPcs+pewhkiB2HL8EU"
    "VM78ayMRUrRSzM/NsrR4iMOHFxmNU7RWYATACuCX63k8nrccL2g8t5Qsy84Zo1eiMGyMucYYm2otpNulZxoPjd26q76+QmP2+1uM"
    "sQJIKdvKipPYtkTmZpmdnWFpaZEjh5dYWjzE7NwMrSRpPDS1IbgxA0+1ucqybDKNstxuKk5Ta5LN6q9Z7o6MylWCpke26+BLgDiO"
    "aXdazHS7zMx06XY7dNodOp0WrZatGNlMKSu0mgBsMxFuy3cd48TycS5dXuXK1Wtsbe9OCRtBGE48NGmaorW21yMIEAj3/uy0mNaa"
    "KApJs4wkjnnoPQ/w7HMvcv3GOvfddy8//R/9Je6+/z3u7AWUFVluW1u1cByNxgxHIwAOLMyz3t5sqjf4tpPH47lN8ILGc0vJsvyL"
    "WumVKrIBkHU6dO1vaSokuhY0auKhqVfs14ZT97fSWk+ssTeOIoJWiygMabVbzM/NcuTwEsfvOsbhpSVod5iMbQfYj3jA/lFul+pN"
    "BZRQ5ZRpSjpOSd0Id+YqNUVdtXF+Gq00QRgQRRGBtAKtqhRFXljx4IIp2602nXaLdrtNq5VMgjHr9pEQjbjafxja7TYL83Pcdfwo"
    "7zp1N1euXuPG2ia9fp80zalU5dpqbfIipypLpBC0Wlbk1abpsiyth6mqWJifJwwDxuOUkydPEMcxZVly8u5ldx36kKYMhsNmqms8"
    "ThmNx/T6fXo92+ZaW9/iPQ/ex0uvvEaWZhjwu2g8Hs9tgRc0nltKUZZPKqXOlNVkRNlWaUAbOwEEZtJK2rdYz7acjNvEK1zeUG3y"
    "jV3O0cxMl/m5OQ4ePMCRI0scPn4cwnkmad6GNw7ArKkjEAIggXCGaFYTzebMqQydZ00EQ17vn6l30BhNIINGmGhj7Li5a5PJQDYj"
    "1UkcE09XY5yQQWtw5mNn6AF31gKNMLYKMz83S7vVYvHQQbZ3dtnd3WNnt0evP7AL/1yIpXahkVIK2i3b+qqX/YEhy3LmZmeZm5th"
    "dfUGV1evMRyNObF8F3mRs3PtKtoZjK2AsxWa8ThlOBwxHI5I05SyLEnTlEppTt69zGuvvY42xm8L9ng8twXiWz/E4/nT8Ru//D+Y"
    "erlcHapY+2aaAEXXQqorNc2mYKUQTMavozAkSWw1YnZ2hgML8xw6dJDDS4scPXoU2T2IXaan+ZOJmW+GW7aHAqVAVeiqavbjKD1J"
    "m26CHjGTWAIxyWGSUroR64ggDCEMnUla23Tv2uvigi61nr49NfU1ZU7O84LBcMheb0Cv12c8ThtDdB3HIKXdqhwGE0+NVppxmvKB"
    "972XpaVDXLh4id3dHifvXuauu447jWXbeVVZUZR2ZH1cV2lGY4bDIb3+gNVra6xvbPHwe+7nlfMXGPSHq7//L/7liW/7Q+PxeDzf"
    "Jr5C47nlzM/Ps7OzQ1GWk2V2rkKzz+zrxIw2zkfjTKwyCAhFQCglcRIz0+0yPz/HoUMHWDx0iMWlQywuLkJrFqvJy6lXnw6g/JOi"
    "aNpPpqpNLdT7ZAisGJFa7guCbHbluPH0ZleO2yBcG3kBOwrtLoQNlbTv3Uz5g8zUXp5KTQke165LkpgoWuD/Z+/NYyzL7vOw7yz3"
    "vvdq6X0Z9hQ5Q85QHFLUyKQZSSULtihCok1xJFNSMVJiZbGFWBYSIDMGHEAIHCexAyiJOLBhxIASBHD+CBK2KVoiJZnWQjmW1dbK"
    "xbNv3dNdvVRVV3dtb7nLOSd/nN/vnHPfqybZ1TUz6vH5qNf1qvot991q6H7z+33L/Nwcji4uYG84wmQy8ZMaCga0gdy4YP9u2xbO"
    "OtRNg/X1mziyuIh+r4+yLLG1teWdZs4GO3hDrq6qbsKkZjTyGTyT8QTj8RhXr93AuXecxct7o6Un/srHl7/wG1+6cJcnPSMjI+NQ"
    "kQlNxqHi+a/8f0svvfwqRqM+xuOxb6Gm3JagE0nv01TChAmDhAaglQ/EK7RGr9/D/Pwc5ue9yLbf69FssYafyqRlk3dDZpjItIBr"
    "POmg44gQvvUb3rXlpIRM9D1ASmhEx7HELinb+tVPqHxIAv2ibdyTuhDuZ6K2iNu1ecJVlgWOHFlEr1eS3qcOmTlVVaFp/P1OUKFz"
    "2N7egRDA2toGrHM4c/oUjiwuRts83ayhvB/K4hmTm6xpGuwNh7DGYn3jJhYXFzA/P4fRaLwCIBOajIyMtxSZ0GQcKqy1KwMiIPFn"
    "FV1o43qEL+KG1i3WUv+R1hBCwDoNgdhX5IW2fRRl4Vu4WwMpG0D7pm1PaBQ8qTHJ/RQsBmYiYwDrQ+Rca2BMS2Fxgv4v+QrQaona"
    "qvil+S5Zu63178ErPpjbfQAAIABJREFUHE/gaBqTOLfSCgiXnI9oY58SCxP58YJpS5oZibIs/fQoCK5t+ByeGLVoWl8rcf36Gj72"
    "A38R83PzuH59zbu5xuNgVIqOMgdLuTw1tY/70k0ips6hbVrcWNvAwsI8xpNqBcBTh/xPKSMjI+OukAlNxqFCCLHS6/WwMD8XJhce"
    "/mLZtF4P0rZxIsCheL6R2gtrrfWN1V5gW6AsS+hCk+DVwZgWsiVxjlJePCJYR9Ni1tXEZMaSPiYKc6ePgz7Hvl/jA5KXnoKjaYx1"
    "0bmUdkfFtVWSmpxUQaSPmXZAcXbO9HFzO3c69UnLPk1rsL2zg2eefR6Dfh8QwNbWdiBGkhxbfEzRgeanRTP6JwtMxhN+/tKnPvmJ"
    "5c9/8dfzlCYjI+MtQyY0GYeN5bIsMTc3F7qOOqsYcjjFioEGV1avoyg0zp49DcATG852UVJCUX2BlDKsXrzeRkBZB2ksIKlWQBCR"
    "YX84wIrkRLczK8Bl0tCZyEyTmf0k9N+A0ABIhM8JKUkCAz1JsJ3pSJqOzJojJhSpvT0lLDHV2IfiNU3sg4rCYYeXXnoVr7x6EZde"
    "X4WUEh/589+JI0cWqNRSQUgRPtd+k6XhaOjJppLhWMhV9STy2ikjI+MtRCY0GYeGl77+b1batkVRaDjX8xMaKSFkt1ySCQNftIUQ"
    "GI7G2NnZxdEji9BaUeO2o+ey9dtSAm4bGqv5+UB3iuL8G8wE9KVTk+kMGOdcWC7xKkmIsFPq8JkZHjMVMBfeH+joZBytoFwynUkn"
    "K+nEphMqSF+ZxNRN4x1QTGZYyFv5EMCqqrz1vPEuLUPnSWmFD3/ocXz3d30Yn/3cF7FxcxNloWHL0pNGRc60UCQahcqbt25jMqnB"
    "p8RYC0mdU0Jg5cd/5JNLn/vVL+YahIyMjLcEmdBkHBqstSsAqLuojGJZISBD27UIJIE1JA+968EofoUIsf08OQmEoI0TAXq/pM+o"
    "uwPyGx3SqrDDitcxiV3cT0tib5RIyEywYaeamRQueb99/i4Yu2l9Y02XzAD7kJqZhOQkVZmnWm3rJzB17YW7TR3TjqmDqZpUVKTZ"
    "howapXRoAR8M+vjIhx/H1595HmdPn4JUxk9nBGjK5UIyc9O0GA5HuHLlGpyzUErTpM1Pu6TwwmnnsIKcSZORkfEWIROajEODc24J"
    "AP0Xu0AqO0kv+NNt11JKNE0bpiS8WkrXK3wRV7qhXBsHKU3gGgm3CCufkBWTkoQwDUms0kQayKmNMI1JhMH8UzdNXdL3TH7mkjs2"
    "KeF01sXj42cGbco0qYkrn9DPZHjFFPun0jC88XiCEaUd13UD33wuIaXvjNJaQ2kNIXwp5jPPv4RrN9bwzqVzkELAOUAIAzg/gWmb"
    "FsPRCK9dvIy5uQGstRhPqs5azAoLLTWEyIQmIyPjrUMmNBmHBmvtMtuXhZAQ0HAFwsU5rlu6ehEfQudJC6+QHOiCShdvn4tS+SmC"
    "86WWaZhdoBNh8pFMaPANJiGJloXRmc4IEX+WwKX3XPdn/rUiqUrFvW7qvRwxsf0IDU+SDK180gJPH4DXhDLNSVVRXcEIw9EYq6vX"
    "sLO7hwfPncXC/ByKooBWGoXWlHLsayTe/7734sWXXsG7ls753CCaeEXtjkNZFPjA+78NAFBVFV548bXwOZnQ0O9x+Sd+9Inlf/Yr"
    "X8hamoyMjDcdmdBkHAq+9ge/tez7mhDD5SSgqArAGOMLFUO+SrQqCwhI1UA2kjJr/AWybRpflFhNMJn0ocnS7ZyDIh3NjPsI6K57"
    "qPjREWmY0dUk94GpiUxKZjrjppk5zczPZrQ7ZLdO103pY9PnpCF7/hxN9115MXXTNL5zalJjPPEW7NFojBdfehWbm7dgjMXOzi7+"
    "3OMfQL/n6HehoFXsk3r/+x7Fiy+/isFggKLQgVRyl1YgZJQVVBS+fHM8nsTPSFMmOlE5kyYjI+MtQSY0GYcC57DkrIUTvvHZCS6j"
    "jH1MmtxKRaFRFgXasux2N8GTCNbT1E2DMUXv93o9snV7jY3viZLJamt2hsK8ISUM/DXe0CU0UysnoLs6S16+q56Z+t4Fe7PrTGZc"
    "SnxSDc40AXKpC4tIDWmIgoamqUMzNpdJvvjya9jcvI2GnE1t22Lj5i0sLMxDKgWlFJSSYS147NgRfOCx96I/6KPXK4PFOw33c9Q5"
    "RQMxnDp5AldWr3XcXExqhBBPfvpTP/qZz37+V7I4OCMj401FJjQZhwK/bpIQ/qIWfh7WNyQclVJCSQWlFbT2XU1Gm3gRp4t627ao"
    "6wbD0Qi93RJlWQYxcNu2pAuZEhrvh+lpTSA6s2uermU7HP2+hKY7ZHH7fs+khKccLFCe1dsk05CpzJl0OsP1Bg33O9WR0PjJjCcz"
    "vKYzxgt219Y38M6ld5CFXtLNC7UdHD74gfdhUlW+NkEI2OScxltMRD52dBGXr/jzMhj048SJNEjW2aylycjIeNORCU3GocA5u2Qt"
    "XfSUDBfq9OLNE5iYT+MnBVJJfzNsGeayRG/dlsJn0UhaN5VFEXJpuqSG32Wf40unCemkxt/xhCQ1MwWHU/w++bBTrx1/lt7ncLpY"
    "ZpmIgTs6mq5mZl8yk9QYcN9SVdeoyNX0zHMvYmdnN2TSNE0D07aQSmJ3b4jrN9Zx5sypcL78hMZ3U/V6JZxzqKqKpl52XyLDJZxC"
    "CLz3kYdQliWqusHu7h6qqk7P8VPIhCYjI+NNRiY0GYcCXpUIYT3xADq5KrzeCUj+618KCbpcJuYnFxw9xnhLsZLSE5peD4XWkQzR"
    "aosvvvQGXW4zbbHeZ1oT3Uzx+ftLguk5U689/bphbcQToM66KT7eW6CnMnKomLJLaGLuTFN7fdHu3h4uvb6KnZ3dMLlpmiYUW7JD"
    "avXqDXzbe9+DY0ePdsiktQLKxDWUUgbGiM7vJ72x7fv48WPQSqFpW2ilsLO7h0lVwxoLCCz9+I8+8eTnfuULmdRkZGS8aciEJuNQ"
    "YIxdVsp3Oxqabtg7aEgA+Av/jLLWDy5C6F0ihLXWQkkF5xwGgwZlUUAxqZEyZKGkbdfiDtMa//Zd/ce0rzxOamZfJ7VkT38fJj5A"
    "UmOQTGg6T+06raaD/r7ZdGZvb4jnX3wFk8mkkxjM1QnOWhgAxhhMqgqXr1zDA2dPwwHBwg3ns3fSAD2l6BiS0k3A628ElXVK4QlQ"
    "f9D3DqpCY2dnD6PRGE3bAi5PaTIyMt5cZEKTcSjglRNDiFQTMqUN4ZC78Fx/sY8XdRMcUJNJhavXb+DM6VNBh9O2LXplCV0U0FpB"
    "SU9qmNDIxM6droruaL1OdC3d3Bn6c98Bjdv3+VETw31Is1btaf0OE76UyDC5CGTGeKt207So6hobNzfx2sXLRHqirmbaGu6cPd80"
    "7VLbtsuXr1zF4x98zNdSQAQiCBHzdXhyo5RKKhNsZ7oW9FBChoJMrTWU9E3ne8MR2qZd+tQTn1j+/Bdyv1NGRsabg0xoMg4F1jo4"
    "EKMhga1zIKeOmZo+MKmJ6xibTCM4Kfj27W2sXr2Oum5w+/Y2Nm5u4vEP+g6hQb+PsvRaGr4Az0xqKMJfJOOWO9cxue5jvsFz7uRu"
    "6qyvmKBMT6Yw62hK3VAdV1MQApswfRkOx7iyeg23bm9NTW9iGzaTRaX1+ZdevfhpAPjw4x9c2RuOPnvtxjqOHTvaITBFQvqkEFDS"
    "O9JiCeY0KaNzytMwIJSR+hBBg922hbMu9ztlZGS8aciEJuNQYK2FcL7PwEn/lTUhfFGcbY5OL+Lx4tw0DTZv3cal16+Exzo4bN7a"
    "wmsXL+OR9zyEpmnR75V+3RFITRQJy1Cx0HVBzWTK3AHfSGDs0dUE7WcND8fu4n6tM5lJSyrDZGZKCBzITIvrN9axevVGLNhMtDU+"
    "vycSJdK7nOfj+9OvP3P+uz/yoacvXrry5GPf9gitwSwc/PnSWgGuDJMbntC0JlY2WOv2/dz+8ykM+n0cWVxAXdUYDkcw1q186okf"
    "Xvr8F34tW7gzMjLecGRCk3EoiBc2B+dEyGGZDoRrjUkmMd0b60R2dvfw+uVVWkHFlYyQAuPxBHt7Q+oY6qNXFn71xFMaJaFkmlEz"
    "az32uEO+zDf9O/68QEpSZu3gU03VicbG2Wjl7rqarBcDcwYMpQLfWNvA2vpN1HUdtUU2njNjTNdlBQSNS4o/+OOvPNXv91aGw9HS"
    "wsJ8OD5eH2n6/wZcKqqUhCJCY5Lm7zS/J7SUw79Ov9fD/PwcpJKwtYUzuQ4hIyPjzUEmNBmHAksCGudEop/xF7w20YGYENzW0sWY"
    "ov2TKc2l11fBQ43g/HF+ArR56zYeeOAMkR+DplcGG7fSFByX2Ln3s3VPW7y75GX6ZzNWqWRCMR3eN5tt0wnT69izkwnNdL0Bna+1"
    "tQ2sbdxEXTWJA6o70TLGJnoeR+s+/xm1UjPrnrY1T61eu/HZ06dOBsEypF81QUooTa8jENxQRlrIqemac1zlIOLJolVjr1eSIw1w"
    "zmRCk5GR8aYgE5qMQ4G1lnPVCK7TEO3JDK1QAplJCY6/ra3fRNM04ORZXs0wYarqGusbN/HQOx/E65ev4syZk5ifG1BXkQ/sY5Ew"
    "B8gJITu6Gs7DSd1MnTDAbzCeSUPwgOksmyQ4r3Mf8fOkbd9ueuXmv3ois4m6rqNoOJ3i2LjCS8XJ/pDo80mBrz37/Myq59/82z86"
    "/9j7HrnQGrPM7iv/i/MkTwoBpxTCbEcIQBgII7x7TQgIWBjrwvnk88FEjZvVqfBz+Ym/8vGlL/zGl/LaKSMj4w1FJjQZhwK+SDOC"
    "DdhaGF43kbWYpyttIDjx79Y3NsOFkQmAs1407K+7Bpubt3Hi+DE8eO4BPPPcizh96gQeOHvaZ9OkUxol/cV1H7FwDIpDxxE17WwS"
    "4fNEUoJvdD8hOEBq4yaC02n5Jt1MQubWNzZREZFxyeM6+iPDJZ/onO/0gIUQdxTjrq3dfLqqquVBvx9Fy+zyIv2RExJORoFz/Jzd"
    "1V1nCmXjNC0ckwOszcnBGRkZbzwyock4FHArNF9lefoQnDodMtPuc/MX9KquA5kJDqhwofTll3XdYOPmJk6eOI73PvpuPPvcS7i9"
    "tY2lcw9gcXGhIxBOb0EsLKdJTZJbM/0VyXSFLu6diQy666bZn6M7oUmdTbRu80TmJuq6mXnMTOAeJw93z364x4RMCPFv7/S7+uK/"
    "+K3zf/H7vnt1YWFhqeDzaqe8XvT5A+Hj7/kdO6u1ZBVGhOv21nZ8MecyocnIyHjDkQlNxqGArdfpRc5MEZpmhsyYDsFZW7/ZTRdO"
    "bM9MkNrW62r29kYYDkc4c/okqkcewuuXr+KlVy7i6NFFPHjuAfR7PeqNoglN0l80M6lJRcMJwWHvOU9X6IPOEBpMEZjOamlKW8PP"
    "YyKzsbHZJTJ07rrTmXT64WZPPk+UWKgsACXlN7RLTybV+aZpniwKXyHBa7huqnPwpIM+BdivNW01T0XNu3t74XUAQFos/+gn/vLS"
    "r/z6v8hrp4yMjDcMmdBk3DN+5zfOr7QU6matCSsV7iLafyLTvd1Y25i6sNvOxdUnygCGknLNwGJ7Zxfnzp3Fg+cewGDQxwsvvoqt"
    "rR1sbe3g9KmTOHP6JHq9sqOl2S+rJtq8k/oEIRLyEv7ohgGGVYz/mzjBmZrEWNchO3Vd49LrqxgOxzPiYdshM8nzp8hMmJQk3zv6"
    "Q0qJrz/3QrBs3wGfqer6ybL0Al6A10gi6pamjq2zVprOzUkEzXt7w0BMAcBKC+vsU/AdTxkZGRlvCORbfQAZ9z8E/ArCO5pssmKa"
    "XS81lHbbUIw/p9+ur9+kyYQN7p/UCo6YKfNppdU7AazuDUeQUmJxcQHHjx3Fd37H+3Hm9EkAwMbNTbz8ykXcurU1cyzN1ISoI1Zm"
    "R1aTTJRMi9bQZ6OLd2cqkd6S9VA6xeCwwM1bt/HMcy9hbzgi0tC9Oc7ncTZYunliw+d6XwMW/8gTsm9GZvB3//7/ulpV9YWmafzn"
    "ZFGyNfsEId75Nk1mWmNwe2s7EKLkd/nkYfxby8jIyLgTMqHJuHeQQJRTYgOBaeKNo/nbtglEpm0aNG2DG2sbqOo6hO1Na2ji24gL"
    "F69cPf/M8y+t9vv9p6q6hjEWC/PzOLK4iIWFebzn3Q/hOz74GB5+aAlzcwNsbe90dDip3Tnct92ftaal1F0WOcd5SFfjEhYwYYoT"
    "Dzeua/j721tbZEmf7bcK4uf0Z2zD7up9ubYcbEHv/lhAfIt6laqqztd1jbZpAnEzgdwklvpwbmbt5YbOFRPByaTC3nAUg/t4xdYa"
    "fOqJH86kJiMj4w1DXjll3DMkaU68jmbqgkgW7UhqiMg0Tfh+bf1mJ9skljraDi8QEOFC3e/3LhhjMRyNce7cWTgKdtNaoSg05ucG"
    "OHXyBNnJp8mFP1bOqdFaUdqwBJMEpWR08nSC7ygTB4Bji7RIdTdp4JyDsIbWTA0uX7nW0ad0XFJdhUo80A6LcdM/jGeG3U1SrD7z"
    "wkvfUt3Ak//Nf//0//b0P/iMUgoO8J+ZhdAu5giZJL2Y6xBmRd4Gpm2xtr4RyBofrpVh4pQLKzMyMt4wZEKTcc9IqwW8cLeNK4jO"
    "qscTmZqmNXXjL/JVVSXajHRlE+3EAPDKpdfDKmVubm65rmtUVQ2tNAaDPgQEFLVI11WN5g5dREp50lMWBYqiQFFoKO3FsXAu9ELF"
    "aQzbz2PjtbMWUkloFRu//TmIAmZjrP+cdQMpBY4dO4pbt7YA2BliE9N3kfCZ2V6paThyfvHvQQr5TddNKZqmfbqu6yf9707N2LH3"
    "XSu1bScskX/H48kE6xubHX0RAIioqVr6sR/55PIv/+oXc79TRkbGoSMTmox7Rmi4hoB1rlt1QF+btkFTt6ibBk3tycz29g5NZ5Lp"
    "B09nnI1aXH/l71yoC62XAaDslb5xm6YLUgpPWLRGTasUDqFzzkErhbIsUZZF+Kq1b+3mi7mmDoB4Qe9evOFiqBz3HkkSGXtSQmSm"
    "bVHXNQpdQyuFb3v03bh67QZWr173Cb+dFVV6QgE4ASFcMgVCZ3CTPs0lx6Pk3RGa4Wh0Xir5JABopb1YGr59+05dW63xE7ewVkyE"
    "3el0ho+e3WAUBPiLAL73bo4xIyMj41tBJjQZ9wzu/pE8pSEBrNfMxKbomqYVdVOjrhu8evFyR4CaCmxTHQldvMN/1f/HP/kTS9aY"
    "Jx2AkyeO48iRRezuDlGWfu0jpYTSCrrRaBpKIrYGQggUukBZFuj1SvR6PZRl6Sc01HukpCdHzqWaoDhl4sdI6T9z6pIKDeM0pWqa"
    "BpXW0EpDKk+Ylh58B5q2xdraTfrsCC4uCIeYJEMrreRnALo2ajpHoXhTiNWvPvv8XU0/fv7v/cKF//l//PkLUohlq62fUpHDq5tk"
    "bINWxqSCbpq8jcdjrK9vxt8ZM7Vw6IEgLf/4j3xy6XO/+sVs4c7IyDhUZEKTcc/o93srbdsGK7R1LrqJaL3UNC0RGr8meuW1S6iq"
    "KlwsLblrvBiXVxbJ6iIJihMCnxFSopQS7374nTh27ChMazCeTDBQ/bAG0kqj0J6IGGshhYDW2q+byhL9vic0ZVFA0oRHaw0p/Wew"
    "xvdQKdVCKQnObFEyKcFMVk1w6EyoOqso1hg5h4fftYSmaXH79haEiE4m4YS3XqesBdN3uwF+8ZwIyG+SPXMnTKrqb0spf99QB1O6"
    "drozoTGR0DQtXrt0JVjO0+lMh4vR5xfOZQt3RkbGoSMTmox7Rq/XWx5PJr5ugC6Gxli0RGKaZM1UVTWuXV/DrVtbyUojumimc09Y"
    "z/vqxUsXAOCnf2plxQErUgocP3YUj77nYUgp0TQtHIC2baG118d4S3LU8wBe7MukRivd6X8SUqDQ2pMy62CEARAnIUxQPFlSs9oZ"
    "LuOUMqxarLUoClrXaB1uSw++Azs7uzThsXBWdAP8plXMiOm8QNQYJdOZmXbtbxV/9+//4oW/9/NPXZhzdlkrT+j4c6dN4CEkMRV6"
    "ty02N2/77JmEzPiwv5TU+HPk+53kk8iEJiMj45CRCU3GPeHi83+4UlWTpX6vh5EaUX+Sv5i3xpAo1q+Y6rrGxsYtrF69HjqJ0rJF"
    "Y42/IKYiWX9xvAAAf+2nVpYc8Bl2Fn3nd7wfZ86cwng88YWW1mI4HMEY40lHoVHSysgTmsTZpHzvE1j3AgclZLd6O7qxQ4JwDOaj"
    "kD52QzkA8I4qabuhff7iTt9L/xr9XklBf/RWojtxmT4GJjJBODwNOqaDYjwe/23n7O/3yjJMq2ZE0excC7qoFuPxBBdfvxKPPQzU"
    "eFXGhAtIQ/t+7IkffvKXv/Br2fGUkZFxaMg5NBn3BCXlk1pp9GiFo5SiizxpSZoWde0nM+vrm3jt0uWpHJNIODq1B0xm/HWS9RZP"
    "AViCEFg8soDv+a4Pod/rYdDvY2FhHouLC5ifnwtrIy8ALjDo9zA36KPf66MsS//3RER8KGDSZj2lmQn5LJ3wvCQx1yRiZgrSMx2r"
    "Mz/OdAL5gLQvSYbJT7hRY7hfaQFpfcI+qybv7lJ66aC/x194+p9cGI3GTw9HY0wmFSZVhary68GqrlFXkZTWNG0bjcZ46ZXXouap"
    "k80Tu6DSItAkEXnloMeakZGRsR/yhCbjwLj80p8sCYFlqSSKosBgMMCgP8ZwbxTWH8b6Kc3Ghicz0ymzPJ0BEC7UsSMJgAAGgz5+"
    "+j/69Iq19kmeenzkQ4/jgbOnYZ1D6RwGpk/EyBOOyXji82KcgFPOT1RCiJ13UDnrYEHheSQCFq0JDp90xeKcz9uRVoXjV8YQ6Yh5"
    "Nd7dROJnIgBVXaMiEtA0fgV2e2vbv2/aH0VwDl4gHAgMOvULjE75pl+dLf/gR//S0m9++V8dSHBb181n2rZdKYpiSSlFZG9aHOzP"
    "8WQywcuvXELdNOH8dT4P9u/Lcg5UrumWD3KMGRkZGXdCntBk3APcCkAXeiI1c3MDzM0NEueQgDEWV8iqPD2V6ehmsB+ZGeADH3hs"
    "BcBnQZkrC/Nz+AvLH4FSmoS/UeQ7GPQx6Pd9h5OQ3QsqHzW9j7GGrNUNqqrCZFJhPJ7Qbey/TiaYTCpUNLWYTCaYjOk28c+ZjKvw"
    "2PA8eo0RfT+ZTFBVNeq6xo21Dbx++WogcJHLiKnvE4j07/1Upgg5OoWfOgkBaw8++fiH/+T/XG2a9qnReIwRTWqqiqczdZjOjEZj"
    "vPjyRd+M3nGjpZMZWq8J2S0EBbnHrMEnfuhjeUqTkZFxaMgTmowDwzkXLkjeQaTQK3uYX5jHpKownlQYDUeQkvUY3clMtGd3X1cA"
    "kLQuOnniBBbm51HVdYj7//CHPohTJ0/Q63LujM+V6fXiFMRai6Zp4wtLARiK4jeGUn/JTeU/UJK/4hKxsukkCyuloLUK05E0VNAE"
    "3VDjVzV1g5rWNlvbO1i9egOj0ShZGyUpvwJwrhs4E3syycjNOh7Ov1GeMEDAf/VruQNrU/7xL/3T8z/3Mz99oW3aZcBPgeh3DWst"
    "1jc2cf3G+szzOsRRJuWfyX3+5VrrABdXbxkZGRmHgUxoMg6EF776r5ecc8tyKmCuKDX6/R4WF+bRNA0M5dGcOnkcV6/dCM9ncWu8"
    "rnOei4RSEkprDPp9nDh5PBAfIQT6/R7+wvd8pJNOHN5baxRFgV5ZoG1LT1qIvHiSIEmsGi/QbaLlSfUxHPTHYuWwclKy43DyjqDo"
    "cpoVQjcYDke4sbaBjZubU8LfmDMT3Uqzol9Bj2Py1CE0qc3af66lj3/so8tf+u0vHziNV0r5aefcFS4ThQA2N2/j5s1b4fv02BAI"
    "WSQ18fx0SR+v/Fo63xkZGRmHhUxoMg4EKYTXQCRBdoUrYmYJNVlb0sc8rhWOHFnEaxcvYzweQ0oZe5YgonNICEjlu5Xm5uYwN5iD"
    "YREtgO/4wPtw8uQJOoooOpWSyIbW0EWBomjQtkUQG1vnk3m9w8lfbK0yUES4nHMhDJDbuA2vxahTSlAKsVJEJsRsZkubTGiapsGV"
    "1WvdOgA+csGTGf/8waCPyaSix6TLMYTpC4uEvdPKEz+RTFBImwLr7JNIggjvFv/4l/7p6t/5r3/2wu7u3nLTNHj5lUsYjcfhfMOh"
    "M3FJV2DzcwNorYMGydFnZUs3r5vats2EJiMj41CRCU3GgWCsXUbQgAgoqeC0g3Nl4nZJyE5RoN/r49w7zuKFF1/F+sYmrZ1cJ4Qt"
    "XBx1gf6gD6UVTVgApTWWv/vPJwOC5OJP0x0/uSBiQzfW6QCAotUYONHXGF9MqZOJi1fDBucT4C/EMIAxJhxjrHxAiPZvSZPTNA1e"
    "euUiRqNxJ09nWh8jhMDRI4s4deoELl66AlDxAL8mn0N/82TKv3fUpYDqFiy4BNLdszblyJHFp4UQy8PhCI+97xHs7O5hOBxhMqlC"
    "UKAQAgtzcyh7JRbm56GUzwPyLqg2TL+4uDLk9BBhlNMnIyMjI+MekAlNxsHg3FJI8ZWgYkgFpxxsWaCfxPKr4ILqY35hHmVZ4qtf"
    "ew47u7sw1Kqdrll8a7a3gqeJuO9+aAnveOBMcgjAdKpuamP2qysFZVRojeYMGrYQF9aiLTR0o2PgntaodRNCAbk6wU96/EWZepOg"
    "qNLAwScLwwFW+2nQex5+F65eu4Gt7d14gIiTGSGA48eOBreW/ymtjvwjQtZNautOayb4PFgHCHJ1WWvxgx/9Syu/+eV/dVe9Tin+"
    "2//hfzn/P/13fwdKSUwmNXpliWNHj9BELKl8kJFEsgDcmDYkQ08mXktljYGxsf/JGoPf+6M/OfDxZWRkZEwjE5qMA8GSnde5qemK"
    "UtBJwmx08rCY1qf4jscVnnnuRdR13WnXBojQUD1BlNgIfOTDj4cKgXSFY6e+F4jBd4puRklYZ4PjJrUla2s9mSENTlGUQQPThIJL"
    "toTbQCxksnaBQ5jO8FSpV/awsDAfbNrsEHLOoSwLzA0GKIrCk7op4Yw+H12aAAAgAElEQVQQiOslmeTTELlhsU343FbAdddfK5gq"
    "9LxblL3y6UUpniyKCk0dU5f5HEoRyRav8RxAwugWo7H/rE3bYkh6HD+daSAoLDEjIyPjsJAJTcaB0LbtkrNF0rWEzn+1x4qBgoS1"
    "tkNwHn5oCTu7u7j0+qpvsBY2aECUlGENxJ1OR48ewaOPPNxJEuZ1kONQu0RHAvDxRM0JO3bgnHdS0QWYH8cTFx0Exk2sT6DWbknT"
    "Ixa9+vf3YXpN00AXDXotrVu4mbo16Pd7IWSvbVtUVY2W3FNekJysmRLNTDqZ8YGB8XPwtAg0MUo7o1IH2kFhWvOZsiif1NqXfHLV"
    "AZ87zuCJ9nhavRm/0ivoeHd39zCZVKEywVkDpVROCc7IyDhUHKz8JePfe/zNv/7X/o+yV9K0gJUfrks4wgSBJjA0ibHGwDqLfq+H"
    "W1vbmFRVfGHhLdu9Xom5wVxIN/nwn/sgHnvvI1POHkGEwIbSRK/XMNG9xG3eVJzovKKVNDfdQDt+/zThlh/Dzh1u6e6VJcpe6ZOH"
    "i8KLkqXo6HfSiUps5mYNjF8V8eSnaRrs7Q0hAO/U6pXhPdPXY1Ijop87HHogdDTtevQ9737utUuvP3fQ3/Fvffn3dv7S933P0bIo"
    "l30reQGtVUhg1kWSaEyHwqLopm2xtzfE66+vYm84DKsmY1pIIVb/4E+/9jMHPa6MjIyM/ZAnNBkHQriMhqJp+h9nuiA2+URiEHuQ"
    "vAW7j3e98xxGozHG4zGcAIQjK7aQnnxYn/L7wfd/W4coCWshhAuEplOnkE6DXHoswpMrE9OBpZIAp+FyBUKyygmfyYFIS9TmaOW7"
    "oLx2xitf2L3VtiYQjxAYmIionXO+UNO5kKQMAL1+D0ePLIYMHWNtZ0oTXtM5wFq/ZqJbjA4Ma6dl3OPa6dbtrc8M+v2V+bnBUlEU"
    "PuvGy2UgIKjuwYaJVNP4/J2r19awevV6yPtpjYE1hosvP30vx5SRkZGxHzKhyTgg+AIdVx3gUDgXu5j8xTwSoPSrg8PRI4s4e+YU"
    "Ll+5BmvazrqFScDZE8dx6tQJ7gDyolwAIILSGnbOxMmMTUhNSCGmPiQO9bPSQhgRCAKXZfJF2E86oi08rHUoP8d6Ja4nQACk9MnI"
    "ACClDVMUkZQ0+g8fCdOt29vY2dmFcw6DQR9HFhc67qwmsTcHd5OIxZEQU68u4vm11h6424nxi//ol1Y/8UMfferhh5Y+e3Rx0Rd6"
    "IvYzcQlp27QYjsa4uXkLa+sbqKq6U5XgaC0GiE//4Ve+nvUzGRkZh45MaDIOjGkhLli9wgQnvYh3nxnuKaVw9uwp7O7tYfPWlv+Z"
    "VrTGkWibBo8+8hAA1oxENxEQrdedMklePbF2h4+TclBYu8LTI/ZSe1JjOt1FLhAj3vB4vYxtGhiZ9BMlJCVk8XRC+zyJMtRSfWNt"
    "Axsbm6ELSWtN1meyuPd70Fp3SFoourSJRgjRFTX1ywGEOJRqgV//l18+/x986PFPHz929LMnTx5HSRUXbdtiNBqjqmvs7Y1we2s7"
    "kMi0SZ1za4TAp//k689mZ1NGRsYbgkxoMg4MTn21tEaKFmoeySRBcvTHdHGhkhKDfh/n3vEAqqrBeDzxotxCh/XUww+9s0MuLE8o"
    "ELNfWLDaNKmbxtuD47QlZsu0bRtWSQAXQLpYheCiRZsnPjEJV4aJzXQKLq+KmoZs33VDFuYWdV1je2cXly5dQU1hfoxeWYbVUlmS"
    "xX1uDkIIGKphqOsWVV2HjiUbph7Yh9HgUIPr/ugrXz//oe/4wDvXN25eEEKEyU8nAZjPr4vTMW89F6tSyqe++uwLmcxkZGS8YciE"
    "JuPA6OhZyOrkkonI9C1qbSLYQn382FE0Dza4em0NDn5iIaTE8WNHcOL40fBf/NJaGEQdCq9lPJlhV1ITxMH7CoNdbNJmvU2YLHT6"
    "pVzHoUUX506cv5haRVlyOwVSQ43be8MRLl66jL1h0uNE7jClFObmBpTX4/N35gYDHDmyGEo2rfWfczKpMByNsbs7xO7eHoZDE87r"
    "NKtxcPj+7/veld/9vd8/FCLxlX/33CqAd377+977JOCecg5LaQ4Q640AJERGnFdKfearz75woAbwjIyMjG8VmdBkHBhhQgMv5mXx"
    "a1w3MEGwUXQ7nRlDZKAoNB44expKKezsDtHr9aC0wgceey+klJ6UGAsjDa9TvF3aGLRMZMKtRWvaWECZkBabvLelFVPTxpUVT2NS"
    "AbKfDrmYvbKPXRlgy7KN5KpusDca4caN9X3rD3he1e/3goPJO5x8a/j8/ByOLC6E8D5jDKrKk6PBoI+iUACTM9PGgwi/oMOd0jCe"
    "ffHlpwE8/dij7152zn0PHJZDFKDXG60KIS48+9KreSKTkZHxpiETmowDw5GmBbDBQmyZ0CS6D2Nsh1g4azv1CLy26Pf7ePihdwIA"
    "5ubm0OuVeO8jD4N7lpTytQNOUWYLl0G2yTRkKt032MXDSsRPWrTWniQoCakMhCB9TRIAl7qlnHVhIiNl6tbicxE1OJySe2NtHWvr"
    "m6jrOkx8upk9/uuRxYWQUFySZXvQ72OO1k5lWUAqFZxRfG6UlL4Qkz5/ypVmydPh44VXLl6A74zKmTIZGRlvOTKhybhr/N5v/fMV"
    "gFdOFrCso6DyQWMpE8bnjgRyQ0Ld1tjOJAQuViQcO3oE5849gKUHz6HQCtZZ7O7uhSmEEIB0FCxH9uiw4glrpxiEl06FmExIJaGE"
    "t11ba9FqA815L0pBKomqEhBNCwP4JF84X3/ga6Viho3o6kgMTXu2d3axevVGZ30FYEYsfWRxAf1eD5J0Q0XpCU2v30O/14MudMh/"
    "AU2yfM2AJ47c7F1VNYZmhGmJsPDC4DwpycjIeNsjE5qMu4ZgS7V1sMJOR+7HoDtKyW15pUOkhAkO26J9Y7eAVhq9Xonjx47i3DvO"
    "oG1bbG1tQ0qJuq59orBDaJhmcS/rVcK6iVZOHds2ERqpJAS8bkXQ1EM7C6O1Jw+09ikLTxKapgkZKsbaIHoV8O3eitZPgF83tdS9"
    "dPzYUXzw29+H9fWb2Lh5a/YcQkBphRMnjqEovaOrLAqUZYleWaJXFtAsjE7Kt31nlvTVCXMDLC7MYzQaYzgcoaoqyrbxD34zpjQZ"
    "GRkZf1aQCU3GXYMvsNZR8J2g3BkKrWPLcsui3ITExJ8ZKmT0jEZKL4jt971+RCnfh8R9RgBoreLCRCQlNHUgMz6l1obpTPe4Q+8U"
    "PKkBvJhVq9jOzVORsvSdTqkmx1kX3EhCxig7r58xYfrUti3KXonF+Xk89K4l7O2NMByNsLc3xM7uHqSUOH3qhO9B0irYtUua0oQQ"
    "u46JqesgklL4ROW5Pubm+tjZpaoIdm0BmdBkZGT8e4NMaDLuGhyo5isNOCyYM2Jif1FnQjNFZkxI1/XrG76gD/p9DAaDUMAYHUVe"
    "GOyaBkL4lYsxyYSm7gqCOTsGSDqmyG4depKUjEF50oWKAl9qqaC1XwPVdRNEwxACOqT2RmLFtQMczMdWcs7EKcsSR48uhuyW0XgS"
    "plm+96hAUfpCzrIoqOLAHysVNFGYH4f/0XNJD9Tr9ZI8HATr+Uy1Q0ZGRsbbFJnQZBwILAgWwibfdwPlOhqahMy01OXkkumMpp6k"
    "waCPfr8XQuOkFFQaGSsFAL9WMWFCkzicEqcSgE7VQrjJOKWR9H24+ItU4RIhErs2T1Q4zZgJDei+T85VaJSCahSkbCHaJrx/WRrU"
    "TYO6pnMH+OyZvv/svV4vFDv6v3ewjkowjQ06HT63cICSEpPJpJOMTNqke04LzsjIyLgfkAlNxl3Dr3JkEPQ6AK4zOeiSF39rw/e8"
    "uuEEWSklNLt7Bn30yhJA/DupuHlawFjEFGAqpIwrp8YXICat3o4atSEEJB8rbbqYlElJFQXCdRrD/U1BKU8SpBCQNLnxwlyaTTkZ"
    "XU7UvRQKCZIUYa+B8eRFTzSMsglJ0oHQeFeTjAnG1CDOScPcWh21SS3G40nohkpJjRBi+U3+55GRkZHxlkC+1QeQcf+hk+1Cmg62"
    "OPM6iYmMSQPukvuOru68bioLjX6/j36/j6Ignk29Tmkxo+QOIa4RIDJT17xusp3uI0V6F0lTGbZuGxuJVtu23ZA9182s4TUOW615"
    "UsJdVp70+Pfi9ZiU3dA9KgcPrykpUFAF4uSFvmVReH1OIEtEZNLjbVq0bTd35/bW9myQIeETP/SxJ9/0fyQZGRkZbzLyhCbjrmFi"
    "a3KnKJE7izrN14lmpk1Se9mxI6SA1gplWaLf76Hf7wexrqB1FJOSIBRmyzSYoLD1GzQ5kfF5tB5SafN1p7iy66T21Qhun+P30w+I"
    "qMFRSgaiFTqVgraI828i4WvJjcWdVWXh05BZk8M3L+txMRhPxMyd6YoHtqrvR2hk6JpyK8hZMRkZGW9z5AlNxl0jrJKCliN+NTOh"
    "elMFjTzZoPwWpRR0oUOYXL/XI7JCj5ECUtGaJ2mbBpIaBRE1LsEtVBYoeyV6pdek9Hq9kO1SJnUCbes7liaTCuNxhfFkgvFkgklV"
    "YTKZ0M13J9WNn+RYZ8HTE/7sTVKKyeeFiUddN6iqClVd4+bNW3j98iqMMSFIryg0Cq1CnUJYXzEZ4olXYk+v+VY3uLG2QeF9lm4c"
    "WBheb/nHfuSTeUqTkZHxtkae0GTcNXhKAsU/caHmoCVdS9p6zWsdvtiHtmjpV0paeXdPr+f1I6Cpj4CfhoS1kYoXfYhYcimTkshA"
    "kigkT2vtpzRSJXkxBo1UqKoqTDxMEvbHJILv+2P1ExnOqeE6gtD3xMSmaTprsLqu6dZg9ep1bNy8xc0NwSJelmVoF+80drcGThJx"
    "shZNG0lMUzdo6LXX1m+GFm5OYJZ0XniCZq156id/4lPn/59/9vncqZSRkfG2RCY0GXeNtjVxigIRLsDB4dOxLHfbr1vT+voBISDg"
    "tSZcyNjrlX7dlOg/hKAAOyYpukXbkvZESWhL6ykpQ9+S4tRdXUBpnwjMOhXAi5qZkLTG+MlLmDJZcOoLvyf1E8WcGu3TegVEqEvg"
    "qYgxFlVVY1LRVKeuMRqP8fIrl1DXDX0meHs2pQIHITC7mhxbsgFBEy2TVjxwOnDd4Nr1NVSTypMZms4IdnYxyQNgrV1q2/YpAE+9"
    "4f9AMjIyMt4CZEKTcdcwxl6Q0gt7RUJoOquoziom3mebcbpyKoqYv8JTCgY7jpSKuTCcZxMbsCWMUp4okSaFU3+V1sH2HVcwPkhP"
    "Suk1P63PrfFTk9n39TcZRbz0FfDW8aZpAAhyODVe/JtYyl96+SI9BgAEyrLAsaNHMBgMfJBgv49eWSS5Ng5CGDjntUacbdM0Daqq"
    "RlVVYSV2Y22DEoy9Db7TN0XOMIQpjXvyP/zxv3r+//3cP7/w5v1rycjIyHhzkAlNxl3jiZX/dPXXPvd/hcYgZ6MTxzuZ0pUTTWmI"
    "1FjryNAskmmK17voQgcnEkOIrltJ6wJlGcXF3AHFriRfPKnCOsdPZ1S4uMeUYU9S2KlUlBO/4qH3lYImQErRlEd7+zjZlaQUlIXj"
    "e6CEEIkmp4DWDREhjQfPPYCNjU3UTYMzp0/iHQ+cQb/fx9zcAIN+H2WvgFK62wlFExq2w3P5ZlVVmIy9rufatTVMJhWtxdhyTuGB"
    "ieMqJDtbC2vsLwL43jf4n0hGRkbGm45MaDIOBGMMyIsTCU2aO9OajkCWrdHOWUDIMFnRWvkOo6KA5ioCzpCh92KNjKLpi9UFWu17"
    "laSSwVHEz4vrKU8oUjIjEl0Ju6m01ujXPdRNQ63apJmRKkyGQpAeYvO2g4NpbZjWcMt4Q7oha/3fFWdP48zpk+E9y7LE/NwAc4O+"
    "J3JKEwnrCoOtNTDOt2nXTYOqrjGp/K2qKqytb9CKCQBkWI3F6UyXxFF1wvLKp35k+fznfzVPaTIyMt5WyIQm40Cwzp6HwQrdDxfz"
    "/ezOvH4yLLClaYKi/ibfXUTJuM7RpAVRS5OE3SnlQ+iKwk9opJXRJk3PkaldW8kgCA6Exh8EnJXUIeW1LE3TwBi/ehIitWUrWlmJ"
    "RCjsNUStNBDCr4XKtOKh9bXchdY+GZk+u1IKvZICBEkEzW3aHeGytTCGpkAswk5D+gDMzQ1QNy2dIp7ORMs6kxtBUyVPkhwEXJ7S"
    "ZGRkvO2QCU3GgWCN9S4nh07Wyr6khi7wzlpqiBRB7Ku1F+9qpYLWw1lq8Gb7MRCErpwczJMT52hCk1zou0m/sbOpE3IHAQgXahcM"
    "FVL6ydM+ryFjfxSvuqIQ2HQ0Pr2y9L1PAFrdJlZ10dEL9XpeGMziZSlSvYslAuVIuxPD+5honTlzCju7e0Bwe6WpyjKQmfiZqZ7B"
    "2eUf/9Enlj/3K1/IU5qMjIy3DTKhyTgQrHMXhHUrLrFsp5bnmSwaa1kL7AmNFFQA6dctUnnCwP1QMY8FMWsmITWK9C3WOUjhQnM3"
    "W6J9qnC8oMuESPGUxgkB4XyaDQuAfQKwJY2PDF1PLPoFYks3f+8PLx6bDwosYJ2DMjJMnKRSKOjzepcTF1FyoF43+E8k5EbrFipx"
    "WRWFxdEji3jvo+/G9evrGE8mMwQsJTUMDuwDspYmIyPj7YVMaDIOBOfcKvcFOVoTOZsk5E5NbLj3CSDCwXkxKrmYh8mEX/mEiy/d"
    "qD2ASiu92wjWwsJCOcExe/QeXc0MkkmFEIjVAgCEE3BUsyCEgLOSXyRMc1gjxGWXM3k1bJkmYqO1RmEtDJEJmRCxsizRK0tatRVR"
    "O5Na4F2X0BhT+FVWoWFsEXqwTmiNY0ePwDmH21vb2Lh5m5Kcpyc0fObAvVLLn3riE0uf/8Kv51yajIyMtwUyock4EJx1F5wEAtuY"
    "JjdUScDTG/57JhN8ceewPJC+w1DUvxSRnkxH+lPpItUcxMfAcR0D/XC/2my+qCMpqSTi5JC8Pj3KOQQywxMUm7SJs4U8JTaAJ0eF"
    "1pAi2tB9X5PP2ymL0uuHKKQvWLadg7ACkkiVthZGa2ht/NTHWppC0UTJxqDCoijhHHD79jYMZ/0EMsPnCfzJIBxyJUJGRsbbBpnQ"
    "ZBwIn/5Pfnb1l//v/z0k9kJ02QPH9ztnO5MTvztijYogF46/kFtjYLkXyTMferFIlGyqkxESTvL7zZYyJkcDFvHyMfgQOhDRSsiS"
    "pfeg3RVPYhyJjZ1zsMZ2cnY4ONC0JhR3do/Dv5bWfuVUaC+C1oUOwX+CBNGC1lgODsopWGWDtT0tyVRKotU62NUZvV6Joihw6/Z2"
    "kn2Tnofk94NMaDIyMt4+yIQm48AQUl4QwLKTDtJOrXS47DE82OtVQgZN0LKkaxULKaMoF+xIQiyhDKSFxj2pDXs/hPJKmcxdUvLD"
    "hMama7PYtM0aoLAGoxTf1I7uSyKp7bvxacgc/MeHpbhdW+uQk8NiX14POSI+DoCFhXB+klVoHU5kanf3NRLs8PLnpN/rodcrMTcY"
    "YGPzFsbjycy5YWIEuOV7/keQkZGR8WcEmdBkHBhKytXQUq0clJUwSYEkExZ/3+cKgycvScU1t1u3poWQIqyUgsWa9S6dtVNCSDo3"
    "IIqD/VTFOgfp0unE9HNif1LUxXTLNUHHFMsiYwIy90GFvB1aQTGFEuRu0olmKJKZpIcKAhAWjiZBrDOiNw/iZikFGqWgdZusuvhc"
    "IDipev0eNjY2sbs3pHqGeG7YTfbJj//gyhe/9Jvn3+B/KhkZGRlvODKhyTgwODnXCiIc1kFZC6VYlBqD3uAAm66eeAJiox4lFQdL"
    "IX12DOBJULgY8zTFdtxVzpJqmN6jS3DoeJPyR0euq+7rpQ6tbnM2r626FQ9tZ1KTVjKkjdecMaMSMjMdesdfwzHSCoot2XwOXGgh"
    "l2hbASkTUXIywRoM+njg7GkUhcb6+iZ2dnYxqaoOeXOc3ZORkZHxNkAmNBkHRqGL80Jghe3LzrEWxsIog5YashXlsEh2OTsWC6fi"
    "WiY06BIanlzwU8E1C76/yLpYE5Cup6IFnBKNE33NN5vOdCobmgZ104ZpUOrcSgkP/2yazCgFKFXELqiQEzPlwiJw/o1zDpASEJ7A"
    "KOfglIRzKlk/AVImTithw9oM1qIoNE4ePxYeb7dtqEpIzsUKgDyhycjIuO+RCU3GgaG1T7blKgAAUQ9jDbQx0KqFVdQYDROmJr73"
    "yKBtfKy/rnVsw7aOcmQETWm6AmEmNEE/4nxyb6pLZlJjyGmllOsk/PJxsHCZpz2BrBiDpmlR175DyVhDx23CJCY6nJjMJOF+UkAR"
    "aVHUB6VUGtInpo4VnWkNnwtY6ytAO8GCXjAMhc7r8OMtW7Sdn/gcObKApmmC3ocLQnlSlZGRkfF2QCY0GQeGLtiWbGktgrDGYcKi"
    "yYnjKKeF81oM/X3dNKjrmkokY+z/TI4KEHQ3TDyYzHDBJGfGBEFymMDEoLoQqofupCZOaLramYZ6lIwxoSjSExleMXm9zQyZcRIQ"
    "CEF4iqZVMejOH/N+YuY7CZxZjyOF8G4w5+jGZZndSRafbyEE5ufnMJlUGI5GqKoavtcpr5wyMjLePsiEJuPA0EqHxupwoab/8jfW"
    "woSG7ThNYUJjjUHbcoN0HfQzgIBSJuhM9lvL8LoqrTyIZGY6d4WD6hwF+snONAlA0J+kacdRm2PpWNuon6HOJmNmbdpRCO2TjItC"
    "J44mSanDXiA94z7yB0XH1BVAR3BIILvJuuWTfH6CW8v44xdCoN/voambjpAa3rqdkZGRcd8jE5qMewITkTRin7NajDEo2jaZeFgI"
    "KpN0pKMxxqCua3+xp/WJJwCGXlPS5CZOXljrMjPJCBf6qLsJ5MS5kDAcRbZdTU26wuKAvWCjDoJhv06zpJexrktmZGjp9qWXhfZJ"
    "wFp104BhHWxicReCG7wRCIcNVvLE2dVZl01PmWZJmbEWbTJxmlT1PiQpIyMj4/5HJjQZ9wzWiQCphsaHzxVFkqZLBMCSSye1LBtr"
    "UTd+FcJlj12yBLBehNdNfqAjOiqSNL+mS1L840M/UyBfAFcgRJcQvRYSPUvQtyQ5OvDrHycFpRvH4siyLFCWBXShoZWGDF1NDt6Q"
    "RX1REBBOhM+Surl4osUOLJ68OCZd+0yUvLbIkLWci0G9wPnS5VXSG8XPl2lNRkbG2wWZ0GQcHPtUC3SnFCo4e3jlYkns6jUy8e8k"
    "XcxbmuSkjqCYa4MgzHUunbakhxJFv2HFRfZkFhlzUSWAECLMz+9oYeizcH6Mo4qBGA0j4FzsfWJCo7UO5ZMFpQFLJjOs5QnrMSRp"
    "y3QQPHGh6UwQQBMpNJyR0ykDtaHZnC3lTGQacmGNhmP6sK7DZD7+A9+/8qXf+d3sdMrIyLivkQlNxhsCR/1OgVw4G6oLUsKgpCc6"
    "fgrin2udg21btAZd+zaRHmONn44obtQGApEBQuova2BCRjAJaqd1NqCpCzMmS2TIJWsqpVRSnAlIKfYlP5ziWxQ66IAARJ2NiESG"
    "SQ0/v3P+ptZg1tKEyySEhicwJrWOJ5bztkVLxaACAqdOncDNzVudbB5+r4yMjIz7HZnQZBwqWNdBSfxJkF2sN7DWBPs1aF2VEhp6"
    "JTgLtK6NDUy0SrJEUrjUUUBwnF5433QNw9OPOBmZrVYI95N1VdTRoEOEhJAQEpBgMoPwcyY/ilZbzjnf8SRt573T9w9kpus7766d"
    "9iMz03k4Jgn4s5YqpGKuzbFjR3Bz8xZ/YNBvCPuO2jIyMjLuM2RCk3FgTM0Ugv7D/7mPWJUcN8YYOOW1MGz5lkrGJNxpJJOd8JrG"
    "enu0UknwXnx26qwKq52UUHRITvJpePMz5YQSMhIDKQFYCSdTQhM1Qaz9sc7CtS4hQt06iM77T01o+Fyk7iuTrp1MNwvHkxjjM4GA"
    "oO2R3DPhJBbm5+70q1xGDtfLyMi4z5EJTcbhgC/AYUITJzOcA2MSsbB0Di2JewGEC7zfVCVhb0xEkm8dACdFyIHh/JrAqdBd13hB"
    "cDKBSVZMkdBg9j0DEfKPD23b1sI3E8Q8mVTg7KxFC0Ck2Tf7rZqmyFXndPrxVtDSxOyd6BhL83jCa0kBAQlJn1VK6XU4wsABOH3q"
    "JDY2NpGSPwcsHfC3npGRkfFnBpnQZBwCZucqqaU4tRPzZCGsYqylVBYS2ULAiUhyUhtzemOm4V8jurD3C8uLWpcYwJfqaKb1K/yz"
    "9DGd9/aPgBAukBpvQWeNjSc2Ien4DqQGgTB1SVUkZdGptZ+tPBynBKQVABEqP+xyMRPIWJoYORw/dhQbNzfTN0rvZGRkZNy3yIQm"
    "4/CQWI5dOl3oVAvQhIbITSAIiTaFCRJf5t3UazrrJ0Be6wJYY3w9QHoYiLZrTzworI4cUvyArjsKkWBMramYmEVC4zoEio9T0LSm"
    "0zgu+GfdtRNPVYAuqUo7p4BoLYeLx8cTIiGEbxJn61X8NXhXFXVTgRxWi4vzKMsSdVV74uhFQst3+ZvOyMjI+DOHTGgy7h2Ov8QM"
    "lw4JSTQ03K5tIQKh4WlG2j7tX6h7kQ/VCeSg8sLgNAgvrq3C1ChMMqJbOW2mDo90XXJxJ9dR/MhuKrfGf2VbOK9/5B2ITUqapknN"
    "7Fc/9QEQiFD8aNPTlThR4voJECEz1kIZheNHj2BtYxPCCfaF5ZVTRkbGfY9MaDIOjP1Sd3lCwwaajgbE+qoA0xpA+DA9gNcmsbsp"
    "JSJIpzTWQTjAwgHOwkJCOjc13WAhDgLpSacrHWIUEnij7oePh+501l2pOwmppZpXQIHQyCliI7suqfB3snPf5/d1SVVcXU33WsUJ"
    "UueY/ckKxJFt45xn07YGCwvzWL+5CSd8qF+2bWdkZLwdkAlNxoGhtUZRFBBCBMFqOiGIE5qYdstN1gJe/wL4rBkpYiKv3zp1L7KO"
    "AuGsFQAsYAEIC0fBe/QDAJb+nLKNd9J249QoXY05IidAV9UipPCfVWvfMC4kABfWZ23ThPC64GqaJjbclM1CXekJjISE45ne9PIA"
    "ACAASURBVDWbiyJhKWLOjpQyJiuH1+xOflhkHJKaadUkRBsInDEGWikcP34U4nVaxRH/+6Ef+P7lf/k7v3vhDfqnkpGRkfGGIxOa"
    "jAOjrpuVucHAh845G/qKAMBYi6ZpknA5ES62V6/egAOwuLjgk4I1N1GTxVgKIGmOBhCnNsJ1HEEOjpqmKcDOdPNlXGdKtF8BZZzW"
    "xN4nT2q00lRhUKLf76Esy2DJ5s/SNC3qpoaqatSyQdu0VFpJZZhMZKSEkhIu0bqE0F4nIYQDQGJixXk2PnE5fJ/cl1MEKT0mLgad"
    "/nmrDZRqoZTC/Nwc9vaGPsPHH0ReO2VkZNzXyIQm48Cw1p5v2nalKAsU0k8wlI4hecYYVHVNZZM0SRECTdtSnosvcNTcRE1TBmn9"
    "81nbAkRpjIQg4bCHcw5SCLDRezbXpSveTfNcYgpvl+QAQFH4LqZ+v4/BoI9Bvx8ITdCktAZN0UBVVN2Q6lc4xVdYKMqmQcJlIASE"
    "dYG3sb6GiU+sjZiqj6CbVLEE05OWdDpj0EpDzd4IQXyayIySEvPzcxgOR/44gpYmIyMj4/5FJjQZB8ZwNPJN0lqhLEtPUHQBU/rJ"
    "hdYaUvqrOLttrl9fx+bmbVhrsXr1Oh5+aMk7mkKGCmCT7Be2cLNo109bpOcGdBH3WSuJHmfGhh1zcWyH1CT5OERwhBAoCk1kpofB"
    "oI+5uUEgNKHKwHk9iqx9ICALcI1RaGULGHJgJc3cXqui/ecQVGpJxyzTlGGloLSC1tqTPa2glaavCkr51RdPi4ApwmYUhGz9cVoH"
    "rVu0bSRGUikszM9hneVAAhBO5HC9jIyM+xqZ0GQcGOPRGIN+D20gL7G+wBiDpm4wHo+xNxxie2cXzz73ItY3NtE0DVpj8Oprr+P9"
    "jz2KEyeO++mOVInY1YOKCDrzAwnAkojWwVHPkvO26WldSZiaIDiunI1N1azpMcbreTQdB+uDer0SvV4PvV4JXRR+bUREBfBERrVJ"
    "HxWYyETdUHh/IKyUFGLAnhDS/ywhM16vwzeV3Gcyo+OKjt6AyZoQxp8zIjd+QtbG15cSCwvzQa8jIOCy0ykjI+M+h/zmD8nI2B9/"
    "9Sf/xnljfK8St1IXRQGlvGi2aVpMJhWGwxFefvUiNm5uoq5rTKoKk8kEt27fxp9+9Vk0pDvhMsiQepu4imbD6ZIVTdDf7BvxNxVQ"
    "Z4OextikmbqTicMrIBmnGlIFTUokSiLmvZAtmt1FJkxlEF7TsdMrmSZJKUgr499Lp2Sm8KSqoObusizR65Uoyx6KIiU7CkrHqY1m"
    "TZKSXT0O62+URK9Xdl1bs9mCGRkZGfcVMqHJuCdI6lMqCo2yV6Lf66EoCrJlew3N9s4ubtxYJwFtA9O2sMY8LSDO31hbx+7unhfi"
    "uiRQj6+z+1QFhCkOWZr9VEMHLYlN1i8x2M8SiaE8HGNgWhu6kNi1PZ0IzDkz0SVlqfmaOpRMS+WQLZq6QV03qOsaTdOgaXxZZNq0"
    "nab+RUImacUUJzFFUaAsCn9eSc9TlqXXHOk4afFfVSQrklOKZeIei0F/qaB4fm4QzzNEntBkZGTc18grp4x7QlGU0QnU60FKhUlV"
    "QQhBupIWOzu7UafiJzrnX7u8+hQAfP/Z73U31jfwwANnOk5tkf4pAD8KEaEmwYtZnc9SkQJaq5ksHCml71NKk39T15Pz5m62YXOa"
    "rmnj5KZtyZYtJSxl0bAguG48gamqCpOJnzpNJhOMxxW2d3bgnMPC/By01gBEEPOyYymKfOM6qdAaRcG3Inzlv0/rFMJCjj7XdL0C"
    "RSXT50cI9ZN0K8oSAiNeOeW04IyMjPsamdBk3BPYzlwWfiXCQlYRbNoOe3ujkHUHAFLKp/n5hdbnt7Z2VoCuqwlAqCbwPEWQtTkJ"
    "3iNS43Nb/JSDntZtR2JdMefNhNwZFurGridjDGoAsvIrNK8N8j1IOrFst8YEMjMajTEcjTAcjnB9bR2Xr1zDpKrgnMOxo0fwyHse"
    "8msgmiZ5TYsK93kyU6RrpoTM+DWeisJpIbuhei5dtCXpxSlBZAKUhP2VRRE2Zx3hUkZGRsZ9iExoMu4J/X4fZVkETUdRlOGiz51L"
    "SNZDQkq8+PIrIcBNaY2d3T3wEKazk+F7IpIaitijlFue11DCLzjATkFK181rofUOTzhC2J1zcM500oSN8WspF7436JVNstbyq6q6"
    "bjCZTDAcjbG3N8QLL76CzVu30bask3G4dWsLZ06fRL/Xg2CdUbpaSm9FSmriZMavkSIpmT4/YS41tTJLKyKC/T3RJ83PD4IoWMDh"
    "4x/76NKXfvvLq4f3ryMjIyPjzUMmNBkHxjN//OWVXq9EoQvScPiRig0XVEAqiYX5+URr4/CdH/zAyteeee48ACglMR5PwoQgXHwp"
    "dI6v25HU0PfoDnNSCEEVBIHIJGWRSQ2BFAKWSIInNCZktkycw6Sa+HVSVaHf76HQGkJIOGfRtAZ1VWM8mWB7ewevXbqCzc1bQZPD"
    "FnClFNbXb+L0qZPhHOhkraST1ZLmyYwuoHVKZlIiQyCi2CUxsVncpX1VTG7Sc4SoVQo3h2zdzsjIuG+RCU3GgcGkwDmHtjUQooGZ"
    "eD0JAJw9cxqDQR+7u0O8+NKrUErF3iSClNJrbvgH/Heu67z51mPf4rRGJvku3QlNrBPwGhv/tsZYjMdjXF69jlu3bqPf72Fhfh5n"
    "z57CqZMnKIfGC4/btkVd17h6bQ3Xb6xjPB4HzQ07pniywm3XSsqQL5NOZTSTmSlrdggJnPmIXjuEIFiOvVLOpgnIccUWVmvxl4ei"
    "LBCpzTeiiBkZGRl/9pEJTcaB0TTNiumVaE0L2UgYY1HXNYwxOPeOB3D8+DE453Du3Dvw1a8/h+s31gCf+7KCZBJgWuMvvElbNwQt"
    "k5jY3PFa223ADr2UTGymnD3Tayh2TwGeGKxeW8PW1jastdjZ2cXt21u4snoNg0EfR48s4sTxY4AQ2NrexnBvhKqqSUDcoG0NQvO3"
    "c3BOwTqNveEI2zu7OHnyRIe0KK2hlQ5JydGlhGDtBq3FxPSnDaukmD8TAgPp5vN2Et1Q0jAOAPODgT9H8XXzhCYjI+O+RSY0GQcG"
    "u33apg2upKqqsDA/jwcffR+AOQC7+PayxH/1t/5z/INf+Ee4vbUFa2z3NZLKgUBEnFfLCOGSXifXeV64D9chM8yK0kWLn9SIrqZG"
    "xPUTY3t7J3kPHxDYtgZVVWF3dxfXrq8F0uESIhE0QyKKdmOPFXDt+joeec/DpDVSwabtnU8qHBPgzwcTECltJ2vHq12YgbHQOdrJ"
    "Z7uqfM0DZ+OYZILUGf/4t87W7YyMjPsWOYcm48AwZG1umtYLZKsKTduiLAtE8rGItm2xuLiA7/6uD/HFP4iCnXMXnPXCW9pHJdkv"
    "PLGJ05tuRgyimychM2Gt5fhBnNLbndAIvgkZSE0nuC+Z7ngbuoOhVVNV1airGk3Twlr71EuvvS5evnRZAHiqKIrVfr+PHululFIY"
    "jycYjcaJBbvb0aS1gpS+yVtyejATGOdoxeXPs8+4aVA3tb9R9k0VcnD47/2toVWYtTaEAFpjPAHrWKEyocnIyLh/kQlNxoHRtgZN"
    "26JpGlR1jcnEi2j3hkPcvnYZk9uXsHfzNVy9dh1raxsYjcac1hucNNa6Vess6rqJKycmLgmR4URehkuYTJzQxDUMPz6un+gmkOho"
    "RAie4+lNJDRcR6DDpCWQoJD4JyCkXH354uVgQ3/54utPSymXtVarHcu1FLi9tY2yoHA8lQboaaoyiGm+aapvWlAZwgOtS277l2y6"
    "ZMUUVm9E6nzwoUWcdAnAr5wyMjIy7kvklVPGgdG2LdrGr1dkK9G0Laqqxmg0xu1bt+EAjEZjbGxs4vKVq1hdve4vpg6JNditOgdU"
    "dU08hP3FgHCzPU77pfiCU34TUjM90elMc8CiYRkv8nT/2LGjuHVrC1J6DYyihux0tZRCSHkBU/h3z7+4+pEPPb6slLrCKcZKKuzs"
    "DlGUnuSkeTPeZi5CfYP/cPGOny6lE6Q4nWI7u3PRtbVfTQSHFPPZlOF13PQbZmRkZNyXyBOajAPDrzXiumkyqTAcjbC1tY2NzVu4"
    "fn0N12+sYWt7m9ZO8wCAF155NZCAU6dOwTlPfIKgNoTDJaSk87PptZRLHD9T66aA7nODG4onFzQRWZif61YSqJjoK5UKExqfvish"
    "hJghNADwx1/5+qqS8mkZGq4lqqqCkjL2MLEuJhElB5MX/S+tcXCdKYzbdyrTuTnqrkocUKmNOzR123ie/vLHPrpySP88MjIyMt5U"
    "ZEKTcWAE7UZVU/z/BOPRGOPxBKZtKW7fFy9qrTAY9DE3N9chAFrrXxz0+9jd3UtyU2YD4iKxYa6SrKQwlbeSrpv2ITFRWsOkxouG"
    "lVI4cfzYjBuKKwtU0NPIkN0ihLxjEJ2Q8jOsw1FSwRhLNQ2+wqBzLKm1mo/Zus7xWxfFwqk9m0XVZl9iw69jMU0GAXDtQSSBGRkZ"
    "GfcpMqHJODCatrngCY2fzozHY4xGI4xGY9RNAwcqYKQJx8kTx6Fph/Nf/uzPLP+t/+Kv/76UcnkwN/CiVXfnizmcm7ogT01qkJCX"
    "hAAFx1NnepMQn/TiLgT6/R7m5+dnSY1MdTQ8oRFQ6s6E5vcu/OGqlPK8FP45XWcWQq/DfhOnTk2DjeckNoYn0xdjQ+nmnSY1nEvD"
    "Nm4knxsQqd4m62gyMjLuS2QNTcaBUVf1qrMOSkkYa2nlNIZpWyjlY/5Zm6KUoqRdsfxzf/NvOF/0iNAYfebMKRRae7cTwTrXYdxh"
    "QuNSwoJICoBAUlgwExxPySSnO/3B1M+BstBRGCwdnEu0KOi2fz/z/Iv7rpwYQsrzEGKF1zu+VsFAaR2PlYXPSEiGQxKVnJKP9PMn"
    "YuAZMtMVDHtC1J3S8DnhHBoiNNnplJGRcV8iE5qMA6OqmwvGWkgpYIzBeDzBcDhC0zYoeyUGgz5pVCjyv9A4cfwomqZBr9cDACjl"
    "oLVf9QzmBtjd2Y35KExSwreza6SZCQ5PZ/YRBSPyn2848dne2UVc/UwRHiCsm6T4lgacnvAkUyQQOWKNjEwIjbXBQBX7rVKt8PQU"
    "5xtpaILTKcnK6ZynZM1EhMs6lwlNRkbGfYm8cso4MH7qP/u51clkssoZK6PRGMPhELu7Q2/Rdi6Ibnlio5TGaDQK9UEQAkVR4PbW"
    "NuB891M6gUnXJNMX8zvdZsnKlHh4huzE9c5wOIp/l1z0w3UfCN84uG+aqvvbv/uvV72Ti97bujDp2W+1Nn2zLrVne3LiOmJfXidN"
    "T2d8UrBN+p3sfu+RmNvpd5JXThkZGfclMqHJuCeMx5PzTGb29obY2xtiZ2cHe3tDSs5FWDlprXHixDE0dRPi+uF8u/VXvvYcXn7l"
    "ou97usOK5O5uyUpqX4dUcks0KlvbOx3yE9xQAPD/s/fmUZJld3ngd+99L/bIzKqupau6uqv3boEQMxiMQoedkbEZjH2AAgMCSxiJ"
    "M2PwsVRizLB4GYPNOVBqBgYYC2TwGOacocaYYQAJYQ3IiMzeJHVLvVQvVV3VnbVn5RbrW+6988fdX0RmVau6qrPE/XSiMuLFW+67"
    "Eer7xff7fr8fITZEpXtFXWNnarLkaINHuDwyE5IVo6rI4LULMUnXq8mSlspfKSwZsucSPqlRWWrOZa3H5lVNjoiIiLiVEAlNxHWh"
    "0WgsjUYjDAZD9AcDXFlbxzPPvoALFy6h5CUA2Iq7piLuYDhU5fhNywOpiMRjTz6F0WgShpW8tgJ2cfeJwNWIDSp/Z5AZa76VAuvr"
    "Gx4hMp5iI8k4k7GSM2anbM/AcT+NvNo00mYv2W1VIudlN/nvBWrM7EJ708TIPYbDsZcnBhuP+5Zv+oaYuh0REXHLIRKaiOvCvfcc"
    "xl13HsLBg7dDSolXXz2LS5ev4MnPPI3RaKzXfU1oEpXpVBYlSs7ByxKccwip+jhtbPaxfPa87eDtiMZsMiO9UMqWxEbImceF5EGA"
    "c47+YIi8KGAUnTDNW8JtUcZgNqOo3myYVg8EnJumkV6tmCCLKQwvha9n1J6Rrj6N9M/nkZyAOPmql4udwRqovXuMiIiIuJUQCU3E"
    "dYFzjrd/9Vfi+9/9/XjPP/w+fNM3fg1arSYurVzBJ//yUeVptbVYVFG58WSsekCVJcqytIs8JPDa8jld3n9agZmlamzlO6l6UKbf"
    "czVcuM4QWrPqjEv1Vk9cqAhSe00owdPPPn9NIaePf+KTyxJYljAhIm8clqhM30+VpPn72PuaMgF74SbfazNjnlyoCb5bGojG4IiI"
    "iFsQkdBEXBfuvvsuHLj3XoDuwp13HsLXvONv4uu/tgdKKV599TUoW4aX6ZQk2L1rAZPxBGVRoCg0qdGL9eWVVRRl6RZ7s2hbZaWq"
    "avghGDlje4UomHNwAS44OBe6E7XAxrrxzwBOp3CLv1FpNK5qCK5gSQrVZDI08zqi4pM0q7xI540xpEbY+/MMwR7JCcNO3nzMMiC7"
    "xHVzu0A0BkdERNyCiIQm4rrQabeOiGEfwBBra+vIixK7FuZBCcVonEFIoTtX+5lOykeTF65zNC9V6EllSo0AIDC3BqGjaqjJhFe8"
    "18ExnsIhtCJTLUQ3HI5UuKkSbzEqjSM6AFQn7mv1z5gzHRdSmO7clqxIS2ZMyClsLBmQNOnIiTMG+yEmgTCsZIrwzVayhqPxlClY"
    "+uQmIiIi4hZCrEMTcV145fSr6HY6KHmJK1fWcOqVM3j2+RdBKcP8wjyGwxE6nTYIdT2TGKMYjsZIGHPhHa2EcM6xsdlHq9m070EC"
    "knjPfSJjiY0hK7zy1ygxvhqjH55SMhyNzOlRicN4yozLeCKEPPp65klKLAkhkBe5uiYRIAQQuqwdhYCk4e8LqbOp3DmcqVh6SlUQ"
    "xvKzn4xC473vk5uiKEIS43hMVGgiIiJuOUSFJuK6cHnlCk6dPoMXXzqFk6dO4+LFyxiORqjXa5ASeOLTT+Py5StYW1vHpUsreOLJ"
    "p/DKK2eQJgmyPEeuH0alKcsSq6vrLvwyw8zrFnTfg+LUjVITlrLUxKUMSYyvYJhMIJWu7e7LWEqkTf9WCo0xOT/97POvS6H5+Cf+"
    "YlkIuZxluWtV4IeU/HBSlZz4YSnrm/FDcJ5ReEqh8b060z6d2QpNrBYcERFx6yEqNBHXiyVIeUSa0BKj6HbaIJRCCoGXTyqyk00m"
    "WLmyqhpA7t6NLMsCA64xDhNKcPHSCh584F4ARqXQXQAwXVjPFZTjKhWccx1KUu9x4R6WJKkTWwKT5wXGo0nltmQwPj/riRDyev0z"
    "ZvDHR+PJ+7kQIEJA6HLApvWAoBRUbyemXLDPsuDUKeur8TKapPBIkPDnxyc1YcgpCDLZS8WQU0RExK2HqNBEXBcIsAzb94iAUeWR"
    "IYSgKEuMJxPkRQnKEuzduxcLCwvgnNvu3OaRZRlyrdJcurwSEB5bhyUgMs5zokJJTvVwoSE/YBPCBpGkbnVgWg1YIuM/D/0z5HX7"
    "Z+w1jw8GQxcOC3ouzfD8TJG3GZ4hG04Kw05+MT3XzDL05ASF9fwUdQB/65u+IYadIiIibilEhSbiuiCkVIXzPONvo9EAJQTj0RiA"
    "KvVv4JtzTRgFgGpemaaQtRSbmwOsrq5j/749Wr4gkMQdb4yxXIjAG6PIzDRsQ0lDb2yYRe2vejcZHw9cRpOnCqkD1Bkopa/LP2Pw"
    "8U98cum+ew4vcy4OUcpdw0vbHRKAoCAUTpXyhmz9Q0HdGV+hCbtrT2d3zTAHe+qMNQNLQAoRw04RERG3FCKhibguCC6WaMK8nk0M"
    "c922UmiKAlmW2c7UbkGeJjRJkqDeEDqDKMfZ8xexd89uVZOGAESHiqxvxKsfI4QqzEcs6QGq6spUmEqrGVmeYzQaOwOyXeKdIdiA"
    "qDYOy5/9/LNfkEIDAFmWHy/L8v2UUlAqLKEhUM0qJRWAcIxGVjpTTqtUoUIzldU1Q+mRUiLPC29UoSlYEo/cRERERNwiiCGniOvC"
    "t33XP1wGlAfGZDIxllg/DOccg6Hq8TQYDjAcDjEej5FlGYqiOF6WxfGiKI5PsmwpzzKURQHOOZbPnlfmXq3ClNrcW3pZStISGWJV"
    "IOmpGGHIyjPMemrGuq49o4415Mc9IKuk5gsLNxmsb2wcH43H9h78NgWzSElo6nVhtlCh8Uy/QRPLMMTkh7GqKdsIngYZTxERERG3"
    "BKJCE/GGgNCw1kytVkNeFNi1ezca9ToYoxhPJhBcPPKpRx//wKxzvPUtDx4RQvyeEAKra+sYDIbodNoQQnqExSMYFdOsIiFeplBQ"
    "vM4zzHr7rK9vWuXIT9UO07XN5Qjw+gvqBfj9P/zo0n/zti9dbjWbhxijEEK40JNQSomgAtT0vjZhJ5uu7qeqS4SZTn514NB/NJ3d"
    "5OzATp3xJBqKI9d7rxERERE3E1GhiXgjsGSqASuFhqLbaWmTMFX1ZyjF/NwcWq3Wlo0Pn3n+xeMsSY5LAEVe4MKlFbswm6QfYs27"
    "HqRrxCi9Rd4u6Cb04lfoFQJZlmM4GtkF3XhorDqDkEARQsAYuy6FBgAYpR8qTR8rXm1ZELY3mKXU+MX0XNXk7TuTB+cCXBFBq864"
    "FG7PXhQRERFxyyASmojrByHLBAREExfGGCilSFgCEKBWr4ExhjzPMRyNtjWbNhuNR6guMHfu/MWAqAAIa95herEWQehluricC82o"
    "3k2AJjCVYnozQk0ghCx/+unPX1P/pu1w7sKl43le6Lo43AshuRDRLDIT1uaZrlkTzsHsc5j7GumUbTOnIWRkNBEREbccIqGJuG4Y"
    "BYV6xuB6vQ5KKWppDVJKMMbAWILhYLCtwvEXn1paSpNkGQS4fPkK8jwPlJVwga6Yfasdqm14yflnTAaQkFIX03OyhPRSto2XRN2b"
    "0oSu1z9j8Ksf/u3lLM+Pq8J/rnnklv4Z6VSZID3bv2cvxLZliKm6DZXMJnjZVG/EjUZERETcRERCE3HdSBg7bnwglFKwhGHvnt2a"
    "yFAkSYKSqzTl7tzcI1c7H2XsOCEUo9EYa+ubqiu2t/D7GT6+UXbKO+KpHmHTRhVuGg3HjhSZjCYTb9HExkDf2xtCaABACvFIoQ3Q"
    "VZPvVB8qX7WpFtKr7jv1CEmfIiyVYn2Wvvg1fGL7g4iIiFsLkdBEXDeazQba7Rba7RY67Rbmul3s378XX/bWh5GmKRhVpKbf30Rf"
    "13zZDoTgOIFaiC9cvFRJ8w49Jrbcvx9q8c3AsuJR0aTm0uUrLj3bMwV7NtnKmAgoJdcdbjL4iX/x80tFUS6ZOjphF+0tPDBBTyZz"
    "39tkRlWIja2vg4r/GdOKjIztDyIiIm4xREITcd0YDIYoS10ojlIAEgljuG33LrztrW8BAE1qUjz1zLNXzZz5s//vvy6ZMM/Fi5ed"
    "imGr37oaNlO+EaviiEDZsFlAJl1bh5ucOlM1BTsfiVGfnvjs597QrB/O+VHVfdtTaczYp7wzW5h+t1VnZHiPnjdoY2OzQttmUJqI"
    "iIiIWwiR0ERcN/7233/X8RdfOrl8+sxrePW1ZZw9dwFXVtdACMED99+Dd37T14JSgrIsr/2khByXANY3+hhPMrUcCxmGnXzTr/QI"
    "gV/bxagznsIzHI6Csv/GRyNteo+txmL9M5S+8f9X+Wf//N8u5UWxXJbcmoLDcBOCOjNBVWDpbfMI3Wwy49XYqYxBzjDM+BncERER"
    "EbcKIqGJeEPwmc9+rvef/vMfL//JRz+BP/nYJ3Dy1GnMddtIEoaFhTl849e/A+Px+JoVjvvuPbxk+kGtrKy6cIkmMjwIQYkphcY3"
    "zwaZTkKqcFOgWjhFxqk00xlON2LeyrL8UGnSt2eqMKGvxoaXtmpl4D0QPIcja5GsREREfBEiEpqINwT/7rf+z+WPfeKTd547f+ED"
    "hAB3HjoAgGA8noBzjlotxV13HrpmQvP93/MdPUYpKCG4cOmy3W5JC3d9nPzO0kahceZZP8NJToebpEdqApVmCm+YIdjH//wvfv6R"
    "siiXuacmWbJV7aZti+pdq2/GCzMZx5CcrcrMwju/4eu2rBkUERERsdMQCU3EG4pnTrz0iBDyu1dWVrG+sY7NzU1sbvbx2aeewWvL"
    "Z6/5PFxwPPTgfSCUYnV1HUVZwtadEU6l8VsI2GwmX6Gx2xRhWFvfcIt5YJTVZMY6S6YUmjdqiqbvlXOl0lRUF+E9rt3868JVgSDz"
    "BcSRfJUqIiIiYqcjEpqINxyPf+bp4y+8dOq7T506g5OnTuPPPvFJLC49sfz4Z566ZoWGc0VoKCHIshwbG33rAZFwBEV4vZ5MnyfB"
    "w/5IvqdmfX3T1ZsJQk4AfFKj13JTmfiNqkEzCz/+0z/3SFmUrriedCEyo9j4oaarqzJ+tpZTaHw0W43KKMjUs0hnIiIibiXEXk4R"
    "NwRPfPZzxyeTyZ1CiA8IIV57/qVTV60/46MoCrzl4fvxRx/9L5BC4vLKFdy2ewEeqwkaNZqQjfA6cDujrXqe57kXbvLqs9jsH2Da"
    "Y0JMG+8b4qExEFI+IoR4v1FkqJCQHrOwJGyb0JILJ8lgnqZBUEtTjDB2tygBOdVUIlKaiIiIWwdRoYm4Yfj88y8uP/vCyx94vWQG"
    "AAhwnBCKQ3ccACEEq6vrNvziL7RKrZEBuQkIjnSqx2A4cheQTplx2T9yms/gxoecAEAI8SHOOWzbhiDtPExB384AjOB+pqHUJv91"
    "qMyQYF8Si+tFRETcMoiEJmJHglIGSgh2LcyDEorBcIQiL8IKvroLtQ2pSEdwXDjKeG10uMlXNKyEsaWUYXGjCc0Hf/JfL3MhloSQ"
    "ARnzu2uH/phwvOZl6P/xfECGruj7mJ/vmjfcX/+hEIvrRURE3DKIhCZiR6JWS013a7CEoSxLDEcqRCJRVWk8VNO7ta+Gc4619Y1K"
    "vRaEa7/xzUCrMiA3RZ3xxv5ItSO4a3EQUJPkkwAAIABJREFUmoKNQdq99ibAQo9bG4E8PxDarZZVZ8gMbWa6pXlERETEzkYkNBE7"
    "Es1mQ5MJ3bUbBMPhCISor6xvkIWv2OiF2FcxpFSeHN83Y7J+Zib/GB5AVW8qRWhu/Ar/T378nx8vyzJoxumrNNNZTFUi4ysy5omh"
    "KyFBq9VStFpNRWYs2TH/s4gKTURExC2DSGgidiRazSbSNFEqTcLAGEPJOZKEgYAEy7dZjEOE0stoPA62b+GVVQSAUN0dnIFSCkop"
    "EkZvSk0WIeQjNg3db7ZpyZvnl0G1ZI6mI5qAGUVG3ZPzAlH9d2G+q8UYw+DcQ5Of6KGJiIi4ZRAJTcSOBGXUEoo0SZAkCdI0QaNR"
    "R71eQ8ISME02CKVbkBrPW1KRYoI9rb1EdwtnDIxRS2YIITct34dzfpx7Co0hNTbcNJWA7ctT3u1YcuY9qHmo+9q79zakaWrv3f+f"
    "2RYRERFxqyASmogdicFgeEQIAQBoNOpotZrotNtoNBpoNptot5toNhuo1VIkjKmmmDZsAhsmcmtyJS6l96WEgFpFJkFiyQzzwk03"
    "r8jcP/1n/3KJl3xZBKRmRqhpViqTp8JMkRmrzlBQHUqjlGLvnt2WzFSJHaEE3/rOb47VgiMiIm4JREITsSOR58Wh0WgMKSW63Q72"
    "7d2N3bsX0GjU0WjU0Ww20Wo10W630Wo10Ww0UK/XkaYpkjTxVBZFTDrtNvbuuc0u5sZsbB8mxMSYPcYQmputVKgU7q27bwOuwKBR"
    "ZgKFqqLKUN0FnRKqXztSs6+i0lBKQY06RWgMO0VERNwyiIX1InYkCCG9tbV1CCEw1+3gtt0LuG33LtTSGiABxhgSxpAkpf6bIC0S"
    "FGmKoijUoyxRFiWKskSapmi3W7j78CGsrW9gdXUd/cFw+sJeTRoXrrq5BeZKzo8TQj6kiJQANVlKgEtVh/caBFIChEhFSiA1w1EP"
    "SQkoCCAJJGilbxXwwH1349z5iyiKEpMsD/w2IOTtN/XmIyIiIr5ARIUmYkeiKAqMJ6qxZbvVwsED+zHX7YAlDEmaoJamqNXraNS1"
    "YqNDUc2m/ttq6tdNb3sDjUYD+/ftxb33HMahOw6gUa9rJUY/qDPN+sLMzSQ1P/5TP7vMhThuFRrbqqESafIG6JMQdS9GoVFKi1Jl"
    "qFVgGGVIEoa0lqLb7eDB++/FnXcexMLCnPUuqVAUokITERFxSyAqNBE7EkKI5fm5uUMAkKYJ5ufnkKQJBBdIGIOgFEwIlNroyhhD"
    "ylPwWk31dSpLlGWJoiidYqPVGs45GKMoy65uh9CHqtKrQjiqSJ/rOyClnGk4vsH3/4gQ/AilBFIacuVCTAYmi8m+pgAEQCkBQAEh"
    "AOp+txBCICkN/p+viJIES5iq3VNyZFlulapv+9vvPPJHH/uza+7DFREREfFmIBKaiB2Jdru91Gw2jxj/SpIkUJEURV6olJCUgiUJ"
    "GvU6AL0wC1dQrywVgcnzQj9yZHmOPFN/KWX6/VK3RRBeGnRYQbiaW3Sj8eM/9bNLx/7NzyxTKg45D49TjWzkiYRUiwKQFBCCglI1"
    "ZkIBJinckQZhT6taqooZci5w+fIV1eFcEkjgCIBIaCIiInY0IqGJ2JFot1sqA4lSVRRPCJtubOiFyk4KzbtmgRZCWJUmzwtkeY4s"
    "y5FNMkxqGdLJBAljkFIiz5XfZjLJQEjYcduc781IYaaMfgjAh6rXN8+rIyIgkESRGMbCd6pwdWyk60wuBCilEEKiKAqsrq6DCwFI"
    "GcNOEREROx6R0ETsSDSbDXDO8dAD9+LkqdPgQgQeEUqJTrEOC+ABPqFRKg1jSeALkYDt89RqNrF71zzG44klQNW2AlJKe+6biTRJ"
    "jzNGP6TCR87XY4rn2aJ5lb/AdCgKgDUD255XwmsRIQQE5yCEYG6ug6K4DZNJjv5gAClx6L//lnce+uM//bMb2nE8IiIi4noQCU3E"
    "jsRoNEaiSUh/OALnHJQSEO1toaAuzZjSkLDoRdoEYxR50eSH0rBoHiVoNBrodjsYDkdhiwQh1EM9v+khlx89+tPLH/m1X1imlB2i"
    "lHj9peBSs4EZZIZUI0u6xYO0fhnTxdsqM1yg1BWYUykxP9fFcPcIo/EYQhQQQvYQw04RERE7GJHQROxInD9/AfPzc2i3m7hyZQ2T"
    "8QSMtpSPhprwEnVF5ozfxbO6yKrSIsJO3OYhpUTCKMaTia37YqrzCn3+N0OhAYAkSZcSxo5QRr3sK69pJnEEJnDTeOndlsyYcJwU"
    "QZiJcw6V+i0hJQXX7Sbm5+Zw6dIV5HkBQEYfTURExI5GJDQROxKj8QRcCNy2exdGozHW1jdQb9RBtZfGlFoxkAAolXYdF1zYbKei"
    "9DKdjEG4UI+iKDEeT3D6zLLX5VqpM0IrNIRSLD7x6TdlMWeMLSVpcoT5xe6qao3314cLL8EjdQJCUnWvnIATojuUw1VG1hNbSxMk"
    "CVNkSNxcU3RERETE60UkNBE7Es1GA6PxGI16HXv37sb5C5dw2+5dMEqFUxfUwyz4RmkwpuCiKJUheJJhPJlgPJlgMplgMskwmUww"
    "GAzxwksnkeW5JjBaodHnkFIiAZberHmglCwzqjqOhwZoamvPVDOdANtMHNbcDOkywIQAYIiMhKAERARFd1zxPkJ0/ygZWyBERETs"
    "aERCE7Ej0Wo1D5VcVfh98P578NLLr+D+++62PhhKOUpGkZSla1ng9V3ihtDkmtBkGcZjRWjG4wnG4zFWV9dx8tQZTLIMfhE7Pxyj"
    "wzqPvlnz8H3v+dHj/+l3Pxw06/SzuoLsK9clO9gP0HPCvXT2okQBQEihyYzLejIPUQnXRUREROxkREITsSNBCOmlaQpKCQ4euB2P"
    "PvYZDIcj1Os13WSRgFpyEy7eQirVprQ1aHKtyGRWoVlePo/Xzp63qozwQzKCQwhus5sIIW+qd0QCruqvZ2auhp0Yo0h0Z3JDfgAl"
    "uCg1yxQaZHqutJIFblUtm/kkVbgtzwtLav7WN3597+N//sk3Ta2KiIiI2A6R0ETsSHDOURSqqu/t+/eCMYaVK6u2O7QUphYNAWXU"
    "Lu5GYTHHF0VhFZrJJEO/P8TLp05jMBh6C3jY/FFwtZ0AoATLj336qTd1ESfKjHvEdBE3hM5PY0/TBGmaquacutkmJYrQCKmq/xal"
    "yQIDuOCgpUcCfZOwEBBc/R2ORpbgQJJDb94sRERERGyPSGgidiSEzjZaubKGdruJe++5C+fOX8Rct2vNwJxzcK2wmExlp0ao0Epe"
    "FMizAoPhEOfOX8SFi5eDlGUpXRNKAM4MfA3qzKsnHusBeP9mv4+VlbVHvuHvHLkhxIcLsSyF67TtoAhNmiao1Wqo1VKkSWoVGkKV"
    "T4YLDkKoIjJcgNLSZkSZwnrSS+EWnIMLjrW1De27USTvzSguGBEREXGtiIQmYkciYRSNRgPnz5/BlSvA3r278dLLr+Duw4fAdBlc"
    "XnIURYGy5JrccKsscM5RFiVWrqziyuo6VtfWbVjFV2MAl/YspSY0ZrsK80wRGk1kjgGyt7k5AAhw+K6DRz67+LGljY3+0Tea2HDO"
    "l7jg72eSWV+PlCpkRCmznccZY2CJflAKQqn1BRHCbRKUUVy48Oaq1A9eWqN136hYnNsqwhERERE7FZHQROxIJIkKn8zNdXHy1Gmr"
    "tqyvb2JurmMzdMqytP2Z8qJEWRa4ckURmLX1jaD+jJQiqJbr13ABYJUKANpYS4Jw06snHuuB4BgBepubAzz26afxxKc/Bykl/ubf"
    "+HJ89Vd9ee/uw4cWn1r606XNzf7Rr/uW73pDiM33vvsfHz/+H/93JCyB8IzAjKmsLpfp5LKdbO2ZoN6MR16KEmWlcWdZ6m1lgfX1"
    "DVy8dNkRRSlvcnvOiIiIiNeHSGgidiSShKFWS3H7/r3IsgyvvXYW7VYTFy5eRrvVDLJwTJuDPM/w9OdPIMuyoBquCyt5hfc8Q61q"
    "aimCTB5lvmVLAPDaC4/3pBTHpJS9zc0+nvjM5/H4k58LxvvYk0/j0Seewld/1Zfj7V/13/YO33Vo8elHP760sdE/+nXf8p3XTWzy"
    "olxKkrLn14lRSo0JFXFwwUC5AAiH1KnZQqq5KfISRZEjz3PbpNP0t7LbsgyTLMdgMMTJU2fAtfIluIAE0G63YnG9iIiIHYuoIUfs"
    "UJClJEkxNzeHuw/fhS/9kocxPz+HK6vr2iws9IIrQAkF1WqFqRInhNCZOtLWljHhF90KyVbalWY/3RrAmG0PHTpwaPnFxxcJwWJ/"
    "MOx94pOL+NUP/y4ef/JpBCWJAfv6sSeewi/96m/hv/z5XyFhrHfXXQcX/+Kjxxd/43/7hetq8Jjn2aN5nqMsC/CyRMm5VVuU+Vmp"
    "LXnhuoobI/RkMsEkm9gsr/FkgsnYpK9PMBqNMRyNMBiOsLJyBc+deAnjyUSFn4QKN0FKUEKPHPn73x4bVUZEROxIRIUmYkciz/Pl"
    "VquBVrMJSAnGKObmujjz6lls9gfodtt2sTX+jnqthrsO3YGXT50GhTIHQzXntj2gQBxhAeCIjJQ29GTquMzNdXubmwM8/pnP4fEn"
    "n/ZMuUYhUa+kJO65fvexJ5/CY08+hUMHb8e5C5d6BGTxR/7RDy4JIY/+xm/9x9et2Iwn2XFK6ftNryomRMUPpEJKSVIGPa0M6cm1"
    "GmPq8IxGY4xGIwxHY4zHY/T7Q7z62lnlNRJSm62Vx0ZKAUqUb0kIcQzAO173BxoRERFxgxHD4hE7Ek/85Ud/TwpxpDvXQZZlyPMC"
    "f/jHf4bPPv0MDuzfi8N33YGiKJRK42U18ZJjOBqr6r9Z7ikvoaLiF4yzygxg67wkaYJ6vYG3ve1LbbjKhq0C+EXppvczT60iBAIh"
    "xJIU4uhv/PbvvC5i82uP/Nxiu93q1Ws1JElii+2Z2jOJ7TyuriOlQMkFyqJAlhe2WvJoNMZoPMZoqP6ePetq8vgkybwGVGfz+fl5"
    "pLUUlNA7f////ePYeTsiImJHISo0ETsStVqKzc1N5FcKUKoUk3PnLyFhDOPxBAlTxeEmIgOEsMdJfWy71UJRlJCk0qDSPuD5aWCq"
    "17naLl5as4HfLynMoDaKjQzUmioM0SGE9Ahji+/7oR9YEkIe/c1rJDaD4eg457zXaDRQS1NLaBjzWyMwuNoyqp9VURTIsxwTUy15"
    "PMFoPMbKyipePnUGmamULBzxMyoN4MzAXHAwzgCGDwD4wLWMOSIiIuJmIRKaiB2Joih6qm5KoVUD6KrATGXcEIJmow4AmIylTWc2"
    "i2+aJlMkxofVVfQTQlSRPkNqlFtYVo7wXtmXYR0bt10VsFMcaNZ5JADSo5Qsvvc971oSQh79yH/43W2Jzf/00z/3yL/9Vz/xgbwo"
    "DtXSGpKEWbJnH4TaezLKVVEUyDShmYwzbPb7WD57HhcvrtjQkp0fk/HFvW3aniS0yRqCHEEkNBERETsMkdBE7EhkWXZI6IJw7XYT"
    "RVEgraUglCBJEhCi6tSYUBHRBEQIASooDh7Yj7X1TeR5Dq8AS3gRorw1RIdo7HmMv8Y7hJBqqMk/5Wzi444hM0gP1ZxJQAjaY0wu"
    "/vC737Uk5fbEZjKefKgsyw/lSQHmVUhWypK7vvXPeApNfzDEpctXsLzswktCp7L7faCMmdrdka7C7NpDHPr2b/2W3h/+yZ/GNggR"
    "ERE7BpHQROxIcM51F23la6nVamg06qoybpIgSRgadaXQGCJCKdX9nQpQSvHwQ/fhxZdOBf2IpO4kbT01Mow8OWKg35ZyWqxBlciQ"
    "QLHZDkEvSQIQwkCpShsnRPSkxOJ73/MDS1KIo785g9j8q5//pUd+6oM/eoQlSY8xCgLikROvfYPnK9rY6OPK6houXlrxqiSrbDBp"
    "x0FACVXnEMLeBfXCbzDnhgAR5O14E7uQR0RERFQRCU3EjoSUwGSSoVZLkec5CCHodtqgRDVgZEmCer0WZCYZUsOoSuNmlOLhB+/H"
    "mdfOYnOzb4nMFKkJLgz4YSHjt/FDSfZIu13qyr2okKHZ96X2M9qSJhSMgoKCcwEpRQ90a49NludHaVkuMqZCTFJKFLYoXonNfh9r"
    "axvIstwVF/QN0NYk7fWFogQCfvFBPV7vhpRiZYlgD8Aj232GERERETcTsQ5NxI6EEAJZlmF9YxMbG5sYDIaY63ZUv6I08ZoypmjU"
    "62g0GvpRV496HfVGHd1uG/ccvhNz3Q4oo5rwMGeopQyUmkaOxI8YeVCkJshiMuv6TP+Mex1uk/YhpSEHMjgXpUT1YSIUlNJekrDF"
    "9/3QDy6+993vsvVffvGXP7yU58Ujk0mGSZYhLwrllSkLXLq8gudPvIxz5y9i5cqqVwm4QFEWurUBt9lM0HV5JLy2EDA361UHNiKN"
    "resjj7zuDzUiIiLiBiISmogdibIsVRbTZILVtXWsXFlFvVZDu9VEvV4H8/oKEapUm1otRb1eR90nNo0Gut02DhzYj3arpdKamSY1"
    "lIJQFy4i3r8A0Gw2javXbpuy4ej3t+vbuN17puKxEE4NUoqQImwAAaWkxzSx+WFNbH7p1z7ygaIol7NM1ZcpihKQUH/1ea0iI0J1"
    "Ro1JKTOGyNnmlx5Zsy0V7Fi8kJYU+NZ3fnPsvh0REbFjEENOETsOn/6rj/VeevkU2q0mGvU6hqMRirxAmibodjtoNOqqQaXpxaRh"
    "wk6MUgiWILULtMTC/ByGw5FVM2QQV5k9jjRNg15PfkZTVXkxISc3FvtsG0Iz/ca0yqMaUWovT48xarOiAHy3EGJR6LR1qe/z0uUr"
    "KhUbAkRQgAotxHgGYuoVF5TCv6K9LiUUlBIQSlUGmFWVFIQUPcRWCBERETsEkdBE7DhQSg9JKXFldQ379u4BZRT9zQFACObmOkiT"
    "RIdlyFSUyBKCgBgQ2+hybX0DnPNrHgupKDT+9lkeGbNdYta4XA2b7VSbWed0RfkUsaFULo7zcqmesmUAhy5eWsHllSvI8wKANvMy"
    "BkolpKRhPR0zDs9PBDM8k+2ku3WbdHBCiNvfdJi49luIiIiIuOGIIaeIHYe5uW7v8F2HkOcFOBdoNZvYtWse7XYLc90Omo0G0pRN"
    "+Tu2hvKCtJoNpMk2HJ6ETwlmZzPZEBUJH4AjOb6V1i/m93rJjD2LKQlDia4/Q0EJ6ZVcHqrXati1MO/tKwMDry0W6Ld88O/UEBmz"
    "D6XOXE2prjxsiJpfmFDGvk4RERE7BpHQROxEvH1+bg533XlIG1aBer2OZqOBuW4HrVYDSZLaxRm4Bk4D6Kq6LNy4jcwwNz8XKCu+"
    "UgI4khEYfBFuMyTGESOPEMwYvb//doZjxpRvCIQgrSnz80MP3IuF+Tk7L9tFuohPYAi1DxNmYr46A2IbOdhxKZIWPTQRERE7BjHk"
    "FLHjkGVZjzKKPXt2Y3V1DZxzbeZlaDabKMsSaaq+utZDcxVGYzWWa5VHPPISHkJ0iwN93ilCJN2/0hXXc0KPOZ9Lm1bnMaRJBued"
    "pei4ayriAUrR7XZBKcUD99exsdnH2bMXMByO3JC2uO3Q66ONwjrt3YSa7EkkCe8vIiIiYgchEpqIHYfNzT7arRbSNAVjDJxzZWKV"
    "qqWBqr9CVK+hLTwuW8LfdYtV2dQNrqXpjHdlRXHZ+hwm7GNIibRkaNooHLZMmF3Mz9/XJzXD4Rj79x4EIcBkrBpVznW76PcHuHBp"
    "BRsbm4F5etZoifXOEJXGTkl4jASkrZ1ja9FERERE7BhEQhOx47C6urYkhOjV63VwzpFlOQCgVqs5g2pgclX/brVkB5rCdouw/x4h"
    "qDca07vMIDKhAOIpGtXjiFI5TFE9dy4CX/uo9p3yycv0gNW2LCvQ7XRU9+0sQVEUqNWUEbrfH+D8xUsYDkeqQrC54pTyRBSRIWT2"
    "bJo6PMF4IyIiInYGIqGJ2HEYDEfLnAvs2jUPKSXyIkee56DM+DwIRGAwMX+v4qnxj9lyNVZyCqMU/X4fC57Z1l2ChCrJjNo0Ujo1"
    "JiBTRBECE45yhXdNqMlVIZ5V5286YqaO6w9GuH3fbrTQRJIkKHJdSK/koFRVIF4hqxiOxlOEySc3JrVbv5g5XcTVGY7F9SIiInYM"
    "IqGJ2DF45dnFHoBjry2f7509f0HVgSEAowyTLMO4P0Gn3UZaS/WSOouVbB1auXZFQflIxuMxFhYWtjmTIivbhYe83eyRRKc++76Z"
    "mSEskxpt+cbsFgsAsNkf4MD+ParvVZqAUYqEJ+Cco1ZLwRjVM7aKySRTZ/MGHXTb3nIKDekyCk3UaCIiInYOIqGJeNNx6tnFHgGO"
    "AehJSOzaNY/VtXVkeaZaGNRrkFJiMp6g5CVSmaDKZyrRk+uCSteWKIsS29MgP1tpK6OwNKJPcAWpFZrQpOxlJ1XMwf77W6E/HKHV"
    "rOuwliJl6iiCTqeNslTNKtfkhg7jkWDc2/tstGRkVaarjyciIiLiZiISmog3DaefW+oBOCYhe17TQ0gpsWfPbqyvbypiwTnSNMH8"
    "whyKvLyqLjDT96ufjMbjmceEvIHYsv9OxZj2xljPC6DTmO3h9n1iXxPs3bMbu3epENaLL78C56OZPs5kFIVNMb3xzpiEfn+ITqsB"
    "AeODcddnjKHTaaMoVBiK802UhZtLm+q9bZ8GZQwmpioyiQpNRETEzkEkNBE3HSc//6keIeSYkKIHCWtElVJCEqAsOW7fvw8AMBgM"
    "wTkH5wKNRh1pkqIoiumA0zWKBabnkY/QCqP8MUlq6tzYfCW1T1V98QZgQkdTHEjj8soqLq+s4r5778JDD9w7RR4euP9urKysqurI"
    "lHgF+VSvp43NPi5cvGyVF+e3kXjp5GmMxxNXPM+rMwNt8k3TBJ1OB3lRoigK9PsDcOFI01ZkJjA9e9lOkc9ERETsJERCE3HT8PLn"
    "/rIngWNCyh6BREITEKotpjq3mQBot1u47bbdKIoS4/EElFIILpQ/pJ4iL4otr7GVwDBr7fVoSrCH6QelCAEA6QrLzXXbOHhgv3rl"
    "sZsTL57CdM2a2czm5KlXvbG6Y9Q5thq5lwelNyUJQ5qmSBhTY5IS40mOWprA9Gwyc2oK6dXrNXQ7bWS6S/d4PNm2To0/DEl0fpPx"
    "+3whJY8jIiIibhAioYm44Tj93FJPSHFMCNHrbw7w6aeewWeeehYHD+zHXLcNKYFut425bgfdThtvfetbVPqxbkaZpAmGgxEYpWi1"
    "Wljf2HwdV5eeBOOHiwyJkcG+BKopo5DCEhb/383+EJv9U3j4wXsBAnQ7bdxxYD8eevBeywk6eptJcH7hJUV2bEq2LmDnthu1RXXF"
    "ppTixIsnYSviBDVqXPE9pVypvlSD4RAAsH/fbajXkqDPla/SUEJQr9fRabcxmeTgJdcduq/N4nst3CciIiLizUAkNBE3DK+eeKwH"
    "yGMAepCqN9DTnz+B0WiChx68F/3NAZ5/4aR3hFr0v+ytX4K19XVMJhPU63Xctns3sizDhYuXUJalTdsOF9ag7zaA6WoxsxKJKrsA"
    "VBGAsuRoNqfr0Bhy8cJLp2xm0pP4/JZZTgcP7MNctwMQ4OEH78PGxiZ2LSyAEODhh+7HXKeNAwf2QQqpCgUCSJPEERwdbjLkJc8L"
    "nL94GZubA5w9d0HvowhRvz9Evz/AfLfjCuX5rRr0HDBG0WyqdgllWWIwHIGXfJvJqRqCPfNyRERExA5BJDQRbzhOP7fUI5QcA0HP"
    "EA1GKCQkvvkb3wFI6erIaFIgpUo9Xl3bwJXVNWxsbIJSgkajgXq9hrSWor6+jpWVVesbMXB1U7YvredezVi4/UwfAnBeolGv4yc/"
    "+D+Eu0iJ5XMXsLk5cGZgu/0i+v2BG5c3nhdePIUXZoalFJrNBg7dcQCQEmfPXcRwNNriXvyxzH4vSRJMJmW4t+mqreetVquh026h"
    "KAoUZYmxmADiGlQaTWr0LR+/2u4RERERNwuR0ES8Yfidj/xKr9GoHzvx0qneWx68F+Hi7RQVW2lWSi+sI9HptMAYw+raBgbDIQiU"
    "MXas07XzPMfllSuo1VI0Gg0bRplVgM7HNS3SGoQQMMZQlhz9wQg/868fwf333Y25bgdveeg+dDttHDp4O8QBPXbTgBISDz1wrw4p"
    "GXUEsIOTznOTJMxeVkqJ50+8DCElhBBglOItD90PQBGkzc2+JUwmFXuzP8C58xcrN+FmoD8YolGvIS8KCL/TN1y4izCGRqOBdqtA"
    "lhUoyxJ5XsxOn9KfjyWOMe4UERGxAxEJTcR148zzj/bWNjaP7Zrv9tRie0mlPBv/CgkrnNj05GrFWkJQSxOMxmPbkNIoHmVZYrM/"
    "QFmWGA6HOHD7fusTUQdfZZDV/O1ZII7QcC4gBMfG+ia6nRakFHjuxEuAJlmbm310ux19Rom5TgcHD6jMrIMH9oFSirluV/dw0vcq"
    "nBHYqCZSSDz4wD0QXIALgXq9ZsnPg/ffAyHUdsEFCCVo1OsQQgTbueAoSw4pJV58+TQuXLwMQCARAoUQAFxdGgIJAUBIiTRhaDYb"
    "aGeqEjMvVVjrKoEn+6LZavZ++N3v6v3mb//O0lVmPyIiIuKGIxKaiC8Yp59f6hGQYwB6u+a7IIRgfq6rPCPwKrdYJca0DHC+D7Wj"
    "K7dfq6XIshxpkiBhDMPRCKPRGEII5HmOWi1FkiY6bcfaZrce5BYp2rNBkCSJ7TpdlhxFPsbb3vow7r3nLu9+YDOz/Aq/ElB9ky5c"
    "BiEE5y9cBgDccXA/Ou02NgcDnLtwyapTDz1wD4RQc3PuwiVsbPaRJgn6gyHOnruoz6mvISUIVW0fzHz6pmI/GypNEzx432FQSpEk"
    "CUA4CAeIAIQZqxCKQNZSNJsNZFmGoigwnogtVZqKToMkSQ4xxhbf90M/uCSFOPobkdhERES8iYiEJuJ145XnVIsCAD2jaqjUZpNR"
    "5JlyK9Xm/BothKh6KtXsZkpV12fTJHGz30fCEqRpgl27diFNEkyyzKZ6h3xm61oqW+Zue0c6geUIAAAgAElEQVQSQiCF1CpNibwo"
    "cOXKGu45fKiSLOUPWpMrCcx1O5ifm1O3a5Qpfc65bge7Fub0OQzJU6Gmg7fvw8ED+5CmqTr131A+o+WzF7Cx2YfgAknCQCnVZFCg"
    "3W6h3x9o5YSAMTWfm/0BxpMMtZRBCEXOoI8jRLgQHSFglKHRqKPZbCLLcxRFiaL0/TfTE2ZITbPZMOngPdBk8X0/9INLQoijUbGJ"
    "iIh4MxAJTcQ147c//Eu9CxcuH3v8yad7Dz1wL3YtzAXGV6JXdaMoBIs9NFnQ0RafdthWh0Qd1qjXsbnZR6fTRpImoISCMoq5uTl0"
    "ux00GnWcOfNaxcoxTWSqW65qedXkiAsOxhLwktvwTtBE0qsKjKA2izECS93VmtjXEhJCClBJvZCbOqP5lxqlisIaeA/cvg/7994G"
    "zgVa7aYyVAtFgu6/724VetJkp1GvQ0j1+pXTr+K5518CIcKlbZuPQxfcM3V2kiRRpCZrIM+LqxAah/5ggK/4ii+z5OzMq+d6jLHF"
    "977nB5aEEEc/8h9+NxKbiIiIm4ZIaCKuit/5yK/0arX0WLNR762srIIQit27FypmWvVXgoBqn4hPH6bJxTQZMfvPdTtYW9/QnpoU"
    "C7vmwUuOdruFbreDeq0GyhjKsgwym0wBua2g6q1sDRMKUgRFqvND4r57D3v7uCJ7UmcOSTgjsH9/wT7SkRrikSMTepNSguhMsGoI"
    "TQLa/wIIb7BGwSIEqKUpCCWggkAQgv379uL5Ey874gKPyPhGakJAKUFdG60nWa5CfNt221SYjCf4mt5X6tRygXd89VfgmedexIsv"
    "n+5NJtnie9/zriUhZCQ2ERERNwWR0ERsiVPP/lUPEseklD0JVfDty7/sLc7TYdmDy2YypEBvRTXOo7YoWhCW2tcUgKjCdPNzXRBq"
    "HbUAgCzLkGUZAIlms4FNr8Ce9dr6fyuY6uNUWbPNYi8BpcxIAUoobtu9YH0/Tucxqcu6uotUdINSCmLCb951hBTq3ESo+zchOEib"
    "4USQQAr1vvXOaEWIUKrIBwBBoPspSTsOljBNVFSIqdlsYGF+DldW16ZaIJgaNfCIDksS1Os1NBt19NNEZTxtCUdH87ywNXLKkuPQ"
    "Hbdj/949OHn6VSyfvdAriiIqNhERETcFkdBETOGVZ51HRhKpQj5UL/TSlVVzRl+3wIXlZfSC6xMXP8ziRaVsM0YAWZ6j02ljMsnA"
    "BYcQEoPhEOsbG1hdW0er2bCLtBTCKg7Xm0tMiLpHIlWROyEEknpi3oRZyInUxeW01EKkmgshJSCNR4XYcxpep/pVqfs3fiMpXOq6"
    "kZgI1HxIKWz5mDRhFduOo4tGVZK6urEhU/v378Hq2vpUiAnV51AqTa2Wot6oo9loXIXQOJheW0VZoixL3fiSY8/uXZif6+L8hUtY"
    "ubLWK0u++Mu/+LNLT3/++UhsIiIibggioYmwOPXsYo8AqiCezeQBdATG8RKv+qyBXaj9midmd8NcAv9upcCcR0iazWbwy58yijRJ"
    "kE0ybGxsYDKeoNPtgDIKWZZTPGZLW/DVoijEZWEVZWmbZhKde+3fvyES1twrlPUFjvcEaeU2bZqgovQoMEZtWMkxoOodSEuAlIKk"
    "nlNKrdIjhfPY7N27B8+feNkLTzkVypAu1yJBpavXazW0201sbPa3myj7bLM/QKk/J15yRWq0WsM5R6vVxB21GtY2NpFlWe997/me"
    "xf/uG9+xdPbcxaMf/Mn/JRKbiIiINwyR0ETgleeWvBYFElJ4YSPi8QCdwWTNpcFZ9AJNVNDGGYMBSUwgx1MtZkKdu9loYH19A1me"
    "I8sy1NIU7XYbhFJMxhPbZ8l0nTbHvi7MIDemRowyAQskiWt9QKi+aW8yDHcR3uWNnwZ2jkz4iYDqLCQiJaRUFWFMinhIZtyxgPos"
    "Esac+iUlpK5BI7gAZVSNWThlSQqJei3Fvn17cOHCJZONZElb2LiSWNKTpgmazabO8uIzp84Xwzb7gyDkxDl3BIeLwLR8eWUVv/+H"
    "H8c3fO1X9/bctmvxdz7yK0tlWR5994+8PxKbiIiI60YkNH+Nceb5R3sAjknIniEr1h9i+QHxFlb9noDteWTgm3xtJWDzjhV6pCY3"
    "s0iNC4FMRmPkeQEpJPIsB+cCzWYD3U4b9VoN48lEe3g820xF/ZkOc20NfeugRKcXSYmEqTo499132Kk0cEZeFyBzC7y/j+ujZCZH"
    "OoLnzawJEPk9l6yZWJ8zSRLloZESEDK4jpASKWOK3BiiYx8Se2/bjQsXL+n5DVUaQ2zsNqJUmlqaolGvX7X9AgBcXrmCJEktqTFE"
    "xhT9E1KRK/dX4o8+9uc4fNcduPOO23u1WnPx3//6saXBcHT0n3zwZyKxiYiI+IIRCc1fQ5x+fsmafaHNuUTXKQnghZ3CDB6p1mcA"
    "XgzFWVQrYScCRwSg/Seuzgy0kRVWMcjzHJPJBEnCkKSpWpw5R5IkSJIEaaoW0ARJSIw84hHgmsSb0OvCmGpPsHvXAohVT6qQ1oNi"
    "DEGBHwawWU4EznNkZsY0n1Rqk94uASmFDR9JIbzrE0iilB0/5MUoVWEozl0FYa2MHDy4Hy+fOo3RaByag40C5GU+GYKTpgnmuu2r"
    "EBo1XxcvrmBhYV4RGUNiDKHyQnLVkOTJU2fw8snTOHhgP/bv29M7d/7S4j/9x+9bShJ29Bf/11+PxCYiIuJ1IxKav0Y4c0IrMkL2"
    "pFQl8dX66vs5PO+Llh78nkuB8uDt7hMZu2BbhhR2ujaEyGTkGE+KUWnGY6XQJAlDp91Gnud2sVW9ncYQXLUJMNuqqc5B+Ca8rQD+"
    "ZhMY88mGEMLNj1ZRfBO0E7KImyurSum/UoLQ0BAsZfgwxzofjCMmjTSxnbgVyZGWNDTqNRBKwTWZKXXLBs5VOEsIgT17duPV184G"
    "XpopY7D11ACMUtQb9dkTFswvkBcFsizzFJkqiXGzLG3IUoXcCAHOnb+Ec+cvYa7bgZCyxxhb/JmfeP/SaDQ5euyXI7GJiIi4dkRC"
    "89cAr554rAeCY5Cy57cbUHKA81IAyu8CSJUWTBDUTDFkxu5rWYqn0Pgyj17MhYnRaBBrMpEQEmqB0xcjkmAyyQCiMqqajToajTry"
    "PFd+FSns4m3CKBVRJFRkrtFaY3bjnENKAUqJDZMY+uJCS1TXjSGWyKkp9UiN9skI4nwyVsFxPA9CSjBGLfmBhCYm6h7rtRoIAMGF"
    "MwMLlR7eajUBAIL73hXnL1INJ3PVU8r8r5LxZEgM/LRuStBpt7edLzMn/f4AjUbDhpOMymTIsPqauQCk/QYQv+KORH8wgJRAmiZo"
    "0Hqv220v/sTRH1viXBz9hV/61UhsIiIiropIaL6IcebEoyprSZt9AVgiQ5RpxP1a946zISIgVByILgAnNfkwi6Fdlty+9rUJR3m/"
    "1qUmTKpysHmu3h1PMjQadRRFgaIowJiuj9JsYDgcIcsy2x7AeXH0dZ2fdiaqlYJDRwtQcg7PIOPOpFdoGzDySJvZ1YRybH0eQnR2"
    "F1U1aKgxBANCOKLHKAVLGCBVdhIXipAwxlCv1yCFRMkViSOEKPWkXrcm3LIsQQjRREyNiXNuWxgURQEpVd2e0Wg8W6WBIzhGaWKM"
    "Yq7bwaZuDlqdN6K+ENbjNFsCk5rMwJ1fT6KUzi5tHUkEGAxHGAxGaDTqqKVpjxAsvv/HfmSpLPnRX/n134zEJiIiYktEQvNFiNPP"
    "LfUIJccI0AP80JFaiFTGjtpGqCMzzuNiQkSGjLiKt2YZcinJOgRDiA0jed5WFWrxPTdw7/nEwBAhIQTq9TqSJMHa2roaJSGo12oQ"
    "QmA0GuveRMQtzkT1SpoJrXpUr1154kgdJSCEqqq7VP0VUmpyYncOFQj4Ck4l9EUkUt3wUkoJrueSQHUWlxJKVdGqS6LrzQghUJYc"
    "lChykWhPD+ccWZZZEsUYQ1mU4FygLA2JKTUhLFUrg6JArVbHeDKxRDJI3w6MwW5O2+3WTELjURpl0IYhlob7yal9zbzZ2j2G1Nh9"
    "vRAeUT6qLMvAGAOltCelXPwf3/uepZLzox/+9/9HJDYRERFTiITmiwinn1vqSchjErInhfr178Ii0JYZ3wPjFjAJAMKFDMwhDuFC"
    "PVWivxL2kd46ZcJX1hDs72hVFbMgSlBCUGs2kGVNTCaqOnDCmPKESIEsLyClsCEXQxamTM3boKrWEECZb72QDAB8+rPPqMwhhGoM"
    "rYZTqmZkv0aMNH4cdU2zrSxVWjShBDRhyjdTChC9T0KVuiOMH0Y5hiGkRFGUNvRGCEHJOYqisAQmzwtk5nlR6nmlEKY5pUdenFIT"
    "bm/r+d1iAgFIFEUR3LpPnqdVm1kfENnyPeMBcgoQ6TFGF3/kH/3gEuexCWZERESISGi+CHDq2cUeII8JKXpqbSV6MZAqNBSEFWan"
    "TRMoO41PClyEwIWYzEZjnDV7Er2ok+rBUurzuuBCQKwq9gpCCLI8B6EUjDGkaapMp7wPISTyvIAQHFYTIZogoOLfAeyJzThHo7Ez"
    "61ZB4BFAHWITQhMNV33XzIGkTnug1M2lUbbM/Lq2BmqxN0XvINW4jU/HD5dxIXTlXVPfpXSvSw4uXGq01CEqM/dCSEtujEKTFzmy"
    "rAhCTGG4CaGHRm9rt1vT81SdYSkxHI7Q6bTD7w5RISlrF5rB+aqfkzunOYf/l+gMMIAQ0mOMLb7vPT+wxGNLhYiICI1IaG5hnHzm"
    "UyprySMygOsbRFAlGGFIIawjI0ElQEBVoTgTGrGpxr5fxqVl++m+vklWXU5nIOl9jQfH+HHU2SohKgJMJmOUZQkpBRijaDTqGA5H"
    "GAyHyLNM1YhJk0DkoZSgKMSUSuOiSxJ5UUyHnrSSQEAhpETCKCRXBIYLASYSdQHhPEHG/GtCUu4S0hIFKZ0fxhS689UPc2mjvBji"
    "kht1Jcut0qIeOXJNUhSZUS0hggw0bT6mjIExlflkjs/yHJBALaUQVTXG+wwt89KzOz/X3bJqsOar3vW996zPyhEUQ2rk1IcwG46g"
    "mvFVCDclvYSq7t5SypmKTXfP1UlZf+Xq9XYiIiJ2PiKhuQXxynOLPSmlqiNjiIypCeccuZo0EPsaEBCSgnpKiiE1xhsjqAAF1dVs"
    "XYaPv6/vrzHbq4qPDbPAjYlog6g0ao8lRW5hlFq5GI/HkFLa1GxKqc2koYwiSRJP7iG2arAQwo7b6DPWQzMzDGJvws2b3qcsSzDG"
    "cPLkmbDjtlld4S26ZrU19+zVYTFeIgKXAcW10df0PyqKEpMsw3A4wmg8wWSSqfBRWThPTBkWrzPF88wYTKsGxhgSxpQfB7AG4Twv"
    "sGf3PIjOvLKqjKfUVH00aZrOnC7ropESg/4A3W5nxnQS66nxSY07Q+iw8T+j2SErICTX0N8X9AC6+L4f+oElIRyxuRYys91+kehE"
    "RNxaiITmFsKrLzymmkZK9ITgytdBtGIC2FCOgX3mLfBUCGWV8foU+YTEN4qGpl1jg6kuMmZhhzXIGnVnpqeFeMQGUisfDsZ30mw2"
    "VIG9LAOjDFxwSzSkp2i40yrzbF5Ia7J1hmBHb+zN2LAZAguMSYkmhCLPC5RlidW1ddxHDoOCepEuR2ikBIjkgPHyCJWxY+ZBnRgo"
    "uCIm4/EEY+0NyrIcmVZgsizHZJIpQpNl+vpcX0O4VgK65otRgIxqZB5UG5oNsZFShaEEFxhPMtTSJAw9GgJjw02hj2blyozPETqk"
    "ROCIm0c0rg71vSVTW/wX1ZOF5/ddXHoOeowR29379/74P19XKCoSnYiIWwuR0NwCOPvykz0p5TFI2TMKhJXhzQprVmgbwfGIDvzt"
    "gAsZAcTze9h3TXaTemG3Cb3R7+isfoi7X/hTx2jVIvjBrYdLQFwquFaIylKFVBqNOggh2Njsg5ccScLcuKTzofgwac0FlA+FC64X"
    "W9gQmRmGIzle6AuqLk4jrUEIqYkNwVd95ZdXwiom7KbJgNGZNJkxRl6jnvCSI8sVWRkMR1qFGWM4GmM8zlQoKS9sSCnPc0VmONdG"
    "Yjc/vnIRelaCmfD8J1q90ve/2R9i720LoZ/KfDkMufHClQvzczjz2llsCa3QhEpMoLlsY9Z2+02pfv7b5htNwmNIsKPxPhliwxa/"
    "59u+Y0kIcfT4n/zBG+qxiUQnImJnIhKaHYxzL3/aNo20xdrg8QLiwjZqgznSX5j81+q5XRTVj+xKSvJ0SMnfZsiALRBnFSLpZTPp"
    "LTYcophWWquh1WrjmedexK5d8zh8113Iskz7ZiaQgqPkA6yurWH/vr3WcHru3AV0ux20mo1gTErtqWwixBIRKUw7AG4JkBtPCDVe"
    "gDGjVgmVKk1IEHKS0l9sXThLCIFSm3AzTUiyPLe1YsaTCYZDRWKGwxGGozEmWaY8MSXXaovQoSgBp4T5YyUztsGOKwjfGMVMAlIq"
    "EzUhQH8wxP69u9V8EE+NmeWj0c9bzSZG4/HUNQ2EJZpuNrfH9PtVvaZK0LY9m//1J8TeN6W0Ryld/Ad/9zuWhJBVxeZataSr3YzF"
    "LKITSU5ExM1DJDQ7EGdfelJV9kW1sq/PWZwx1xANm8Fi93FajYNRKfRvfrvIV/cIl88gHIDKi0DRqRAefaZWu4N6s42F+TkcOjTE"
    "oTsOQEiJSTZBs9lCs9lU6owA/uunlkApRZomKPICo/EY/cEA+/ftxa5d82g2m6ilKcpS1WSpghDYDtYqDARbYXeq5UAY4wCgar2U"
    "RWkX/NW1ddxPDgczadQnzoVWXoYYDEYYjcaW0Ki2ACqUNJ5MMBpNLImxjRurc68n0TfAuq/ArH1DSG8/U+fFkRs1/sFwhGajbglA"
    "4KMBpnw0rZZHaLwvhx8CHAwG6HTC6sIyUAxnjHNq3P5nUSU12yk94XEAoCxVFFIKCEF7LMHiP/i73/mFhKK2Ij7XRHQiyYmIuHmI"
    "hGYH4bUXH+8REE1knNpgC9NR6BRiVFgGsYIBdJE7U2rfj0MFv++lteO6/zJX/xNNqi+9kxBHhqqhALOv1FkutUYT+w8eBEBQ5jlu"
    "v30fJBTpSJIERVGo3kyNOqQUuH3fXpw48RLuOHg76vUa7rv3bqyvr0MIgVazid27d6Fer6PfH6jsnQp8BYvqh80sCgiN2tvSQD1n"
    "RVEgm2So1VU/oyc+8wzmF+atImY8LHlRYDLJtHG3wGAwwngyQVGUKtXaK2zHtYHXXmYLTJtpTfhoxvo5xTL1/cutFQ5CgMFwjFaz"
    "MdtH44Whpnw0AYl1p/UzrfwxhFcOt8OE6ezJ9CdhQ2XT9xXs6/H88PsXHk8IBaXaLE7RI4T5xObRra5yDfiCiU4kORERNwaR0OwA"
    "qBYFRHlkpOq8TExBNsApIBUvSkAw1B6W07hf6p6qAHMcAKLTonxNxzuXz5eI/1PbGFKIp/BAORhgl0IJUAIKdQ/z87vU9aREkjBl"
    "9h2PUa/X0Wo2MR6P0Ww1wXSl3IcfegAl58iLArfdthuddgv79+/F2tq6PaZWr2E8HoPY+0E4eDMbegdb7t+QOMVuDB8EoRRUN5Cc"
    "TDIURYFEZ/i8unwef/BHn1BH687XtggfXNgG9rlnXiUMNCEgOsRjRsC5MjQnlSwizrk1Favie4X+7EP2Yj9ZgkC58Bd3N6bwu9If"
    "jLB/3+6QwMwINZkD5ue7kK96E6vvwkXdJIaDIbrdrt1nFiEJOQ+Zes8ROJ/IzcZWniGYe6mAUQYJaXxNOhT1nY8KIT5QITbXG4ra"
    "SpDaFlWSEwlORMTrRyQ0byLOPK+6XwOw3a9NXRKie/egoia4CIn5JU1DIqINu6Y4nO+dcf+qc9nFzoQdvHPYPYxvRhtenbrj/lrv"
    "jF043bnGmUp91gYWlCXHZKL6MUmpKt4mSYKEUVDG0O8PMD8/h7e99Uvw4ssnUa/V0Gg0VLNIIZDnBfqDAdIsdSnF2y1B2ywlfvCt"
    "VktBCEVRqPovqju20GGtiUoXN3EgPx5EzHwZ7435vBypoJRCEmrnWkoJqv05xJsrAGAscWRSArV6w15KCK/XlCYUZVkgSVLVtLPk"
    "NtwndTE/q6Loz4sQCkBgMByj2aiBCD9tOww12e8GgDRhKIrSI1ISKstJfc+KsgzIVNVP41SzGZ9D0AKhmh1n7NpVVAkPCe/XZ/7e"
    "GVQRRBWKIoS+PUnY4vf9vSOPcs6P/l9/9PtvRCjKv/B2+25LcqKKExHx+hEJzZuAMycckVFiRqjIWOJgCpMBITmpLDzQ2xz5cSTI"
    "CgXmr5MOKosX8U+ju1k7Vcg+tCTjspzcL3taWa0k1GLOkkSNQCofiyIiLvVa9TBKQdMEWZah1WpgYdc8du1aAPRYCFGZOpPJBKPR"
    "CHcfvgvNZhMgFzBrvTBzpoWYQNtwi52a1Fq9jlqtDkJUDyHVGLIOIdT4RsOR+kwobOjKJ39uTiVMKrFb3I1i4VFJCRsOk97JbPr1"
    "zLECSaIInFGSCAHSWs19TqnUlYi5u6b+bKn9jNWYTMZ7QF7s/4yi5UbSbDWQb/T1qLx3tCQ4Hk/8WQk9QOadQEpzn4iK5BHvi+7P"
    "k/T3xDSRcZDhPzNNyiZ8Rwi1/iJK8XZKk7/6vr/3XY+WJa+Goq5VsfEvdC0E5rpJTiQ4EREhIqG5iXj1hK4jQ1T3a0JIUGkWhKjw"
    "jv4V7/tcANhf0VUyog7VCy1xxdtMyjTgFkCz7/QDHgEQmlj5Rlqn/qixwJIYn1Q5AqZG3mq1kCYJIBWBUdV6VZ+poiyV8bcsIQQH"
    "FQQbG5totZpoNZvgJcd4MgEXXJuAS0gh0e108KVf8jDOnj2PNEmR54WdwukVQRMX6S+MLr24XlcKUJokYIyhL/poNpuo12sYDtWC"
    "URQFOC9BaapIGpyKpRSP6fAJTLjLPPXCf0olMEqGO4+ZRl+Rc++5z9xXMNx+5nya/BH3Gdjvif18CLKiRFfWXBjTfKiOjQXayny3"
    "i/X1fkAmfFJrWjD4hfj8NHvocQjBrZfIh/8t9zdW/UCzvUGGnM6aF1S2h56kQGwj9O1pSv/qe7/9ux4ty/Lo8T/5g6rH5vWQm+Cy"
    "Wxx7XSQnEpyIiBCR0NwEKI+MIjIm8KNCGjPCSRWfjFkYLZmphCiAkNj4igFVbwaLXrj+ycp/LonOCpF24ZFSaIVDhioRpscxbQyV"
    "qNcbQMIAXQiOEgJJiHpOKYSQaDTqKixFKRijWFtb12X7c6ytraMsO6hrJYJQgi95y0MQUqBer6HdbmE4GvkXhSMwXg0aqVLAXTVi"
    "gjRVZKZer4ElTLcyoEhTFc6ilIJSilotnermPeWVsTOIYJ01lhQ/FGMWVKPUmH3UfPsqgq+eEfvd8BUh8zkxRtWxXvd0MzhVh8ZT"
    "1ogK35Vc23KnvnPTaAWNKiXgFUc0JLrkAp25lg0SOSIsdF0fAmXS9Ys2hnMYmLX1G0VRoCwKcBEWUjSExx279fgDVL/25hutw16U"
    "0rfXaqkhNh+cQWzCA99YXI3kRIITEbEFIqG5gVCKjFdHRrgwh/uPOLG/poUXGyH6l7INMRm5HeF2YPqXsHqL2IWGkOn/2EshVOhg"
    "KhVYTqc3qzd0dIHYcJjlOO4nbvhTlBB057oAFwClkEJgY7OPVrOBRqNhGzPW0hSEUoAyPPDAfXjhhZdw6dLEkrOy5EgTFQKr1RSJ"
    "KQvlzVlYmEO/P0BZljDG1ulIg5rbPC9gKhG3W02wJEGtVrPkBQAajQY4L62K0Gw10el07U1Nr2C+14QE2yozPnO7eS28hdwRHXe+"
    "QPFBuOibLB5KKYjpgUGUamLJDNz++hkmeYFWPanKHjPuj2iSl+h0dliyaFUlSOR5rsOloWLixihBCIeEar9hvtc2S8qSZUeS/LBV"
    "WQpQAkXeKqxkVnjJbPeVSXdX1WPl1HNKydtrtfRT3/vt3/loUZQf/L8/+v88Cv9DnjVZW03iVcJJ3uCvptJEghMRsQXYmz2AL0ac"
    "fm6p94Efe+/vAeRfSinvDBQODV/m13wGZMbiGLwOFlUXFrDnN6eselnk9H+s3XuVMUl/ObKr1dQ17FPLZcJrEkJQqzfR7nTA6nVA"
    "CJRliSRh2iSMoCEjgUrh7sx3MRmNsLGxqY2makFluqZMs9HAwsL/z96bB1t23OdhX3ef/d779jcbZjAY7ASoLSQAPlESF4mULIIy"
    "SYmkZFmLGcdxWamsJUUyLUVJKo6rXPAfqcpSKSfluOJyiXEcShY3EOIikBIBkLJEgAAIzGCAwexv5m13OXt3/vj1du59DzPYRIJ8"
    "PfXm3ntOnz59+vTy9ffbFkAiLE8kpvVsDPEkNUCUbUsxkJoGTdtgfm6AW285geM33oAgCLxQB8yCnTzPrUO8AwdWkWU9xElsQyIY"
    "FsRc1wU13hvabSHdBTwYJsyxMhyOnSGAYlglgER3Jm7TbJmqc62HNb13Tm9YSoU0iay4aPc/l5+cAVadPsQZh1EED8MA8wvzMOyM"
    "aRfl3ZMxbl0K+IItxuDM65VfXwLYFJSzwXiS69AOAtN9ebdk2LHuu9kdd0yPD9d27GgQiI+9+fY3vffOm29/8smT3zauk6cLvdbf"
    "dN7drr3ePLiOc50UZ2Hnr5rUL5V9P+2nN1zaBzSvYXruW19d+89+4z/8BBh+H0odM/Oj0YRh3rTjMyxWlMPQ0aUAMMU4OH8fCrCe"
    "eJURsXjAwyxS0luc/MVjOs0sDXohMyyKAWQW1FgGaUqfx9O/6PXnkGYpGONomwZlUYILEjONJ3mnfANaeBQiDUOMxmOMxxO0TQsu"
    "uFuQGEM/o52nlFKLYEg0FAiBIAzIaiqgOEZGITYIAhw6eADHjt2AQwdWcGB1BQcPrCKKY1RlhbKq0LYt6rrGeDxBWZZI0xSrqyvI"
    "epkVR3ELFmb/qHpOhNRdSLtt7YCCA60m/pIRy1hAMLXQEptE4MaKmTwQZF4QXSs1UOvq3hBQApKIopZLzSA63S10AI35297esYDD"
    "B9oESEMsr06ZAzMAACAASURBVCxbhsnW2tOh8a9lFpSxznlTV8pLgK6ua0ABjXZWmCTxLq26C39mD+211vtWVbNgxj/OGD8qhPjY"
    "3be/6b2333zrU0+dfOYsZoHEqwU1L/f3awJw9sHNfvpeSPsip9cgPfetPyMdGWCto3oqfRrd/a/sJKrsPEw6o3QWYNDrjQMqzMSu"
    "cbtbE7vPzFpdYOMYIavDoevSsczRK2bHemlql95Jti7+XZktF/qzlRJxkqBpWrRFhbqpwTXDIqXEJM9RFAWCIIAIBEajMZRSGAQB"
    "eguLOHHiODjnuHRp3YqUwiBEWZbY3NqCUnOIogiCc2RZikAIpGmKoiiQFwXyvMBkkiOKIyQp3TMQAcIwQBiGCIKARE+9DFma4NRz"
    "L+Dy+hUURQmpJHq9HhaXFhGEkQYZhFI6AMYiF68tbWK2LWzTeQs7AQ6ugYwndlEwncG8fv2KWOd6A3SsgrF3DSnfkhsAAjPCf9Vw"
    "5uUMVSORRIKClnIGJt0zmOckk3mmTe1h+6jXIaCYwng0grMe8vsOg3NLQL859+8DAL5StLRWdm1LTgqNxVlV19jZ2cHCwmAXCDMN"
    "y322Z9ocfLf83pWdgqfAIGdvi6P44Y/e/6GvlVX1m5988I8fmanK3mDCDPLX6vdu6WWLqPbFU/vpeyHtA5pXkU498VUCMkqtSShw"
    "TacTANELhwUdrLsG+GAGcEDFAx/2SqPnwrq6M+bwNJDp2EYprwwFKMa8GY5WODkFaOx3RfW21ixmITXP49VJKs/vq1IIgghRGCLI"
    "UkAqJHWNsiytB90oCsGiCHmRQ9YKXHAMhyMopZBmKZZWD6HfG+DY0W28ePYczp2/SHGfwLCxsYUwDCGE0Eq9MbIs1bGUKEJ3UZQY"
    "jcZI04RAipQdpkNKpetSI0kiZFmCoihQFAWOHDmCJEmQpimCINybkem0pfd6lXG9D++d6C3zDKvjgIv/3o0ojGrMDPUG+1V5ojL3"
    "WDZxISjiuO0JBuzAW+SBoqzRT0nsJJWC4sqCCf+ZAOhYWl0WwwJrRX0gzyfo9XpopaS66RhVvshpmrQy4Fp6DgUZgwNl0vXtuq7J"
    "jN4ylXuzMh1R624wwB9mXvtMJ2ovrw2hYTxnb0vi+OGPvO8DXyvL6jf/8KFPP9pp7NkmnD6mvN+vFsS8VHpVAGcf3OynN0raBzSv"
    "IJ164itrSuEBpeSaAiyQoeSJHKYWPF+XxiwEZor0ZzhmwA6mZkd/YvYPKt9Mm87ZrMy7lDkfI3SMrjUgyYIsU0+TGNWQa3Ng96Q2"
    "Oy1ocDvzOI1oF66LMf5nyKcM0Lbk+I180AQIgwBtGGKS59jc2kYSR+j3+1g5cBArBw/i4MGz2NjYxHA4wvqVqyjLEmrQRxRHyNIU"
    "QlA07rZtUTcNirzAznCE3rCHoigotpIXNLKuSuR5gdF4jK2tHZw9dwGTSY5eL8Pq6mqHPYFpu45Ix2seA0K93yZgowWUe/AJjjHz"
    "Gtv2F82kKdefyFoI0DZsNk+rAZutLxzwAYQFC4ZBMW+vaUjHyFh0KS7BBQdXEhTPs6tPMzc3wM7O0D6BTygppVBXNdADBfYE0Ohr"
    "21bqtuGOQWSO2TPwpG3pmxGrSdkCjMpTUiIMAg8g2QZ27dZZ+r0fnWWb7frO/HJ8Ud90XgUdUgNG7MnfliTJwx/+2Q98razK3/qj"
    "hz7zyFQFWKdwvyIzD7AnyNnrumul2Y63N8DZBzf76Q2d9gHNy0innviKdYhH6wu3Ezk8V+0vBWZ80UKH+VAvMUcxw/BQRGtL/Hji"
    "J50Njlo3PI3/Df7MPQNIjD6Mcla+dK0isOODMbcNNvf0RAyk2IGmaRGJBuAcrY5Gbcro9zIUJXkMrqqKQglosRBioGklNja3sLG5"
    "hcWFeRw6fAQrKyuYjMeYO38B29s7SJIE/V4PvV4GFgRAEAA8AXXrHMPL69jc3MJ4MsFkMqEo1+MJxV5qG+R5jp3tIR5/4ilcvLSO"
    "sixx6223IjCOAIGOLotBqg4UTr1z2xxTLMYUK+JOwqIBd878dqyF6SNucdWgSYMUitDdaGYs8HRspFbAJoaOWTkmrPM9pRTyskYv"
    "CYld5Bxci6n4NFvDgF6WYmdnaB/RZ2iUUsiLHIfTQwSwtak2gRlXfxIpEcRzisDOuo5rMETPQYraLWsJJGpGyvdl02lXu3wz2M7q"
    "QYTdIGX3vThxrBH1zYxLt9+wiuK6nd6WJumffvh9H3ikLMvf/KOHPvMopm/pms3/vhcbs9f3a52bvpd/bhrgvCz2Zl80tZ++m9M+"
    "oLmO9Ow3H14D8ICUcg3Qk1hHB4DZOdT3TaIAC14AsxP1lC/h2BIYj6h2Q+nYFgMoaA3l5qbOXFqXY1zzE7iYnUcN9W4BiWUAFFx2"
    "ZmdAA5d8vZrdklHg9KoPwYV7Nk7eeBljZG2kGYF+vw/OGIoiQFVVCLQYqRcQ2Kk1m3J1YxN5nmN+fh7zi0sYzC3giScex8L8HPqD"
    "PhDHAAsAxAAiXYMIgyUyMY5iEn9xLkgsUpSQrcQkL3Dx0jouXV5HURTo93uYm5tzC5qO22Tf8ZSYyV8I/YXfvh8AXHDNsKjOtYBj"
    "f5wCrG1RXaZhVUw+WvSDINCsR2NZGefnhd5aV2eFFmYpqd2nHfcVZY1BFqOVhkVhNlq5UVQ2rEovyzp17PRZpZBPJhj0+2jb1gIU"
    "E8STjhngQveStk3JcsmwIUbkZJ5ZSgnZkrVaqJ9/mtPwn9WCP0/RTL/VDhvjmBj/ev9FKnvMB5M+dgdg20pKCabYfVma/elH7//g"
    "I0VR/tYfPvTpRwBjT7+rOOrlgBq8xLnrATjXSvvszX56w6Z9QPMS6eTjXyE/MoqUfQUX1iEe4HEjBsjo73bW0vRHR8fFzr7unPUx"
    "w2AZH6YYTJgms2hQuW6CdYl1Ptyk7RYdKzKBD6KcsqPTlNELWvdqAMafibn/7Nxp2InROEd/XgOgQABKoa0bq6cRBAEmeY4kThBF"
    "FIdIKa2DFAUQnCPSC1/CY9RVjbaV2NjcRBxFSLMUy8vLFAwxjgEWwhnsNbomJVDXCIRAEsfakRw564tjUvRt2xYXLl7WJsEt3nTX"
    "XfbZjP+WPbe9zPUDK9rRCzPjJJ6z4JZBi1p8RsAwME4U4787X+eE7kE6KabevmM/W1+ddnNwaERTPpA2YqCyrFA3re0bFpzbvuIs"
    "2bIsnXr3sCIswTl2doaYn+ujKCsMhyOMJzkqHRHd+AoikOdZ7GnleePlmJqenk9KGh9KwcbyStMEpsP5IFBNs6Twv08zMQ5Mzqbp"
    "9rPZp8r0r6cvhlUiMCruy7Lsy7/4/g89khfFb/3h5z/96EwFXOKdgrrg5ZUAmdcK7EzXZ/q4TfvgZj99p9M+oNklnfzmw2sKpCMD"
    "kPze6GgY2b9JbOpzVxZj6hDTCx/sYuf91mX5BIsfNNvurBWsDg7bZbqzZXr39D87ddVTXLcYElPo5cQWbEAL03VRkB1WSUnS5UmT"
    "FFGS6O0snavqGnEU2XhJdV1DyhZt25IeTRRCaX81YRhAKWJb0jRF27a4cuWqVeRdXJgHjyPNzAj9EBIEaFpA1hS5WikwzrSFU4g4"
    "jpGmqQ5vENPiCuDYjccQaxbJZ2Kmffjovb8FHK4tdet4YMWJmvy2d6yAUrDP7oulDBvi2BSlY305YOOsmAgECOEWaCNe6t7fiX2c"
    "boizgiqqxjnZm+6P3jOBAfNzA2xtDwFt7UYsToAgDMA5wzPPnkLW62E8ntjwG8QkOfN71embrtcpJdG2DqgZICo1GJXGc7WSrk4z"
    "YMVtE7r3mM63W3KjwGef7MZkJt90MsDGbRY4F/cN+v0v/9LP/cIjkzz/r//w85+aBja7sTb+79cayFwvwJmGctfN3uyDm/30nUj7"
    "gMZLJx//yppS6gGl1BpjDEEYIhBCy+uVXeT2Gv7K+09OHXSzRxe4WJ6ngyZYF6T4u1B7iBCNMsgCsPUjBV63KHdFHbokjy2wYidl"
    "lDzNjrlj42R34o5pUm6iV85aKktTWpjqmhziNeTVN0szDIdDcqjXtgiEQNuS/5IgCMAZg0hitHWDSZ7rR2Ko6xpRGGLQ72sgVNEu"
    "PTDMjHk66f6suELZnbzQCsix9jY8GPQxNxggDEPMz89bsNpZYQwYQRcMugXYz9Y9bxgDEz7CiSPd+yUw4wMg94anXpjOx60ohjE4"
    "k3KbTaJtFYKA0aJuQYmwIi4ppWZ5YHVulGIkYmtbrz9OAQDddVdXl7U4jtl3aZS7GWM4d+48Dh0+7LFBRhEZlikygMpvRwOwjONA"
    "pVwcLXN8Z3sbaYclMu2mAbhhaXQTOpHdS4GZPciHDqLZLb000eHfTykFIfh9g37/S3/rbxKw+eSDn3oUjpmZ3hvtVsFptuZ6v7/W"
    "rI0pe7p+08cB7IOb/fTXl/YBDcizr1LqAankGgNDGFEsH7O7JDaf2QXPmCibne70rGBJFK0zA3veLY6Os4YFEZ0ZQlEef0I2wGE6"
    "dZc/bxFD93OGPfLzMaecqWxeB3JoMeNgUJAcgCTQZvWCDHulAU4YRUS/cwes6ramRZ1zcCkxnkw0WxKgaVpI2SIGubYPhEBeFAjD"
    "EOPRGGJugP6gh7puIAQDDyPQWmDgxywImH1eAnpCULymXpbh4IEVvHj2PHq9vrmo8x6sqMZwM6x7L9ZR6nViPbrWsAgmbxcd+OIf"
    "05fIXNvdg0RVBhBpYCY46rr1lH8pv9R1jaLAWo5xwREEBHoCIQDGUBYljCM/gEBNGAaQTYGmaSxD4z+TEAJCcCBi6Pd7OHL4IDjn"
    "mOQFLl26gvEkt+1gIqInaaqVfgGjQmLYJ8aZ7csO7FH7UFwqE6eqtdcAQF03iFtt5WSQl2alDKhxQH3WRNxv/27qsm3dfP4I7+bf"
    "pYvNlqrzSG3Kzhi/r9/rfemXfu7nHxlPJr/tKQ9zv6iXqPTLBTAvB+C8UqCzdyN5aR/c7KfXM31fA5rnn/xzbbWk1sCAUIQIQtEB"
    "HsZvC+ELmoRN0EcCIT5rQ5MsU2TCDIAUej1gY/yGsKkpwzjbs5ZEZkK2gIBpHzeGCt+dACfsQ786s5PyQMfUOR9gWX8knndgV26n"
    "yjZNg5msN4DQnnWntqkIAgGuSNl2MOgDSvuw4QyylSiK0jIHJkTC/Pw8mqZB05QoyxL9XqIdvbCpPwlaE6S9L+ecxBSmnvoJOCfv"
    "waury4iiCEEYeOIl99Ck20OLv/UHA2M1xACtK2PEKoaZMW3mi6aUciIXn9Ex4iMHh43+iDTNNiO+cswMiZfIOzIBkziKEGtF6Cgm"
    "83nBhb4GVtQltLiNMWqLyWSMi+fPQXEOBCaAZ2jzcMbBBYfgAkEgEIbko2dlZRlnz17ExuaWrVs+mYBzjjg2Hn1V91mka4OpLuI+"
    "FRAGIZo6x3gywXA47G4SvDFnGRoLcLwOuic70wXBs3uF3dbo7q2vldxYMZmVL3q7b9Dvf/EX3/+hR0bjyW//8Rc++xh8BNz9Pl3s"
    "9APMDOmXcf56Qc1eAGd6N7EPbvbTdyR9XwKaM08/sqagHoBSawRUOALjxEyqqWFolkD9Ex5r0qH6VUdEY/fNZp21oEUr/JoyzPEp"
    "AGGQEU3sbjdqLFBmFT+pdjAfDBb02KVSwQNNCsqAGAVdSfoulXS7Z/2fnGqHTiBNfVRps/IoihGEISkENy3KoiTKPRAQQYC2JCXR"
    "OIrBmHPKF4akw1HkBaSUyNIUTdOgLEskSay/FxAiIOanA2aAjiGJqRtnQKPfj1Y0bmVr40DZJvMAop2dfWADWF0mX3Tk9xH75phr"
    "I8t0MOe1lnOONE0ItLRUH2KoXARyKsfFlyJw40yKDYCJwgBpmiDLMiRJjCSOkSQxojC0TxIEAmEUah0hel+TyQQAw/z8AEIIq6+T"
    "j0fI89xaTBkmhwsKJREEAkEQItIsZhAEOCYVjhw6iNMvnMXFS+tomhYiEBTuQmlTcg1OTWRwX0xkUtsqa4lF5t7kcVpBoW0aa4U1"
    "N+h77eyNQfuOulZcs+JAd67rA8gd90awd2zX173nuWkQxTQ7KIQgsBmFqJsGk0l+39yg/8WP3v+hR0bj8e986oufe2yq2OsFNq8U"
    "zLwc0OPf+1pAB1N5po/ZtA9u9tNrkb6vAM3pJ/98jTP2AKDWOiNQKx86z62z1i3M+2IZnCkRArMTKUg4w5QFIx2wsutuETNzqdXm"
    "UN4JvVbv5uCNHkXNlO87IfMtrhxoUbtMVwYUOJBkWKTpCjsPwrRoR3FEvlw8MNY2LYKALHTatkUrJeqm1otkgEKLl4QRk2gnfEbX"
    "pygKKAUtPnFtPjvX6+9tC2pB5+Ok1QrITUMxm6qqxvrVDatTophbxG0be6JBxnW7+PO9AsDpPkIwu/t2YMCZP0dhiP6gh4X5eSwu"
    "zKMsSgrTUJBn47qu0eh4UgwkXlGagZGyBdeWUkEYIE0SZFmKfi9DFEWYmxtg0O+RB2bN7nBtbRUnsQUjcRzb9yGl0hZfHFEUoWka"
    "rK3dh8989kEszM9ZYBToSNu0CEckktV6TwYM3XjjUdx228148ewFPHf6RVy5uoG6bnRdNFgTgQ3zYF/VFAAQQgBKBy6tG+0EsbYU"
    "VStb7SfIfwveu/DAy2y/9s3YbQ6PLZrt2y7vbGIMHeA0jQE612mGSwiBMHAhOPr9Hg4dWMFwNMbVjc37OOdf+Mj9H3x0PB7/9qe+"
    "+OBjmBVDXQvYdFrC+/5Sx66HobkWe3M9aR/c7KfXNX1fAJoXnv7amlLa/LpjHWHmP5onfB8yrDvzdfJ3lDDtMTiRgBZHAWR2KrkE"
    "l9zCJGfOayxpGBT3GBpmHI5xxwb5SW/1fesZ41vEzK/OC7FP+rApXR1PfKXg6uctCLs6ArQlMzBrWk5l1612jqdTo4M+GpAQBgEE"
    "F5BKgjOGPC+glEIURSjKCoHehcuWGAmpF/A8zxFFESb5GP1eBiuTmEkKUC1I94mhbYkVkK20XoQNmCmKElub2+45Oy/aiBLpaL+f"
    "WQaFe8rFYRgiSWL0+z39mxaqMAisryIDcpI4Rr9PACQQAsPRCG1LpsiNZiCamuIVmYXcMDRGSZoWwxBpmmAw6GNhfg6DQZ+AR+Bi"
    "zdZ1jbpuLBuUJM6CK9TKu62UNp4WAx0/fPgQ7rzjdrz44osU56qXoZdlSLMUaZJQSIgkIdDqxbgCACUVTtx0HD/yQ2/GhYuXcebs"
    "eZw/fxGbWzsoywpNXSGMIhJF7pKcBRS1mQgEWAUCok0DKRUCIZBpXzhm3MF+TomWLJ55CXLBABtlju+WdutnzH3M+Hxina8GdBE7"
    "QzpNQUjsWhSFiOMI83MD3HLiRlxev4qz5y7em0TRF/72Bz/y6Gg8/p1PPvgpI4ryFYj3AjavBMy8XKBzLRB0PellgZt9YLOfrid9"
    "TwOaF7/9qBUtAWaRN07o9fhjziLIJAV0nNaZYz648QEPERG7j2XGGbjkkNyJNzq7Sg0KOJh3DzYLZJiDEdPbSV83xs4qGvR0fIbo"
    "MvX+EUYnxOXwJmlAey9GZ7rrKDl7oMzc1+pNcA5VN8iLAmVZ2fAEnGQuaGsyqxaBQN20NhQCKbVGqEoCQqYNAaAqS5TaQZsDNP68"
    "KEEm2xLwPLi2kixxmrpBXdWoyooUV/MJLl+5ijAI7ZTsv2cmBA4fXMWP/ei9WF1ZxiTPUZYVlFLIspSeNSI2ygAVAHDsDEfTNMjz"
    "QivVCsRRiCRNMBqNsbg4j6ZpoUCuASaTHI1+5romBeqqos8oDKGURK0txsIgQBRF6PczxFGEKI5QlhWqiuoXhSH5feEcsWbMhKAg"
    "oABZfNVNo5WktchJSjR1jR/6oR/A6dPPI44iDAZ9LC4sYG5ugLm5AZaXliD6C9RYbQ5VVjp4pNQei1v0exlWV5dx5+23YGc4woWL"
    "l3H6+Rfx3PNncOXKBqI4IbGTfXvU331Rm1FENsyREAJN22Aw6M+IkNxY2duSya64CnAWV+aMn6tbtunx3WL3Aj67MT2w+kcEZpzC"
    "dhSFiMLQ6jylSYI7br8ZP3D3HThz9jzOvHj+3vm5wZ/8g1/92KM7o+Hv/N//9v8xjA3zPqcr9FqCmWude61YnGuCm33WZj9dT/qe"
    "BDTnnv06ARlgjfQmPFGLYUWY2+bs5ptFzkx2uyd/Upxhn+0B43XDhBCAhVV0VAMYANjDMmMa3HTr4IEqq/zrTdzmf7v+e5P0XisA"
    "gI4DHP/w1DfLCgFYWlpCkqUAY2jbBgAo6nUYdu4nwkA7iZNIkwBlWSEvctqZxxxBSFG4GYDxZGJjQSlF8YfQtkAg4RrcAzicAZJ8"
    "tEgp0TZth/nIC4rEff7CJUzGEwRRZMEMB8A4x/Ebb8A7fuxtuP3Wm5GmCaqqtj5rpCTl5rKoEIba/wqjnbdhccqyskyOARkGQE8m"
    "OXpZRpCSORZnbm5AASWZNlWPIm3CzNG2rQ0TMRlPbF0MC6OgiC2KYwyHI/CIGA7D8DCYeFoBRa1uJUQgwDXQMnULAopa/sM//IMo"
    "ixyrKytYXVnCwsIC0qUlAPO6vRtAtGAxQxgIQIMZ+pMQbQOhvQwncYz5+QGWlxfx9NMncebseXAezQAFo2PkDjgTcwUaAysry7DA"
    "xYqIfTCzG6hhHpvjAyGnwO36ELOsigFb3CtntmTz325rMtWZ2oETiAlDxJqViTSQiRPSe0qSGHEUIYljvPmu2/HDP3AXzpw9jxfP"
    "nr/3QLv8J7/7n/+Xj25sbf3O//wv/s+vezdju3w3v19vMHO9oGa6Tn6a6QZTDbnP2uyn607i2lneOOn8yW+s/Vf/6d/7BGP4faXU"
    "saZtSVdAe6KdGRlGPKS/G66hozjrZTcinQ5T4ogaU5w97LMsXfhifjOb3zBFXdzidvr+d3NDwi/u07JFGsBRiAXZAVoehOrUxZx0"
    "9YFdXcwT+BZY9vlNXfQ9Vg4cQpjEgNDBDltJlmOMk8ffpoWSEpxxHVBRaVNsTkyFDj5oRBnG/whFci6QTya0m41jsCgEQRB/s6oA"
    "SKBt0VQU4bsoS+STHONJjtFwhO2dITY2N/Hkk89ga3sHC4uLxLhodujnfvY9eP/P/hSOHT0C46k3jEIIrTjLGbNsRBxHaBrnu6WV"
    "UrvwZyi1uC1JEsRRaEWSnFNbGDPrpmm8VtYu/6WCVJLEE1ohVwQCspVWjUcqhbIsAZDvHxMSIdQ6L4JzJEmMPC9cGIOAHBoa6yNi"
    "ZxgqrajtLy1CcNxw5BBWVpYRz80BLIZzXlhRJZiyHcZ3dWsUsIkho/cZaNPv4XCI8aSAMVenPuzCLhgRqlQSeV6gbRqMR2MURYHF"
    "xXmtVOw8MTuTb09ZmxkRMvfOw+bZndVhbhyYIQCnD+XfyxdPd9dcVz7nzIqYwogszuI4QpIkVnk7TWISCcYx4oTATBSGVpR5+OAq"
    "7rjtZkRRBMbYDQdXV37tPT/xjp88euiGp/7iiW+e7Va8830vsHOtY68kzyvJez318n/PoMk4C+1fNamnT++n78P0PcHQnH3msTXG"
    "yLOv1Atg27RWPMLMDAX4mzCbfKVZ+k3fp7cOdlfoLeTeVbTbM2Uz1hUfubs5oyXvXoD25WpEON4k3NkudURbTsfFgTB9hfdbKWnb"
    "gCZowxG5/Aq0NqlOW01ZXym/lWD1cfymFcZUW2ciJVUnTlDQ3l+bln7pRU8pCi1hPdcWBbIsQ17XUAp2p1/FCUXPriskdQyEAoTL"
    "A/1H5aJt0bYN6rpBVVUEanJj/jvCi2cvYGNzi8zA+z0LoA6sLuPNd99BQEuLZMzDcM4RAKjqRoOf0IZWMOKlpqH7GcVVE3W61s7i"
    "hAYVIqbjBvQoRfohXHBUVYOmbhBGIfzOWpUVFBRirQ8zmeRomgb9fo/KKijYpxCOKZI6vIGJJM4FRy/LKFq5Ukh7Gaq6JqCs+4dS"
    "wPLyEgLBMD8/hzDLAG6spnT7mj+Dfs3mgBkfNt440W8+CATm5+dww+FDuLqxDaWZIb+/m/HQtlJ7kqbPyWSigR9mwIwF3gbMALPj"
    "tgNcbPf2enOnqrssn9OlzpZF5Rt/OMwydKQro8FMHCNJIgtoyDItQhzTZxRF1oIsCgNqcSmxtDiP5aUFnDp9BgDufdPttz70D371"
    "Y49Oivwf/otP/OuvY3dR1ExTTD3dtdiX68lzvUzNS10zXb+Z5t3lWTr59lmb/QS8wQHNmW8/sgZFQSNJvDAVHdhbDDqgprPLYrMj"
    "SA8rC0wAB4QMo2POKQ0NjCjLK8KjMrzYSK4482XGMMniJTWTv+OHxvx1yuo+jTnbtSxh8BmXzj2YAy/K/JtSCp6+xhQtFbTybqgj"
    "X5MvmiAIMByRMq8QAnXTWG+wJhp0XdMOi+L9AFEUoa5JKbbSnoI55wjDAMPhDgaDAZkhBwIU/sDM4yGgCh0iQYOZokSeFxiNJ9jZ"
    "GWJrexsnT51GURRktROGAGOIowjv/Ikf1YyRgBAtGklPHSoyPxacI45CVHVD/oaU0iIojjCKyFxdg6EoCm2fTOIYUilapGsFhHQ/"
    "YkwalEWJWjXgUou1NHNlfMsIITAeTZBmiW1/ITgWFxeQJLENzVHVNUK4sAlN2yLSIKeVUoeXUNbvjrGoStMEeV6gkQ3CMERRtOj3"
    "+0iShN5lZ30zHUn7/OGM+tQMc+H1WS36BYBeLyVGTnaZOJOkpMCb1HbGnJ0hjs27MtVx4OVaOjS7g5k90p64ZdbKz4xFv0xjnm31"
    "ZKLIsjH0SUrasWFs4sgqlEcR+Q0yIT6MhR4BVY7NzW385eNP4cajR3DbrTfde+Xq5kP/xz/7Z49evnrl47/zP/zjr4Ne0G5Omqaf"
    "7rUGM68G1OwFZHZ/CbPPYdO+rs33d3pDAprnn/raGoMBMprdMD5Fpru5OaZ3n4DehXpZO5d0lGS9mWC3SU5NTWjmsGZnLFgySqaM"
    "+dXpjMQOjc2Yt+ODx8J4AMb+x2xhFrzoz85e1WsDGyncQ0LupNShywAAIABJREFUmVnnEgWj9+OXiak6kDUSmLA6LoEIoGpjpUPK"
    "wGVZEQgBMTfGrDeMQhu4UAin15FPcigtdmmaBkFAFi4vvPAC5ufmEMcRMiGAWIAibTMAAaCUtWLKtdfa4WiEne0dbG5t46mnT2I0"
    "GiPPCxw6dNAq7N55+y248/ZbAEYAqywpxEKjTZzbttUiH6bZFtKJaLT1lGFEpCIGivReAhsdutFMCJkmK2J0dAgI458kjEKMxxOy"
    "ftHelofDEQb9Pubm+ijLiu4vOAIRoGVkGaWUQpImFkxVZUV6SIqjhUIoArRNi6IorO6SeSdZlqKVEmmaoChLzZq1yLIULPDBot9z"
    "GawjQyN2Yn4edEC31Auz1GxUkeeIU7f4TCMOpWBN7I3/GbLiUkBHWZ3Z/J3QB6Y3e3n8ZAlU/3dnTHTr4v2aOumuIzETn3FwaBR+"
    "09SBmY6IKSKldM4FDOcphNBsH+luNTp6+c5wBAA4c/Y85ub6eM+73g4hxL2333bi83/8r/7lo8+eOv3x/+L3/hvD2OzmeXi6MV5L"
    "MPNSrMtrUdZuM/w+a7OfbHpDAZrTT/4ZefZVck3aOZRmJs649vviL8/ePKlAjt/Y3pMc5e8yMHZUGfGRK67DXHRKU+bGs7Mj16BG"
    "ATpmErOYxI5Xb8dHf04HyOjKmItMTCfo2ikdMLBD25jHgS/+Ynb9MYsAMw1GldMiNAVm60HP5IM0ewcFpFmGOEkQJBQNmQUCTVmC"
    "gSFJE0wmE5RlSabEWYo4TTAaDhEz0iNQepEPggCybVE3tfUWbCJkgwFXNzaxsDCPKKJda0yUDgAdhbmqrHhpNBoTK7O1jasbmzj1"
    "3PNYv3IVy0uLmEwmOHzkMAGJMMS73vl2pFkKxhjy3Og/0MIkJbEZIghQNw3F+FImJhL5fXErBvWTWseyYgGDCAQiBjTa0WAQBsQ8"
    "aSZKKgXByJqp1WwO1+UGwi10jDEEIQ1bIQRtx7mLwm181TDOyEkkgLqqSY+nF6MqSzDOSVG6bVHVNYIgQK+X6esZhuOxFaVBmFhZ"
    "DF2rYUMEaDcIHbmqB2SMHo2O+WSYM+djyFyi7JhpdTBKQLdB26IoS/R7me763fHWjePkr3nXk7xx6m2CbM2m7mWzKfOc+tG5s2Iy"
    "Iibf0WGa0vfUVwDW+jKtbJEksdWVI8u4CSl8Cw4uGZqaxG2nTr9oK7owP8B4kkNp/bJDB1fvfeePve3zf/C//2+P/st//W8//qkv"
    "PugDG/MC/T3VdCO8FizLK2FdrjftVeY+a7OfALxBAM2pJ766BqgHlJRrjDHwIKD9oTLmyv6CTP9ZnRKYhdwHDvp7Rx/GhB2a3inq"
    "scE8fofBLegMMCIcc4Bxo0eAzqTdhRbKeuplPnDC1DXK+7Mzras/88o0DIwBb13AZcDI7DW8+8heQ+pY24ZxUoqsvzydI7NoKaX0"
    "Lj91FZfEAtQ1+ViJoogUe/OCHOtVtXamx8HDCMVo3BG/Dfp9AgwwPBDQ0/5XLly4hFCLQvqtRNZXQKwA1NjeHmJnOMT29hCbW1u4"
    "urGJy+tX8O1nT+G502dwz1t+CAvz83jkG3+FOE7AOcPb1+7B0SOHIVtihAb9HpmSM6BtSbHauPoPkljr/HAUZYU4jiBbCRERg2AU"
    "YZM4hgiE9QJszK0LFKg1W1NVFT2HUoi1U7wkIUATBoEOzighWwNq6Z1EGuCFGpSQB156n4lW+KVo19rqSuvqUPysRDNPDUUiDwO0"
    "sgUYMZ1pktgo4I51mY6b5XcWf/PvlNSNuM0wLU1do6prVFVFMZkMMIez9jK6J5JLcCXsAt82DYm/NID3hoGrSWejMj2OMcPKTJ+f"
    "OqI/dhFJe89unCmGQaB9y5AHYKsXo0VNsdGdSRICNXFM84R5Xx4YNOMjjILOfDQe5x3R8YHVZdJ9Ugrf+Mtv4YUz5zA/N8D8fP/e"
    "pcXFz//Sz/3Co9s72x//9Jc+/w3sHQSz+/JeH5bl9QRH+6zNfrLpuxrQnP4WMTIKag1gVhfARhvGNJ5wDAKzS/eU8qDdXrEueDEA"
    "YTchvC/q8YZWx6eLPukDq25sIObdR0MFPct2ZhRNz5thaspi0A9qirHgyzNh1QuJ8vRgoB9XebtJyb1yFaz+j/e4th13WwFMXmnu"
    "p3UkFhYWPKBH9eFcQAjy8GqZJM5QVxUEp9hAgQoASUCiKBsdz4lpHRSJrJehKEr0ez2wtIe3vuWH8Qef+CQp4rYtyooUfsNwB3Vd"
    "Y2trGxubW9jc2sbVKxu4dHkd337mFF48dwHvfufbcdPxY9jeGWJ5aRGMM6wsL+Gn3/MOJEmMqq7Jaokx69k4z3MIzdQA0H6LOFpJ"
    "YEtoC6KiKBBGIbEjSlG8KQVcuHhZK3UuoihLSCnRyzLNBOWotHiybSVEoLR/noBYmyAAWIuIR8jznHbtjBM7pX3HxHGs+yi966oi"
    "Hz+MM7CWWXEPA+koFUVJzv20T5SyrMgDMxhF0VYKTVMDM2sI8/4ULDtjOqjX36fBjHFmWJYV8rzAlasb6A3mwJiCEMQQCU6Wb8bR"
    "oBl3pHMlbVwzf/lSQIeV2UsBeBbMXIs82GUe8Mo3rFgghHWmSPoyoTW9ThICNanHyCTaJxDjTFszBTBWXW0rMZnkWmzlosibjcyV"
    "q5uuagro93r6HPUjxoCdIYF5qiO/d2lx8fO/+HM//9j2zvbHP/Olh16KscHU5zRQ+E6Dmb1AzV7Hr4u12Qc231vpuxLQnH7yz9ag"
    "CMgwwJoxmt2f9d0BWPagM/4UOmJ2670X0PojDhXYEcyYXZx3BTUmeTo2+qdlgrrKgZ1c5nYA2C7nXS57VA9T6c3CXbPpWTBjGBNj"
    "cr7btGTAB2PMxZTSC5IBMNN6On51TZHTjBEXxq2+XnS0gzilSBHVAAPZSvs+TXsbc26jFCm1LxMASBISRQVBCyY4oBrMHzyKY8du"
    "wFNPP4NJnmNleYkWREEKtqPRGBubW1hfv4KLl9bx1NPPYjLJ8eGfvx93vekO1FWN0ehZFEWBEyduwnt/6h0IAvLPIjhH2ZZomgZZ"
    "lhEYUAqyrrViakyMiddXGi2qsYEc4UX1DgIszM/hM5/7In71l38BgaDftbbCy7KMWBytT1SWJeq6QZpY2G2dykVRiDAKUWlQEEUh"
    "MURRCM4F4ph0kaI4JFBQN2g1mBCcoyxLVFWFNE2tIz2jaD0Z5xYkMQatA+RienXT9Prn+oe05tqt1i0yYMZZml24eAlVVen+QQDu"
    "zjtuhWwltrd3kBclBGfY2CArtLqqoaC9Z+s26ajsTIGPzvCdAutmDjHVZ+aN7TLkHQiiN+Gs1AKEgdC6Mg7IRGGIOA4RRzF9xrHW"
    "n4kRRcSoCQ1WoihE20oUZWWdKLZan4ox4erJAKYYxpMJvv4Xj9uhfuL4UefCAQrrVzZtO3R17wDO+D1LC4sP/uL7P/TY1s7Oxz/7"
    "ZQtsFPb2PvydBDMvla4n7zQYm34em/aBzfdW+q4CNH70a8WAQATaLbuJSOwxAlbcBK+LOsajwzjQhfb63SwiaPJgbkH3/0whbGpU"
    "mF3x1KIP+Hnd5GujNXvDjSkFaS8xZq/mHq7Ofvk+xIEXENP+54Oul9i/OC5L6ujfu2XWxxhsu0FK8m4sORRXgJJQiqFtCMSAM6Am"
    "HyJSSvT6PTRNAwUgikOYJzR6M1wrQBr9IKn955gdftuS75rxcGR9rLz7Xe/Aqeeex1/+5eM4ePAABoOeBiUtRqMJNje38PyZF/HU"
    "0ycxNzfAf/L3/w7e+pYfRlXXOH36DMaTHG+64xb8xI+/HUdvOIyyKEn8ohcpA2qFEASqtMjILDoc3Oq+KKlI8VZbYjEGxHHfvruF"
    "hTn89HveifEkR5YmKIrWEhpCR62OowhVXUNAWB89Rpm4lWah05ZLorFiJaHFSVEUoayUZWEA0q3pD/rggnRm6qZGllIIh0qHVoi1"
    "+IxxZkVUURjq0Ak10qYFhIRjY3zRk+l0+r17fmecvgyxMmRplmM0GuPMi+e1WbsCGPkfuvHYEaRJgs3NbVy6vI4oIuZoY2MDVUW+"
    "duIktgNrV98zM8BmFuhYVR2vf8+CGXfMxOIy+jHGOV7ogRifmbHgJtLRzrXjxUAEVtdGSoXxJNfgkdk5LggCKOn8RpnNCmPAFx/+"
    "GsaTiR2RBw+s0OZMAadfOOtq7j2LAzbUDznn9ywtLDz4kfd98LGtne2PP/jwF74BB2r8l4upz79uEPNaAiCTrgvYAPvg5o2cvisA"
    "zYvPPLoGpR5QOkQB56LrQE7n6zAIyu1gXGLeho3py9VsOXpW45LZUa/1ETtlW7bDK93c0o0kJyLydRz0BbB+ORRmFBapDPqfnsWA"
    "HWaf19XDMSn2GfQ1yntWe9wkNfXJ0KnftOm2P0Uwm63rvVhyDi4lFKcoA0wxQE/6YAzQCozGv8rO9g6Mx1QlKeo2Ywx101j9kcDE"
    "F2qNRUvQARUmthHFYwrQy1L88i99GP/L//rP8eCffBlZmmBuboDhcIzRaIyLl9axtb2Dm08cx//43/9D3P2WH0E7GuHcuQsYDkdQ"
    "SmFxcREnbroRQRhgMsmRpgkEF1Z/JAwCSKlIp6WV9n2GQQih4ya1Unvc1a7tm7aFksZsmhbEOKJYPQrayzEzXntDGLP4uiFPwAyk"
    "CFyUJSoNOPJJDpEm4ILeRRRFVmmYC+7MuicTEtWFEfUszcIEOrTB3NyAIpZXFYU5aBrwmiyzjBVNqH2fhGGIPC/Q61UQIZngu828"
    "D2o00DHATsddarTJfFmWOswEgZkLly5jY2MTqY7H5DM7Rw4fRBLH5M24rrG0OI9z586DMY5Bv68jiKO7/zbd1sMzXZaVdRb23cCL"
    "39fNMSG4DZxKIqWgC1QipyvjHws9ECM491ZdhUBQ4FUGBmHM8yWxYK1y+mjCxMgyrcwYLq9vdB56bq5vAW9elDP177aNI2KUkhCC"
    "37O8uDgNbIR38V76NtOzyfV8vhxg8loDoL3SdA/aZ22+R9J3FNCc+fYjawywsZa4dcrm+ZNhxmZklz5sLBB8MZJHZVhq2WdavDwu"
    "uvLsbs4s/LSTVvoQ6wwDO3oM26EPSCX1DovZeV8xpUU8ypXLNLti6mOwhccmOeDi7mnbpDMkVSf/NFDxFaS705N3Zmp3t5dOEQeg"
    "OMVJ0tQOgiAA53pOlBJFUVoTZQWF4XBkWYi2bRHFMUx4K+Pu3zAypN8hrGO1MAyRpSlUQmbFdVVjoyiR9Xr4jd/4j/HJT/47/F//"
    "6hM487Vv2MXsyOGD+Fsf/QD+7t/52zh04jgAEqMUZYVWtkiTBLfcfBOSNCFF2DSlxVwRgKmbBmVZEZipW6vT07aaqWka246CUwRw"
    "EzyxbCi+EecCUov3wjCwIRPG4wm41gcxbAoUAcAsSwFQOIFKO5SLY2JR6poAoLF+qpuGLJkEc4yOfnec0/Vcx3AS+l1SPCl6D71+"
    "D2VZIk0T63U4DEMb5bqpK/R6GfpBCCQ+oDF9goOmkBow+jJeiIlS+/8Zj8mZ4dbWDp599jkSEx5Y9TohjYf5uTnbDlsL87hw8ZLu"
    "ThKDQX+mH5p+akFJ96Drx7bPz25HzPMY0GHATBSFyFIdiDOKtCiJYmbFBrjoEAZxaCKQUzRxuq/bZDBGekwKFOXc94Fl/AcxLdqk"
    "aprvVO/ReDIDxI7ecAiVDl568dL6ruPUSQsdi8W5gFLQwInds7y49OBH7//gY5s72//owT/tAJvdRFEvB9hMA4vrBTvXk+d6ANBe"
    "yQcz18Xa7AObN076jgCaF57+2hoDe4ABa6Z3JUlCFh16x2J7mkEMXjLMiFvcvcT0Ga1XY/CAwzkes6Nox0ID3umjTK33nXt6uAXT"
    "4iM61wUaMwwITH7WcRLR3Ul2RV4GAJl62OL1DwOOuAZ5SoMq/962XhrsOJbGXOd2g2R9MYVulG0B2w7KO93r9RHFIZn5co7L6+dw"
    "+NBBbdFSk/8WzpGlKfK8QFWRTxrDHrRti6IoMclzzc7QLtewB4yR+a7gHCKOMBqPyUIoDPHrv/4r+KmfeheefvoZbGxsIE0T3HLz"
    "Cdz15jdps2NiLKRstdUUw+rqMlZXV2hi56QQGwYhhQGoawIHXPsVCUMKalmRiXMrWx2YMu7s/s37juIIUC7AJNMKpFJK5HkNqSQE"
    "DwkUkSiA2BYuyO+Ijq6dJqmNSm7CGrQ6CrmJ8RRpcEIMEYGlSi+UYRggEAKbwxGZvWsRB0B6aYY9FEIgEgJNXWtmIsbS4iJOnjyJ"
    "Xr9HPlU4AyIG55XZJL3+aTP7yoiY8oJCTYzG2BmStdkzJ5/D+pUNKCnR7/fxN977Ttxy83F85nNfwk3Hj2E8mYBzTh6hqwo7O0Pr"
    "0Tjrpbaz76XiZhmYqf23Am0m/D6tOpaJekRoFjGKI2Rpgl4vw6DfQy9LrT6MATNGETiOQhvc0wcxBpybkBMh57oPusnAOODrbLy8"
    "DY6Zl86ev9S5pt/LkGrdMgBWid5vB8rr1mvHtlIbCsGtonaSJPesLC5/7qP3f+ixze2t3/UYm2kUOw1sTEXN516AZPrYtfLvBXJe"
    "Lqi5XsCzD2y+R9JfK6A59cRX1zhjDyilyCGeXkTPXbiIubkBVleWEfEIZVWibbSZKnMgYnYXwiz4cYOYPn1GxuzfFDMAR1npjs6t"
    "/yjmtQNALj+V4GgSf09nbj7DmuySZmcE7TvDA1JmxMmpMpnNz6w/G19pk56dgzEFprgza/efwYrYvGcx9zY7R8y2tTJtqpyZtnOa"
    "Bh3oMLAVufHEcVIMZnRdVdXItVhnYWEOSpHb/6IobaBFBWVjAJHTPaNk2lLUac4sO0GmxRJVQ5Gz+70e3v72NbtQc8PaiQBABoAY"
    "FylbzM0NEOSktGksVepa+25RsKIvqRTqMcU9MmKdumlgxEIkUiIlT8a5VcKNtPm1Ca5pgqMaEVOoA1amSULMVCshwlC/P4WqrsB1"
    "DKlAt6nxXgyQ1c9v/6N/jL95/0/j3T/5ExBarNS2LdI01e1GDGdV1ej3e6TP1Jr4SWQZZVgnoxuUJAmqukZRFJCtRF6U2Li6iUAI"
    "DBSQKAXEDOTE0E9kgl8WJYqcHBmOxmMMh+SV+erVTZw8+TyeefYUxuMxbrjhCH70vrfgfX/jJ8GTWCtUB5BSYmt7B+tXrqCua8zP"
    "DbCzs6P1eiLsNrycqNb4opkeacbBJeXpjhXnwJJEiYEFM/1ehn6/h4H+y7LEKrOTiJHEfYJzcMat8r5je7kFHCbqeQcF6HPkINut"
    "s2beMpZzjDFcvLTeed6DB1e1SJ6e9/L61U6buKE7O18qKBtKYmdnCKUUbrjhCIiZEvesLC1/9iP3f/Cxja2t333oK1/8C7w0sOk2"
    "tPt8OeDleo+9FLjZ69jLZW/g5fN/A9gHNm+E9NcCaJ795sNkfq3kmlRap4SoFCgGrK9fxZNPPYODB1Zw4sRxrCwvIQxClNrE1Ypi"
    "2DQro/kCb0dj0swxhhnF1w5TYQGKQUTQ+ityBtQwxtzwVj6YMiyPH0CyaxVFebhXVVNuF1hIpcD1g5vJd3qi0odh5nTvLjBVNJ5+"
    "7RV2wnUldazApoGMJ/4iBVgJa5arpHbextDv9d1MKluopgXTOght0KLX7wFKIYoomKOxqOGCWxEHAO1gzIGBIGDIcxLvNHWDJE0w"
    "Gk9cTCQuEIgA49GY/L2kCRjnVo/BpTHqukaWZQjDCGVVo9fLSO+DkX4MsSOkg2Isj6q6RlGWCINAlxtpcRKFdTCeb43ZOWPAznBE"
    "+hQBOf4jpokCbAouIFLhQBdj+h0zHTuKTL1N7B/yVxNoh4QU8JJzjr//H/0K7rz91k4HJPGFeV5io6q6JOV6LfojoORAbRAEVm8D"
    "DIg1uzMajXH7bbfi8Se+Bc6dODBtWvAeAMzp+1RAnmMymWA8mWA8GmNnOML29g42NrawfuUqnjv9Ap58+hkMhyP0ehmOHj2Kd79j"
    "DTs7Qyxkc7jj9lvw1NMn0R/0UZYleZoOAozGE7St1KDOAPNd1prO0NfARh/ymRhfPGXmB8YoaGYUUTDILE2JmRn0MOj10O9n6PUy"
    "pElMoS80o2JIS86ZHaPkTdp4kubWJNswYU7Jf6r+Xn12+z0e+wuoQpYmkLIF0AU7ftkzez8F1E1lgczm5hYmeY6F+XknUtdzieDi"
    "ntWl5c9+5H0ffGxja/P3Hvrql/4CNJ0YcGMaci9g81oBmmuBlt3AyrXOY49j8I5hKq//ex/YfBen1xXQnHriq2tKqQeg1JrdIekd"
    "uwUI2nFV0zQ4d/4iLl1ex4HVVdx00zGsLJPjqLIstSjKLN7KsglUCHR3047fAK87mknPt/xhnVN2aFqgxNwxaQABs2DG6ZYoeiRv"
    "5wemzUv1jsyAIYp8rfTw0OPGu58Rdxn5ufGz4zh07wZTmwwLbLzhqKYv0Se4Bi/uiHtuS5mbu1gWxgA75YCN2U0qhazfRxxHpDja"
    "tqiKAoxxsFZCCA7OGYKAFucgEAjjCI0WRQWKFmsRkL5JKyXKqrazq4Ky0ZqllBiNxtpZH8V+4iEpGicJmYxXdY04irSui343rMX4"
    "6hbABObnFzDJc8zNBVhcWkBdk3mzWQI50155FbEcnDHS99HAK4g1S1I7XzV13Vi3AtBiizAI0GrT9UZ/ylZq/yWBdbiXJIkO1tnA"
    "uA6I4wh5UaIsK+3Jlxb4WntRDoMAt91yAqPxGL0sQ5jEkHVD+jIAZEuAsWm1f5yyRK0DZgZBgCSJ7ZgzLvaZDq5puj1nDL25Oezs"
    "DPH8mRdR1TUWyhK9rIc0z5EkQ4ggQFVWGI5GGI1GGI3GpCuzvYMN7czw2WdP4/FvPYXxeIIwDHH06FH8wJvvxJEjh3HmzFksLC2A"
    "ZQPceOwI/uqbT6LX7xP7qPs/sU6JN0hh348ZC2Yhhu8xWM8FzoOwW+Oc/gp59Y1j8lTdy1L0ewRg+v0M/V6GLEuRJon2C0NJmhhU"
    "0P59vGCZxpjBvHuAxk8Y7hYPi5LgAowzSC+IrOn7QRCYgJQ23XDkoHURcOXqZgdgmeSOke5VnufY2dkhIDPJvZh3agZMmfkoCMQ9"
    "B1ZWPvPR+z/49aubm7+rgY3P2EybvLmX0n3QVwNUXu35a4Ee7HLeT/vA5g2UXhdA89wTX10DYw8wqDUJ6AWzq+tiBpHSPxwF2+Dc"
    "+Qu4eOkyDhxYwYmbbsTK8hIiHqIsSUnUbbr0jkf/ZxZZeL8BTN9Z91wHhswOymIuBvsbjEOw7pgwkxc5xwOFszHFG3AAI/aAFZ35"
    "llnMy6tMHmkYHUVtwoxdlZ+mkIpGTWr6tOpOVGaiNIDQZ2XcO3FlS1OG12bO6Z8rUzGFNM20CalCXVUuZhODNdeWUiKOIzA94QsR"
    "IEkSu5C32hOuEau0bWufhYFZJ3NMtqjrBlkvAxRZGUnlonWbcAAG/CRNgzAkk+yFhXnykaKUdUrHGUecxKjKyj5p27RWt8cobrba"
    "CkjpugtBeWXbkp4HFJI4RplTlHAC1wp5UZAYjDMbv0q2pJTcSr2AaYAkNKOlFxPIlhR966YBFFCUJaDbyFjWSCnBTb9pW/tulFLa"
    "1JshExzbXqBPGwRRMwkmfxSGqDXIGQz6uHR5Hffe+1b8m//3kxiPJjhwcBXzcwNkaUYLNCNT/aIsneLv9rYGM1fx+BNP4fkXziLP"
    "c2RZhre85UfwE2+/Dz/1kz+OYNDDwsI8zp+9gCM334z+yhIOHz6Ibz9zCpxzjMZjrF+5iqZt9DhyY934T/IZ1mlCYjbRwKM2Ftpn"
    "DIUkSNMEvTRFr0fsTL+XoZdlSJJYW57pfqiBllHkNWDGABzONfsKQKkZDTlvI+TmJjvedB/2l1SlFF48ex7T6+zS4gKqqgLnAucv"
    "XtZ50cmjFLRoKcdQB2QdjycayLi2tCJ424rdTQ21WfDWAyurn/no/R/6+pXNjd/7Ewds9Ow3A2ymAcLrAVSudf56AMxudd0r7QOb"
    "N0B6TQHN80/++ZqCZmSUhAIDZ9ztoEyyky6gYQjMrst437WMzaV1C2xWV5YhRESeUPXiYkaRHc8GyEx/Gvzi6YnoA25XBEegKEhd"
    "nHLHvb5sp1K2RxmgCalrKaT1ZTpN4SsAm7J142hQww0bpHTp/gPPDMHuVGknJgPSOq9gt/Fr7qV2OepEYrQFJGXLJElpIuekUxCG"
    "IbZ3dtDv9Wjyl8o6NDTRnc2jBEGA8WRiHe0RO0DMglmwAQo/0MoWTcP0IkKgxC7qnCMvCmQBOY3L8xxKEtuhFOmtQC/g1upEOR0Y"
    "cjxXkdm1AmReWNZHCG4DTTLG0MpWK1WSPk2slViNvkul2ZCqrMAAG5/KiHhaDcpIfEF+W8xCa+6TaMumpmmscnQSx1rHpUQcR1qZ"
    "WqJpyMkeeTh2TBvTgIMxhtWVZVRVjbqhsTOeTAhQti0Y58gnE0RhSKIpDWS3t3dw5MghHD9+HF/806/gTXfchpWVJYrCrXVw2pYs"
    "x8ajMbZ3SMxkQkyYQIrHbzyKg4cO42O/9os4cvig7oUcSytLeP70Cyg2N5BkKRgUtra2UJQ1lFTY2t6B1Lo9VpTiDTDW+c9Z8vif"
    "TJvTBzpelxEtpQkBmSxL0UtTpFmCXpYhy7Rlk45urUDMmj9WjUjJ+gvS+j++uweuvUVbtw2MWT9Hvkm2P2qVQRjeRqfUQNtsbfr9"
    "DEuL83Zwj0aTzjh2jMzExjCbTHJreenmEfOdNlJufrSnaO7w2lII8daDKyuf/sj7Pvj1K5tXf+8Lf/an/x5dq6hpUKNL2hNcvBJG"
    "ZS9w8nJAzfWCnd3SPrD5Lk6vCaA58/QjGshgDQqa5XCTqt/LlV6kofQkoY/ZtbnDm5Kp7bnzF3H58hUcPLCKEyduxOrKCiLBUVXa"
    "ekazKlIBkPBYDg+QqOmdkRYlKUAxRZY+YJr98VgSnd0GfTQD3EMKGtN4iU39hp6k3L7HOGRzohwzqTlgZ7GLmiogwvHyAAAgAElE"
    "QVRfTY2pmaEFXYbbGU6zOaT3oQ93C9dgw02qMBMzByCV9xQcSUpu3cE5oGP1SCUx6PfxzSeewt133eEAlb4/mU5Lbeaq/X1oRqSq"
    "Kq1Uy7XehvPLYYAL5SMLoiiO0DYNpFTI0pQiFNe1ZbuKotTNz6xoKQpDcEFKmwakkMIu0IwniCPytGv8wBh/OgpAVVbWfJv8gMBG"
    "A6+qCiIgS6VLl9exsrwELkiBlICQ06+AInZJSfJPYoI4Sg1wAiHAhIBQCjva5F0IgV4YoN/LkBcFpCK/Nql2jmdEV1wv4E7E6RZZ"
    "wcnrcCDImdskz8HAMOj3URQFyqoi5WetTNzUDd7/vp/B5cvr+PRnH8INhw/i8OGDSJMEXFtulUWJ9StXce7CJVy6tI6yrKCg8GNr"
    "9+BDH3gf5uYGOHBgFcdvvxX1cISz585jMBiQvlIU4sLFS0jTFNvDMdpW4vz5C1CKABXAMDc/wHQKAoHuRoGAMDOO8LSOVagdJcZx"
    "5IBMkhBw0WbZJFai0ARxFFoW0babBsBWHCxpu2PHvQbGsGO46wjUghrJUFe1HXOdcadIH8cfbwDw7KkXrHiLAThy6IDWh6JXe+ny"
    "up0SjLLvcPhSQMZsmNzzmc3nLHOr78sAXxeJgM3qpz/8sx/4+vrGld//0te+8pfeLOR/Xg/oeC1By173fbXfd0v7wOa7ML1qQHPu"
    "5GOfiKP4w1VVWfFBZ+/hCXfd4AYUd46lFhcWcPbsBdoRmfMesDG73HPnL+Ly+joBm5uOY3l5CYEQegFzjIqvgGdAiC+btsPVm1B8"
    "UZX5YiYAHxDYKzq7QH8S8BLrWiJZBVsASos+rJhpihGBmaC7c14HFJndk6m00r+5rZ+ro/3UtLny8pj6O1GSB2TcjWgC5xxGH0oq"
    "hSAMaQGGAgKBJMsw3hmiRYu77rwNZGrcos5rVFGNXpYiCAOouoFUClEYYDFZoEVQKQqTICU4I70Drj2r+u+VMYZeLyPGQfvioAWO"
    "EyCoagRhAMbINLUZUb9s2hZhEJDvmVaSkzO9sNDCxbX3YhAr4gXdFJrFaVuJsqRF35hzkx8buq6qKlRVhfn5Oe1cTVhwCr17TjRI"
    "4uDgIaluFyVZNsVxRP5llPY8rAGRVBJpnJDiMOfWbLfVIQoM20T1CtA2LYTQ0bulRKWZsTAkC6tIM2LGVN2YGIdhiOHOEIwzJEkC"
    "oXWB/t7f/XXc9aY78E/+6f+ELz3850jiBINBD1vbOzaq9+HDB/GB9/8M7r77TiRxjB/8wbtxYHUZW9tDDHeGqIdDijZeVvjWk09r"
    "ax0BIQIwLjA/P48kTbF+ZQOMAXlRYH5+zo1h7291Zcm+N9OHzfN3vPpqZ3gGzNjgkBrYJEmMKCJminki4g4ggdON8TViDbNmx5e5"
    "Vklrns3M+NI/GJgNXmt+K2jLQenWZzu07VRCP44cPmDH6rdPngZAYnpS9t1xQMbXkdFj2QAZOzcyhsHcgO6oN6I0P/ribmMJ1gVC"
    "AEMQiLeuLi3/8Xt/7N3/7sGvfOE3MKswfL0ABtc4fz2g5VrXvdT3vcqc/r5b2gc230XpVQGaP/qDf350Z2f44cUFgSxL0bY0WTmF"
    "OPd2FboAglnrAIabjh/DwYOrOHnyNE4/f8Z6YfWTubLWjM2ly1ewurKMm246huXlJfCAdtWGPnUMhwMvRvQ13fP8BXwaV8DspPYQ"
    "K/n12825lX8fuoWjpZ2SrVMG5N797LU+I+MDHGUmeFLiYTOgaHfLJf/cXvXcLdlyOpMiOcCL4wjQ7uyzXkZ+W2oKcEjBERVa7awu"
    "jil4X63NnIMwRJzEqLUFDxfc7oadCTaHFNx6EjYiuUZKxFEEBYUwEAAjHzChXqTSNMF4PEHbNMjSlJSJlTYz12yP89DKAUYRrsl8"
    "XO/GW2I+Yk8MJISAbFuESQxoBqdpGgIeOlp1FEWotV8ZY9pLcZnIn06tPeoGpJCjzdeJSSqKEoNBH0JwzM3PWQbI6GhwTmBNeAsx"
    "ueknfzWRYRo4B9O+dyrdvv1+D5M8twBmkucQvEGapmiLgkCvJIs0BtLdEYHATTfdhH/6T/5bfPbBP8EXv/xVPPfc85BSIkkS/MIH"
    "34df+eUP45a7/wOgHeHyuQsWwDEAV65uYGt7B71ehslkgrppMB7nWFpewtLSEsWgCkMcO3oDjt94FM+efK7jNdf/6/Uy3HrzcSg4"
    "cRDnRtGXAI1R+DXsTGyiX8eR9ehL/mOcCNqCEOZviJTdgPh+oczgIQeLrgwFN7atfhIsniVA3ioC08rdx8yF5JxSGyEwhm8/e9rb"
    "uACLC/Na6b3F098+hZ3tHeRFgcuX12cZGX+sep+MMRw4sIrDhw8R8J/erNm7dY+4ahAzWFXkMqGY5O8/vHzwv7tw9dIV73LmfX+5"
    "AAYvI+/1XHc9318OyNkt7QOb74L0qgDNJC/WnnjiKRw4sIqDB1exuDDfATYUnwewDAIws5CaRTJJEtx91x24+ebjOHnqNJ5/4UWa"
    "6KfEIUQOkIfVcxeMVdQKyCpqCSwM0WgFSH+UWtrX7IA6qzn1VWvBo8U+Dhh5Eypgn4kxzPiXMM/jK8/6IMZBAdgJgjNuJ7AOm2Lu"
    "xXzApfVwzPMwV89p4LKbCXZHF8G16lRdVXeW8Nky7z5VWSHtMZw7fxF33Hk7yfxaMteOIqCsKNDi5z7/Jdx5+60IwgC33HyciuMc"
    "YRxBtRJNVUMpqVmUBlEcQUliQqKIrDkoUCIQBgKlFjWSCXiDuqkRBqELEhmFmIxJRyQMQ/R7GematMTUTLT+CMWhUnYhZIxpRoSj"
    "aRsozf6QR2RotolMyMm5HoOsKXCiCEO0WrxlHK9xIaDdp2A4GiNLEzCtH9Q0DWptOg7GELbSKmySNRgBK84iMA2+lFSaBSV9oLIi"
    "B4AAiRuallklViO2AtNBD8MAQSAwGo+dGbde3HpZas2yY838NDr2E8UZYijyAqsrS1hdWcIvfeTncezYMXz54a8BAI4fO4KP/dpH"
    "cejGowBCQJCfmvMXLmEyydFKiTzPMckL3HDkMNI0xUq/j4X5efR6FHX86sYmJuMc/X4PnHO8cOYs6qpGtppa0alZJ2+/9QRuPnFM"
    "x/xSnX65G0sTBARuRBBYRWkPm9uNDNPvVe++ADhQYmVLqjsmmAVEbq6x40y5zZWZ9dwcY+9uo6ErqaDQ2LIuXlqfYW5vvukYXjx3"
    "Hg8+9DAe/9bT2Nraws7O0Lq3oFJtJS2IMs904OAKDh86pOOV6Zmgs/Ezs8PsXETj0AGZPM8xHk8wmUyQxdlbAHxOX+zHhHq5AOb1"
    "BC0v9/urBTadfPvA5vVPr1rkNNR+Jy5duoxDhw7gwAECNmlKFixFWaHVli4AsQjKLsSO7qBBzJAmCd5815249ZYTOHnqeTz/whma"
    "fD0g5A/yumlw/sJFXF6/ooHNjTiwugwhKHqyoV59eTv8wavpW1Mk7/w24Ke7A6PruD02zQb5qcPIeBONq5Muw9DQnTHgTSrentHt"
    "Vv2ccGVOgUYDUMzkZgGbudCf/Hy/Oxb9eOAJDpIZVuK2W04AmlUxmQwbUVU1fua970ISx3jhzFmtSNlCSAFmgvIxoCwbBEFIQRe1"
    "jxeUJbhelIVm/aq6sorHRiRlFuyqqpBXNdI0QX/Qx3g8QZLEEGEIWZbgilvxkfFRIxXpT7UtWRmZdjOO7JqWomK32kzbKBczMApr"
    "wHV/1OyHajUgCQMKdKUUWBAgTWK7+65r0qMwujlMCMRpAqn7a5ZlaGXr+pOUOgJ5a33NVCVFBDdKs1zrjBR5QZGdPZaT9DsUIIR1"
    "PChEaPWdmrpBFBHyEpyTw8GghWi0pRdglYehFNIswc+85134+Q+8D3VNujZIYkB73UYxQT7JUVU1Nre2rb+dMIwQRhFWlpfR62UU"
    "xLJpCDxVNdavXrUxpuI4gpStDsLZHVfHjx3B6sqy6/emvzNm3RJwzrRyObEezgrJAQswEs+6MCsAB9esj4f89eDxwb4FNEormk95"
    "12Z6o6LQBTRmnPnfuVJQRpTrzQF5XsDcSimJd/74ffj3f/Ut/Jv/79M4f+GiFW+6KcXTk/HADQPDqgUygZt3OoAG7pg335n6GOeW"
    "RVFgMskxmYwxmeSo6waAsnsu8/jeS3slAAbX8f1awGf6+/WUudf3VwpspkEdgH1g83qmVwlo3CDfGY4wHI1x4eJlHDp4AAcPrGB+"
    "fh5Zmmi5eakXB8B6dlFO+c1MSAZgJEmCu990B245cRynnnsez5/xGBszqdhaELA5p4HNoYOruPnETThwYAVCBDakgvLkyvDua/V2"
    "AKv0agCKYyQcCDIgxld8Nud8BsTVsasn4+Y9Zn3wWXzHOLwZz0usMxHtxsj4dbF3/v/Ze5MmSZLsTOxT23z32D0iqzIzllxq6UZn"
    "Uaqqq7qrG42dBEQ4nIEIhCRGhoDI8DAHXrpFKMIDLxShcPkNPABsDDADUAAZLoeZAdAEgQEw3dWD3mrLjC232Pfw1dzNTHl4ujw1"
    "98g1srKyUVqV4eZuZmqqaqr6Pv3e0/fYc6FAirY3EkJYj8msTdli1Dawg5Ao32IhImPeIAC8kC5Ku8jUVl4BgXq9hl63B+EJXHz5"
    "ggktEIUqTEIQIO10EAQh/EIEBCFogZchy1qA70MmBHaSpEdCQoElz/cRKkYmGZBH3ygMDcvW7/dNZTwhIIW1PRFQMl6pnTylnpE6"
    "SGMQEPhLKD6RNkrW6iIdfBKA8l5MfVmDFM+3npoH/b55LwTAaBdUpVIme5wkge9TLCzP9+H7GdLUR49tBw+iCEEoTbykQAWRpGjW"
    "MQZJYgyHdX/TgEqrp7J+H4Hvw1dRnXV0ZwKefQWmSoiiCKGUJlK2HwQoKCNjrarS8a58w6L61HfRxMHBAYQQmJgYQ9wnVVKpTOqz"
    "2dkG+VBR4KnfH6DT7UKCwjHo+FmtVgdSav8tNvm+h+npSQUs7TgwDIjqtRrY8LGpD7QtH23DZ4sqqVS+vvVFpEeBPtQLk7MWL/qT"
    "7HvoOENmBpMtn2fycez9QHG4JCQ2t3chZYaJ8Tre+JlX8cMffYB/9zfvo9vtGhcCBsjo8qlya1uz2UYDF+ZmEQSWkTnrUyc921EX"
    "StDvUx/jjIwGMmxKyK8YmetR8/ujAJjHASp4zOOnBTnnDmw+BzXnm54S0AwLz2aTHGxtb++gMTuD2ZlpjI+PoVwuI0kT9JWNjVYJ"
    "OfQoZaIyoz+FQgGvvXYdS0sLWFu/bVRRjrBl/WRgjIcPMDfXwJXFBczMTCHyQvTiGFnKdOFKoAtnecHLY1kJy+bY66XatWJ7rIBb"
    "GjBBpnZh8WEANYnxIWHRlG5UwCnH8ERq8pN2Ms0/37lUIy/FlhnBoCqqo4fb6yl/ztzolWqhEKHdbKJSI3uG/f195dXWx+lpE1eu"
    "LJLK4bRpGIZCoQARBECaAUEVWdpCWKkAXgkf/uB7uHtvE2+9+QbGahVAeBDFGpD2kLTJ2+/ExAREFCLt9eCXK4Dyg1KulBHVaugc"
    "HiGKItRrNWUX4yEoFoFeD3Eco1qtkKpQtQPtDPIBKSHCAKHvQ6YEygI/gCc8ZQ+khY5AtxejEIWQmTUqHihQlaRkG9Tut8kORYOu"
    "NIWAb0IjaAPfbreHIAwIkIQhRBDAFymCxNcYFNkgMVHKhSB7jygMIVWQyrgXk28Z38P+wRFuLq/i/sY2pJRYWriMtfU7+NpXv4y5"
    "2RmUSnYnEDwPvi/R6ZD9T7/fR6FYNICgWKSt4qFPAKoQFWhnlBDwBYFT0RWI0gxeuQqgjImJSfh+aJkzBYpklhkj7kjZsERRiG63"
    "i/2DQ3TaHRwcHOK77/8d4rinwJk7XiqVMqoqUrddDAk7ZKQdgxqsS2SQmXIhIcnDrmTjGQZWaKNzO6CkdAGRC5AYGNHsUE4um8UC"
    "m7AkK7MBH2x8SgmcnrbwwYe3cPllYlW+/ft/jO3dPbMYyQMZKisDMjMNx0aGg5ZRgCY/T5BqaaBUSxTOoqtsn4Y2MJgWd7Zuc4Dz"
    "uAAGn+Lxk4CcRwU2eTAzBGw+Z2vONz0VoDGGtlrIaywipVFFbW+RKsowNtzGJk21Bzf3bWvBSd8AkOB87dXruLK4gNX127h9+x4J"
    "K32Fulxb6A8GA2xsbNF279kZLKmQCiIUZLisjPzAn+moW1S5ePwXSPOX25zotuDf3UEvzP06Ow0ehMlKP0vR9qpR9bxr1Uhs8uaJ"
    "Pe5hoMbZ3ZXPR5VNOs8QrL6AZnM6nR72DlYxOTmBeP0OIIgmj6IIhYgCQq6urkFA7xqSuPjySyhXKuh3e/B8H+2DQ7Q7bfhHRxir"
    "1/F3P/gxXnv1OsbqVWRZhvbJCW0RDuzuHFEsA70O/CAEBgO0220Cq1KiyipUnpwDsp6Kxl5CEKZIkiaBl0IBaacDv1xDIAcErgD0"
    "O11E9QkI+CgVush6MbwwQKTiQEEInJw0MTk5jkypwTzPQ5ol5LCuECFChOOjY4QhCfUwClUMKDIiDYpFIMtQUOqyWq1KUbeFgNTB"
    "JzOKt0TshVQu9qURmsIjew8hBL77vR9gYmIMtdMmrizOY3p6Eo3GNO7e3cD8/EV4nod33n6DGBmwqPaqPFkmqf2yDNVKhVigTCrg"
    "lJn+kiQJkjQxgTajiKJM9+M+4jhG3GyiXqMt1lEUwvPIV025VDJOBGml30O/PzCqQ4BUeb04RqvdRrvdQbfbQ71eBe/sQgCT42PK"
    "QaPgowpCmpGjwIwwziwhFWTxrEGvyI0nPRo0V6vHpzswpInZpLcEcUBDw1jPIZaVGXqeBh5S/67eqSAV6O7uHv7k//w3mJkaw4cf"
    "fYJPbq2SwbIRmY8KZGDyhXkOq7LgqmTKXAOZOI6VaokYmUQ5d3QtAJ3ZQ4MY7kVYl/Is8PA4wONheTwJMDnr+FEAy8PADE+j6gr2"
    "/XNgc07pKQEN2ICw75O/uWarhdZaG9s7u5idnUFDMTYlrYpSVLen7lTWHmpCUvmbnMnF/euvvYKlxQWsrK7jzp17yl5AC1xhQiPo"
    "VfPGxhZ2dvYwOzuDxflLmJqaQqhAj0M72yUTfQrb7zSjJEzlWC2NjYpFdgak6PMGcLloxIIZaa43hssKnAF2dtC38y2r+RWTAVyq"
    "OBxscUNKXgiZv9e0B6+HmsIVQ9PrxfjxTz7C0uI8tEFmrxcbQBWG5KdFKP8nF+Zm0e50QEagh0iUnYrCSOh0u/i5r38FaZbi7t27"
    "ajtyhnq9jsPDI8QxGd3Wt3dQqVZQKZeJnYhjsifQW7+DEEnaRdq6q2xtQkRRjO2tbaqEAlJBGJJXMBEBoo9+u429vX28XJ8G4ANe"
    "GV45ABAhCAdI2034pSJmooh2HIGM0z0pEYURRBgAUiKJY+i3qVVczVYb/+r//tf4tf/4F9G4WCF1kO/BFwIIAoSlGiAHgAiBrI9A"
    "Ssh+H0XlQA9CAGEIJAk8j1RUWSaReAm+9tW34Xkejk9O8Qd/+K/wT37z1wEJXL70kkbqtANQqm32aWqZICkhZYpyqUQ2SF1iRkql"
    "Ivm56cXGGaIABdIUrIvQVnNSP0VRhG6P1IJZJhGGdieZJ6XZEUWO8sjHUL/fR9ynOFWDwQDHxyeI1C6e6ekp1d+t0KdYX+7uIUgJ"
    "pkzWI8d0b4fBEe49QoDFeIN5npO/GbJkc6OHuV1kmGHkPBew1zn5saR3VmUyRbPZwocfL+PHP/kI9+9vYnn1Nvr9gR6VNP5GABoY"
    "1VLO2NcpOy+oWxBSLXFj354LZHh9IJyWZfM+j/XEjYLPE6g8Sn54QD6Pev+zOqfTmec/V0M9XXoqQJNl8r6lZti7yb0mmUm0Wm20"
    "Wm3sbO85wKZaKZNzrrhvdrIAcBzZOSBAgYNyqYgvfuFVXF1awMrabQI2iqI2j2aCO0kSBWx20WhYYBOEAfkSkVl+KlITtwtmhKe3"
    "VtvsHQZEQk10nGZmefLJxsA3t1dbUKPd/cGqyEzVciAmxzYZgAeR285tQZcpiWC+aaSus9OSMC9Vq5sy8v0yOTGOzc1tBGGAg4ND"
    "JEmKcrlk3oV2GFepVNBqtTC2t2eo7Gq1YoIjCiHQ68XwfRKQvV6s1ENV3LlzT23lJiq82+3CP/BRLBYpDpRyyleplNHpdg3AEUKg"
    "WqkAglQlJ6eniOM+7QqREuVyCcXjY0yMj6PX6yl1SwFAAqCPfrMJX3kd1pG5016MdquFbo8iV5MtTMUEnoSUiOM+jo9PMD09iSTN"
    "4Hsexmdn8dv/9W8DCAGkkFkMEUZAGABZAqAEiBKALuAVAUQQpQRe94h2kZTL0PZVQXUc6Hfg+0Cv10NF7QwqFAv49X/4qwijiNoU"
    "gFCqtHK5RNvgAXhRRO8m7sMrFeF1u4iE8ksThhgMyKlgEPjwAx+R2grv+wKFYoHyUKqyMAzVDiyKe5VmEnE/RqB2X2k2x9fgKcvI"
    "l1GW0fsOfMPSUHBQH3EvRqVSNuEZlPYLQpCnXBNJXeheKdRmA9v38+ooPS441DFdXNixaMavzluhNw2Y9HiBcy/MmOeLIiu1hKPW"
    "NrOFBKRM0Wy1sbG5jVvLa/irv/4e7m9sUjyzEeCFLyw8IdBokKPDSxdfQqvdQa1aUQEr2Zw0SuSCxnmapsYOq9ftoc2ATJ7pNbcL"
    "3ZZQi0GJQTLYBQEaDWo4C3HeQOVpjs/juqfJnyfeg8z5z9maJ09PBWj+i9/+b/72v/vmP/vbixcvfKVULJrfXW2LMEJQCEGMTZsY"
    "m7nZGczONjAxPp7b7p06zxE8L6EmL0mjplQq4ouvv4KrVxawskrAJhAK2HDUoe7Xnoe3d3bRmJnG4vxlTE9PMmCjB3F+PTU0HTHD"
    "PzvHAdI4GjNlhVoGqnKb+VBPvjxf9mHYlRFAZkRpzK/GREY9RONNcwUHP+zT2f1krtUPYZHOJVHtmjnwPA97e/totTool0vY29s3"
    "bub7/QFKpRKisI+m2g3XapOb/YJycBaGoXEwmClVS7NFbvP3Dw7NLhRPCJTKJSVIA7TbHdra7Puo1SooFoomjzRN0el0zU4oTwVh"
    "9DwPp6enFKBRSoyPj6F52kSaZQbUtNttnJ42USwWUIgKODg8hFTO6TRQ07F0wjBApVyGBPXFOI6VoKDYVbo9S1IiKBbROt5Hp9NB"
    "EAYol8sojk2o1u6DgJRE0jpBUJ0BeieI+32kSYp+3IeXpAgKBSAmb7DVSgWDJEGlVAYQICh4GK/UgbRPjB4tvYFCEfHxEQpRAV4U"
    "AkEJQAQv7AAoIU1baLfaZFskBCoT45D9PhlDAygWyBFgEAQI2a5BX0fBBhBFRfWeBggjWqQMBgl8tStsEPfJU3GBdkMJKVAoREi7"
    "GbI0Q5om6Ha6aLZaCIKA1Eq677N/2vhaDyKn/0uJEfLXBS1GVaTBjjXxFRA2LpuTv+V8DCM99HxAudJmY5OPLtdJZpZmOD1t4v7m"
    "FpZX1vG993+AlbU7ZKv1ECAjhMBco4GFhcv4j258EbdW1uH7Pl5+aQ63ltfBNzHoQrpTobTsWByrnUsddDpdh5EZZfisq6NbMcsy"
    "9Pv9H9zd3/gJgAguoHlc0PIw4JM/fpQ8zzp+FOBxHufOSnkw8zmwOYd0Ro99vPRrv/yNb77+6rVvLcxfulgsFkAThz0/2oiMJsVK"
    "paxsbGYwPj6GYqFgdkWlalcUZQI7kaiBnVftaDXIqmJsKEKuu12TLaCIgvd9zMxMY2nhMmZmpuB5tNWYWAPzaAUw7ATrGTXOMEDR"
    "dRsCD7qshg1RU2T+LRjbGWEnb6ZeMkAFbMIVwIgxMcy2mKWiqw7TqiRHfcbqresjlddemWU4ODrB//Y7f4jr1xZRUUCDgALtRtEe"
    "WpvNNtLUOoYjHyEhyuWSobirVbLdKJfLiOMYrVaLnLIJYQJDZhn5gSkUi8jSlGIXecI40CM1R2gm6SAIMD4+BilJVRnHtBKtlMuo"
    "1Sqo1WoIggB7e/smntSFuVl4nodyuYRWq21CA5RKRVKnKSBXiCKEYYAwpJ1Fg8EAQgDHJ6fwfR/VSgVjYzXaveUT8KEXRu7+BYCo"
    "UMDM9DT8YtF0pM7JCTrdLgb9AQ4OD1CtViEz2tVVrtAEFwQBWq0WwjDE5MQEwtoM0D8BogpIlki0D7ZRKpeQJikZXAPY39xEtVZD"
    "cWwMQAVACiBDc2+DjHK7XVxdWkShWgGEQOvwCNV6jUBRFAFeFQBtJUZKEdHTXg+D/gDFsTqgVIJQDgLjTgcQZB+jbdaiSgXw9FZs"
    "Adk9we7uLpZX1/HxxzeRZhJ//Cf/DzxfYG6uobxlU//2PB+//g9+Ba++csUVbTmwfsZ0Y/LhQF3vZNRDw+SkQRTLl49N/VAvN3j5"
    "7iNzii1I0ixD85TCP9xcXsN33/8BVoxqiY/L4WMhBBqNBhYXLmP+8kX8ws99Bf/ub7+Pza1d1KoVs2jc2t6zdeHTnsz7kVHGvt3u"
    "kGrpzCR1PVLEcX8r7vd+Z6d58G0QmAlAgCa/EpTu3UO/nefxed/zOOeetiwYcQzgc1DzqOlcAI1Ov/bL3/jma69c/dbC/MWLRc7Y"
    "ANAsjX6snVhoEFarFbPde3x8jHaLKM+y2qDQ0Ufr/BxAwew74j5t975zF6EOCJdjOriwD4LAxIqanpqieEEqpIJtLdLle0M+J4Tz"
    "yQGHQTwaKLCI2nr7sM4XipFxwBNcoJQHRRxwWNCWA0CcpdHXmfJkxsW/dgbIbQG00aKjVVN5Hp+28Bd/+e9RrVaQZRn2Dw4xPjaG"
    "er2GVquNJBlgkCQYq9VRrpTIL8nRMQZJYiIGR2qrcRzHxsdLkiTY3NxGmmWoVsoYDBJln9OjyMiVMjyPQMTpaVMFtszQbLXJoDVJ"
    "USxEmJycwMTEOAaDBIdHRyrMxpiJllyr1dDpdHF6egqAnDuSnxtf9T8SMoNBgjAM0W538NJLZKeQZfQcsgspGLVpvVZDsVQkNVUU"
    "IQgC1GpV4/AtTVMIFeKgUIiQJlBm5CsAACAASURBVKl6LxTHqlAooNslHy5hGKBUKiIIQuPlNwwDFAoFtNsd1Os1jI+NYW9/H51O"
    "F/U6AbSTkxM0my1MTEygXquiXC6j1Wpjd29POcFsIBkkSNIUB/sHAIDTZhPjY2OYmp5C4PuGqSxVykgHCe2IKk6BQFAAxPtAoYbj"
    "7XsolUoojL0MoAW7OA9wsnsPoQr/0Ol0yC7mpQuAVwap3gD0D3Drk1vY3tnFyupt3Lu/gT/787/E1PQExsfqECr8h1BA8Ld+89cx"
    "25i2442PafbHWVBp+cBAjOnbho3V45eP63y++n6wa4Q9kbuIg6FMSgVktrC8soZ/r4CMDj7JwYvdlEDHevv14uI85i+9jLfe/Bns"
    "7x+i2Wqjpli1vf1DfPDRLVNwPmaJqOO7lrrK8LpLPpGceth2GpUUINrqxfHv7DT3fxf0IgO4YCa/snqWAOas4+cNZp7kWv6ZPwbw"
    "ObB5WDpXQKPTr/7SN7756itXvrVoGBtKD2MwDGNjgM04CoWCoq8HCtiovACHUcgDFX1N3IuNjU3AnI1xkMV7TRiGmG1MY2H+MgUX"
    "1D48pDSThGCrRvNsNrHycjg9UoMFaUGNs/OATUScFXGYqFwbmn/cY7EGLJzNUfflwZf2Umo8lTKwZWdyF2zpPPf2j9Bsd3F/Y4s8"
    "3w4GavVHapdSqYh2p4tatYI0y9Bpd40qQevuq9UKSiUCO4PBwOjuj46OUa1WUamUkSQJdnb2MDk5jqmpSWRZhmazpeIIZXjppTkA"
    "oJ0zyp5mMBigp+wCYgWcqtUyKuUyxUIqlRD4vvJkm6LXi40jxsEgQavdNuqwVMUoGx8fByBxdHxCQj+TFMBR3Rcp25Rer4ckIdcE"
    "9XrVMEe1agXdXg+lIoEy7SSv3ekgSQao1+podzqAlLhwYQ7j42PY2dlFmqao1qrodXuGrfKDAFOTE2i1aCt7rVaDEDAADwAmJydQ"
    "KpUMmNBhD+JejP5ggLaKsF0uUxvX63Xlfwcol0qQII/Bh4eHqFYrGBuro1Kp4OjomAKL+j7arTYuvHQBSZKg1WyZMA29Xg+Hh0dW"
    "5Sc8lMoljI+NISqXgKAIyASne3tYWV3Dyckpbt+5h82tHfzrf/sdzDZmjApML2R8z8M/+6e/ifHxugXyjqduwQCHXly4zCOdsf3Z"
    "3Wo9KonhWZKNYz3czFMFbHBLNbZOT1tGtWQZmb7DLueBGAcyFy7M4tXrV/DK9SXzblutNgDg5vI6Nrd23RI7QMaqlkYCmVH1G5Es"
    "kOn9zk7z4H+HBTEayOSjbT8KoHjY+c8qsHlW9476zB8D+BzYnJWeCaDR6Vd/6We/+apibErFogNgtP0Jf1f6PFdFzTUamJwcR1HF"
    "x+n3Cdg4TIK0mhQ9eZk81XEvJlXU7dv34AcqMm4OdHC2JAh8NBpkYzMzMwXP9zEYJJCZpIi+bEXjGOQCRi1jwZbbzHynEMBob0aB"
    "62fo3Uw6kKUGGAb0qAk9b7zH62aYIFbGIU5YszTqGdSMmW1TDK1BIaXE3Y1ddLpd3L+/iW63i24vRqxCAMRxDD8IFNMWo1qpmPg8"
    "zVYLlUoZL12YQxAEtAsHZOjY7fZQKESolCs4OT1Fs9XCWL2u1FdkW9PpdpUwLqmdW5kCUrYtKpWycvdPIKFWq9LWZUlxigYDWrHW"
    "63XlsTZBq9UG2YcQm3J8fIJSmcBPvV5DmhL4iaIIvV4PhUIBcb8PT5CBcLFYwPbOLmQm0VVeVY+OjjE1NUGxmTwfE5PjJmQB9WUg"
    "SRPTJycnxtEfDMwW+DAM0O12Ua1WaXt0v49ioQAKCJsau6NUeROemppEEATwBNmpRAXaPt3r9VCvUR0Oj44gJdDpdFCtVFCv15SK"
    "sIggILDW6XaQJikmJsZRKpUAAK1WyzAZOrp3FEXodDr0LAXqPO3nB1DBOscQBAF83zOgsVatoj8YYG9vH/v7B1hbv4PllXX8+IOP"
    "0GhMo1arMpAvMDU5jt/6x7+OUrFgVUJsIcFVtJzZdBdOlrng7IqzOBmR9Ln8WLRzmA2cSrY+BLo3NrfJRub7P7RARt1imZhhG5lG"
    "YwZXFhfwxo3X0Wp18Or1JZANYhvNVhuf3FrDyxdmUa2W8fKFWWxu7eL7P/iJqatjI6OMfbudLgbJwNTpUcBMlmaI+/G2YmS+DRfI"
    "8C3a+Skl/3mex+d9z9MAkse59knqgRHHAD4HNaPSMwU0Ov3qL/3sN1+9fuVb84qx4Tpoq5qhPw7o8TzUqhVcmJvF3BwZDxeLBbUC"
    "ZDY25lW7aphRAKcXx1hdvY3123fh+R5jIsD0zXalFwQB5mZJbz0zM6XsJRLjfE4DFwDGM2zeuHboAby0WgBzMCMYE+S5u62M6ggj"
    "VE3mOlsuzlbl1VdumfIrRWknb66KktLcIjOJf/udvwIg0ItjHB0d66cQ8ExT1Gs1FUPJg5QkyPr9Psbqdbz00hxarTY83yNmQIEo"
    "ITy0Wm0T4bpcLkFHzm53KNCklBKTk5OoVStodzo4PDwiny1SolatYnp6CpMTExACOD45MaBy/c5ddDpdctBWKSMIAnS7PdNOgyQh"
    "I18pDfgBCDBrfy2R2tmjo2YHAX2vVsj+p93p4vj4RMVXSg3YabZayLIMly9dRBD4xtCWwAGpsGjXkDA7vdrtNnnYlhKBH2BychxR"
    "FGF3dw8Hh0cIFGAUADnx8wT29g5Qq1Vx6eLLZsdKrxcb1WCxWESz2YKUtPspUFGpq9UqCoUI3U4PQeij3e5gemoKY2N1SCmVbVJs"
    "AiAmaUJlT1MUigWMjdXRVbGber2YAkCq91coFBAEPnq9GBBAtVJRRtR97O7uY3dvH//fX/4NdnZJfdaYncZYvW7AvYDAL/38V/HO"
    "WzcsG8rtWdSqxgnuqsc9pyz0dwkX2Ag7zuwwGJIhjGHNnLhveixnUqLVamFzcwfLqwRkVtfunM3IqGMHyCwt4GtfeQtffvMGdvYO"
    "UKtW8P2/+wkggHqtipcvzOKlC7P6btMC9za28e0/+BPEsWVktC8ZHVePkUlDiyCeFCOz3evHv7tzuv9tDKuW8oyM00ywk8yndfy8"
    "zz0rcMM/88cAPgc2PH0qgEan/+QXCdgsLBBjw/2j5D9JAGtjQA+1WlWpomYwPl5HGEbGwM1G92aUM7MT4XSzPu71elhZVdG9PS8H"
    "OSzNrVeIYRhgtjGNxcV5NGamycZGCW3JhL2e2Myn/g05pka4wMldcSrDYy/PugB50AZ9r7nGtQ3iQIaDL45rNKDijaC3ZnNgxMEN"
    "QJP3jz/4GH/+F3+Deq2Go+MTHB0eo6pUK81mE/sHRybIZKDUQYViAeNjpN4IwgAX5hqKASCBFISBCZcwMT4OCYlKuYyDwyMM+hQH"
    "KQwCVKtVhGGAVquNarWKNE0MM1CtVlAsFk08nDRNcXh4hF4c4+TkFIEysk0GCXpxjHKphCRJlAPADLVqVflMKRgV0ubWNgSA6ekp"
    "8rnS7QGCXPZXVABMHYZAShXLKu6jVquiXq8ZWyFaOZPPnP5ggLF6ndiNMMT+waExMt5RnmHrY3WkaYpKpYxyqYxms4kkIRVSllHf"
    "n5gYR5Zl2NreBRQD1VVhChLF3JSKRdqp5XmIChEmJyZQVcak7XYH+wcHFIxSkDO8iy+/BD/wkQwSdLsEVI6PT6B3K1YrFfR6MQqF"
    "CONjY0hSikheiCK02m1lq6XiZXlCGfpnqKpFSpIk2Nndx+npKT7+ZAW3llfNLqbr15cgPM8AlMmJcfzT/+o3UChEZm7gwF53XK6u"
    "BTunmU49XvRYt/MC7Fjk42jU/JFjhyVo+/PpaQubm9tYXl3H+//hRwrIWEbkYYzM1aVFvPeVN/GucoK4ubULCIqXd/GlOdSqVTRb"
    "LXx8cxUbmzsm39NmE2FAkcW/9/0fOrGWbIBgC+B4u5jvqgmMaomAzO+BjH01mBnlZ4a3oP58mHB+HODwKMfPAvQ8TzDzoPbLHwP4"
    "HNTo9KkCGp1+5Re+Lq9dWcAr15ZQKhVdAcwmCz5Z6UmqVq2SH5vGNMbHxtQqmbbUZqm73ZuzERYs6ecAUmbo9mKK7n37ropLA/M8"
    "Ew+GlcMwNotkYyOEMNGf9USlgUCWSRs3iTI1+naTJwc2DMxYlsaCPj652jK5BtbDDAzs/eY8m1wNMwTkpvjcO5FGtZO3zfkX/8f/"
    "hT/9zl+h0+mg2WxjfLyOOI4xVq/jVDEBpGryjN+ZZrMFCIHF+UvKOR6pbY5PyFeM7/u4dPECLl96Gb1ejHq9hsOjY8zNNnB4dIxC"
    "FBomQNtYlUolzM3OIAxDw0r0ejFK5SL6ffIonKm+UqtVcWFulpzMeR7ifh9HxycYq9dQKBQwVq+hXC6j3aGt4WEYkiFtkqBYKhrg"
    "NDlh1aFCWE+4UlIYkCAIcO3qIqJCAZAUC6kf95FJiYPDQxQiy1wcH5+gUCigWq2g1W4jTRIUGfAnT73E+KQq2ngUhWq3VYhmq412"
    "q6289FL5emobuY48nakYTmSMTe+j1+thZ3efbHUUczI2puxUPA/FYhEnJ6cIw4B8RUGqtu2hWCwqBo3UdJVKGe12RzFUCXyfjJ0B"
    "GHZrZmYa5XIZg34fh0fHWF5Zwwcf3iTP4RKIChGuXV0yxvdCCHzhtev4R//pL+d69TCAcaS2Gmk8Hz4e8sd5dobPFWbOMKCEhkuW"
    "ZjhtNpWxLzEya+t3TZ2Hx5IdfxrIzF++hPfefRNf+8pbCMLAskxqjG9s7eDjT1bx8a1VpXIVhoBK0xQX5qYRx3189PEyOu22ssmy"
    "QEaPbGc9xUAdIJAqx3oAcHvv/nUARQAFuGBGsH+mauzzWR0/C8DypOee53f+mT8G8DmweS6A5hvvvfs3nu99JfA9vHptCdevLZmV"
    "FzgToAtoBL0qtFqBzzZmMDs7Y4SK3mlCE6OretHJHHHWISNgQ7uiKFaUYUhygEY/PwgCNBrTWJi/pICNZ1QM9EheD10Xo9Myx9Ze"
    "xmMAh9RNmqGRgMOMGNDCmBmAgR7kV66s7tKCOZ2Pe52l76Gu00DGqNkY66TfF6TEIEmxv3+I01bL1FYIgd29AxwcHhthoD+PT07x"
    "wx99iCRNkSQJTk5OAAjFPGRGiHLPsp1OB1mmfOAo0KgBna+idGv7Jtq9xWsvUCqRKgegXU31WpWYlMEAiwuX0ZiZNuogANjbJ4NY"
    "SKkCUkpMTIxjfKxuPBl3uz1MTU+iEBVQKZdwfHKKO3fvwfM8XL2yiNnGjGFjZCZRKpNX3uPjE7RabfSVYKfnAJ4nEIahAgARymVi"
    "j+5vbGGsXkOn20WotqQLIZCkKba2dlAsFghwzzUwMzWFVrsN3/fRbrcN80K7BlOzy0lAMSjCw/h43do3lcvKmDlQwRAloihErVaF"
    "lMD+/oExLE3TDBfmGpiYnECr2UIvjsmPkCRP4WEQIElTFQ7DskmtVhtb2zvY2NzG3Xub6PV6kJnExMQY5hcuG8EuhMD85Zfxm7/x"
    "DxRQc9VEzjjgbKXqhVptO1o9y/7p8cE/3cFj+lOakWffjY1tR7UUayCTu1kPWVqoEZBZWLiM9959E++8/QaKxYJZRAkh0Gy2AQF8"
    "9/0f4bTZwsbWDprNtpkDs5Sixl9+eQ43l9dw994GqZYGCRubdji75LCdZ1IdXwtAEPhIkuRHt/fu/zYIzOS3YvOmzX++qMDmswZm"
    "HrV8GHEM4O83qHkugOZLr79ysVgsfiuKwm+GUYTQ93H92iKuXV0g4aV9nSgBalgNJvABC2wuzDWMgz7tNp0MJhOHlbBMBv3Rgp3b"
    "vsS9GKvrd3Dn7j2z3dvq5GFUUQAAtfKdmZlSwIZctffjAdIspecqxTVnXjig0fWgVaR1vsUNfi0QOZuB0UnPXSNXrayeeSNj3R4c"
    "22ggJTNJnpTV+zATtL6Og8+cKiAvRPT1fFWcZhk+ubVmDJOTNMXK6h0SkuN149tDCHKPrwXj3v4h9g4ODcjSzvG63S4++mQFkKBy"
    "KwBk2wPqnMTh4ZECbbTtu1apoFQu4vDwGHHchxAwRuiahRgfG0Pc72Nx4RIGgwSFQoRioWACMG6rHVkvXZhDozGNcqlkduklSWKY"
    "ku2dPcNQArSzaJAMaNu52mElhECakPCsVMqQIE/E2iZjbq4BAaBaraLZbJogl/VajeJHCaF2tdBOLB3p/PjkBN1OD57voVIu4cKF"
    "OVI9dTpIElJRBTo4pBAY9AekjlNMVK8XGx8/2gYny4hVPTk9Rao8B8dxHxJk1xSGIXo9MnRuNltI0xQnp6cIgxA/+slHODw8Rn/Q"
    "x6WLL6PRmIbdTSjQmJnCb/3mP6LApgzQmI6qeiTvb/mxICWc+cOqipmX8Fz/ttfSr5pdvHd/E8srXLXUd+eW3KA0jMyMAjJKtVQs"
    "FJxyO4CLPV8IgT/9f/8af/vdH2Aw6OPiS3PI0hQ//vBjHB4eYzAYPHRusEkZdA9Ifev7AZJkgF4//r3TbutfdvrdY5ztV0Y/5FHA"
    "Bf/t0wI2zwrofBbAzKi2xYjjv7eg5rkAGp0ssIm+WSgQBX796gKuXlkgr6+Qjh8YGvCux00AZjvq3GwDjcY0JifGjR+bXq+PVBkv"
    "GmMS2AnKrM60vYhKcdzH2vpt3LlzX61uTSlsViojCXLx3piZwvzlS5ianDA2NlJqz6Zs0uIqHiNjrZpJ1xUQTl0d3T1yL8+hkNnE"
    "zsDT0IqUAwt1ns+ipl0cpml4yTdUHlYWFxC6ky1nsZyttbnrOEuWn/B5HRyJpSb3tdv3TKRsZ8irdpGg3Vj37m8pcBLi2pUF7O0f"
    "4N79bWzt7OH0tAUIGMB7ctpEt9MBBGjbd0qASIdr0GEaSqUipqcmcXLaxEsXZjExTkDo3v1N7O8fQghgbKyOmekplMslHBweYXxs"
    "DJcvv4xkQPYlcRwbFmlrewdJmqKoomFPT0+i2+0pnz4DdLpdzM3OoFYj8FAulVCplMnZn0chJaSU2NreQbvdMd6cx5T/mn5/YAyd"
    "dZgE7Y+mWqmobfUpMpkhUiESSO1Fu5yIHSUD8EIUGmaVmCMKcVAulzFWryGO+9jZ3TPOC//6b99XW9ATvPrKVVQqFUdVdOniBfzj"
    "//w/M7vDOGix755erFl05AAM73f5e90ul+soINWOVi2trN52jH3t4y0TY3Mi9quhfFx99Z038eU3v0RhHYw/K8bW5gqrbX96vRi/"
    "+/t/jK2tXVxZvIS19Tu4ubxGLJl0R+aDQE2aaiAjlEH5AHE//vZJt/UHDMhoMJMPMpn//LRAypPc89MIZs6qA0YcA/j7B2yeK6DR"
    "6Uuvv3KxVCp9K4qib0ZRCN/3cO3KAq4uzSMqRNDUQX7Vb8QqE6C1apU8D8/OYHyMIvMmiTIe1uAoB2YcetnMSDQTxnFMIRXu3rMr"
    "Vn0pu0kL18D3MT1NjM3M9JSaNEgIWKqXM012GoKqi/6dT3BUTG2km2vAEXnmbXAcW5wHgBqHcpfKbgbWB08eOOUBiCNoFMDg5TBl"
    "4GXhATMZHrF1sQBPg1KnPWDrz7EWB1j5fmLfnK0z36FGYFqaz0wyB4sgddbyym0AwMlpSwVZHKDd7kBKiXv3t3D58ku4fPEChBDo"
    "dLr44KOb+ODDW0jSFGFI7B9tFe8o43JSkWVZhjAM0e1S6AbNClC8KArjkGUZKuUSWq2OYRh8j4K0zsxMY3ysjkqljKPjE0ACjcY0"
    "ut0eDo+OsTB/EWEYYm/vAMfHJwiCAPV6DZ7nYbYxjaPjE1yYm1U+dgiUawA0N9uA5/toNVvEyqgyjY2N4eT0FC3l3DAKST1VKEQA"
    "hPIPJDA2Vje2Zccnpzg4PMLa+h188MEnGCQDlEslfPFnXmfqJmJpvvG1L+Nnv/a27ftC70qit5gbtrb3jGAcTbdwu8sIUCOQyQyn"
    "J01iZJixb8xtZKR9Plf3CE9gtjGD+fnL+PpX38Y7b90gj9FwGdi8naAuS5al6HR72Nzcxp/9xd+gH8fIshQffnQLxyenuU7Mv7rw"
    "BoCxHRMCZmdc3O//3km3+QedfvcQ1vg3hGv86zTfp3D8LMDMg859Fr4/7TX8M3/89wrUfCYAjU43vvDqxWKp+K0oJGDjeQJXl+Zx"
    "ZWkeJaVj5sAGuU/9Fj2lipqdncFsY8Zs9yafClYVpW1CTBohCPVkRQ76yHjY83wrWPW1WsAqIRv4tCtqaWkBs40ZeL5HsaKUzcdI"
    "4cpnZXuJnaxhGRp7X44xUm0hOBDItZnja4YKnhMMOTubPGDSwsQW2pTFqvV420hWDxcw5QXBcKvkmRmXxTF1zrUFL89wHjZpIeeA"
    "KtU2Ws3mAh3LPOl2McDTMHBu/qPqv729h6PjE9YG0pRTt2+/P8Dq+l2WFxVAx7aiPi+RDBL85MOb5BxQ+bOBsAarg8EArXYbvV4M"
    "T2jbowzVatX4nOnFMZLBwPTtWqWCTreLqckJo8ZqNGYwNWnZoJOTJmYb0/B9H/sHh9jZoa3kUkr8zBdfAxnxV1CplDE5OQFarPgo"
    "RAXs7R+g3W7j5q1V3Ll7H3FMvn1u3PiiYaA0mImiEP/kv/yHePnCrPvu7MDI9UX1bhgjqt+p7j/cJo+DIz0ektTayNxaWWN+ZAZw"
    "k8uaQmog08CVpQW88/Yb+PJbN2xcL2H7j/2nWWcqU5ZlBnzeubuBP/+Lv0bge1hZu4MTDmRGJel+TZWHYA5kev34n58SI3MEC2Ly"
    "QCbfjR8VaJzX8ZNe9zTXfhrfn9U1YJ/5YwB/P4DNZwrQ6HTjC686NjaeAK4uzePa1QVQEEwmQHIMgGRqB09R5XNzM5ibbWBiYlw5"
    "VEtM0D9Kdk1jhR4jcJnQ6cUxllfWcfuO2hWl2CMwAai7khC03XturoGlxXnMTJPB6SBJTABLLVCHup9dfpp0JkvD6BJXsLKJnQpk"
    "hSsXBiYv+93sZhpRLpcNYuVzMzPvKW+34xgtjki8fo7aTL0Sc57/rpvBAYo5digP7DhDN4qpklZY6WOh24CrDln7Dv3G2t0wUyze"
    "jwGU+sH8fbEXy8vE6zK63en88fEJtnb2AAnc29hCsViA73nY2NwxQTb5uzs+PsHtu/eRKhuartrJVIhC7O4doNlsKjAl4Pvk6oB2"
    "FpJayfNIPUK+hgYq3AMZahcLBczNNeD7HtrtDvb2DlAqFXF8cooszVCplPGln/kCgRljTyYw25jCr/zi17Fw+WXWH2zrSOn2F90o"
    "3KDYeaesn9i+YPtzmqY4PjnFvXubuLWyhve//0OsrN0xIQpkvtOy5+tdS1euLOC9d9/Cu2/fIG/QpgC2jHxM6t2UWZah1+3h6PgU"
    "e/v7+OTmKn78k4+xu7ePk9MmbOEfkNQ12hM3AARBqG1k/vlpt/kvOv3eEc5mZEYOazweyDjr+LzveZxzT3vv0+b/aV3DP/PHP/Wg"
    "5jMJaHQiYFP4VsgYG62KKpVKRliNWnnzJIQwfmz0du9CgYyHe7EGNmxGdNlaR3hrgdTrxVheXcedO/fg+8TM5gW2CaznCURhiLlZ"
    "cpo1MzNtYhFpg9NciQHIHOhgK0zpnrMF5qwB7GSZX2xZGmVojnRVUVbgwjyBryxNAzOhnK+LbbN8+3AuQwuFvMCwK2y41zplAQMT"
    "jph3gQVccOOyRNLEtOIgxqmEerYGUXmhyZ9nmBZh62nqLzNmlJ2v1XCfHmZ86EdHZZpru7yKkNfVYS1YphKUJxf4qVKtzTamMTZW"
    "x81bq0jTlCKdJwmOT5pm11iz1cbG1o7Ju9Vqo9Vuw/M8dLtdqx5Tz4uiCKVSCdVqBRPj44bRmb/8MmamJ3H50kuYv/QyPN+GN7Bt"
    "Y0GIGQsM6AzPC6NBuM5TSonTU1It3by1amItOQ7xTPPadtZjwgKZN/HOW2/AZ2FWnEFmhqmwZZbkF+vo+AS7ewfY2trB3/3oA9y5"
    "u4GTk1PWDzUIGlEJlTSQERDkQ4gYmd8/7Tb/JQMy3OCXO8nLV/BJAMjjHn8a557m2icFHU9yz9P8Nqp+GHH8Uw1qPtOARqcbX3j1"
    "YqFQ+FYURd8MoxCeELh+dYEYm1LJRr7WN1hZ5ggAXxkPzzasH5soCim6t2Js8jYZLm2tBB0TSrHyPHz7zj0ItULVK3nhCRXHxgq+"
    "MAyJsVm4jOlp8jxM9j1WjTQMXCy5oo1z+TF0ifPALs8kOMhMOhOllgycTeFCnMpA28uNMWOOJdAG3JLlb49h2CUSmsLJG9I9tsUS"
    "Q4Ka18sAC2aPoJ/plMVpFl1+di4PaDQTlruPjxgODOw7cIUpN4jO2y1x+yTnOQwsalnI66X7tGWOpPNd32T7rtOkMIAZuSTdX00d"
    "6Iu6xgIf/ly37K7qLUlSYnTUO7m1epuiO0sY0FcqFrEwf9G990zmy4KTvOqZFcQ5jzOuJWPfFu7f38QtFf16efU24ji2c4ceb7n+"
    "KTwCMpcvXcR7776JL791A+QwlM07qgF5u+tvxIL1cHxyiv39A2xtUdTxDz9eVkCGZ0L3C3voJMvICGYj0/u9k27zDzv93gncbdjc"
    "4JeveB4k+J/F8Xlc97jfn+beZ3nPef6WP0buGMBPJ7B5IQCNTl96/ZWLlWrljzzP+0qk3KrTdu9FpYoaemcWCahjAhrkpr7RmEZj"
    "Ztp4ak2SlPx0pCljOoRhWSwWkCaoo14h9+I+llfWSBWl7BA84cHzXUDjqcB1FN17GkuL85ienjK7orIsM+V0JjQjFOk3B3RwiQU1"
    "8Uoo4eqZuFDmkhzQsPe7tiNGMIKX3+r8rXG2mvCNbU4OzLBncXURwJ7L2lZyQc8YDn3bkN8e4cbWAms77p7eCJacwM2zUUO7YNQX"
    "XibTvfjREIDMAREORnJg1BV6TsbO13xeDkOjQVi+T7A2NMdiRJ1YfxD51UD+PikN2zLKOFu/E64i4i9HDuWdr61kKxJYMOMAJle9"
    "l1dH6bz4u9Cf5NmXGJlbyyz6db9v2iUPHk17CbKRmZ+/hK995S2889YNFFQQ3mFQn+vGeAAAIABJREFUzRYTqpVkRg4WDw+Psbu3"
    "j63tXaysruOjj5eNamkE3HR6gq5fmilGRhCQoe356Q8Omkf/bbvfbQEoAyiBwMxZjIx+GfnPpz0+j+se59zTXPso38/rnvO872G/"
    "8c/88U8dqHmhAA0A/MI33vujNEl/Y5AQrap3RV2/uojrVxdRHAFs9KRkJxZKQlAAw8bMNBqNGYyP1RFFEZKEbAAymVlBzidmNYlr"
    "Hyd6Qs8yiV6vh9W127hz9z6CgFz9+571p6Hj0ujkBz7mGjNYXJjH9PSkUUVlGe+Xth4a6DirfSNM8MBVLWEiupbyyHKCPCecRqyG"
    "BWdodLlYWex328Z2cndTXsBbICFt1TnDIOkleqodPSupHBDB20ty53oMNGhApsth2yRXDl0+XSYGBGCytRLZgj/2LvLtZItjyuJI"
    "da0ayp/jbJIBMtItNwMyTrszQOKq8XSl3Dq6AMhepYX1sLG0Zd4clWQebHAgNiLpNiGgBbethtgblxEbZmDcPiGEcPzI3FxexXe/"
    "pxkZvWspB/Zhwa62kZm/fAlfffdNvPvWDZTKJQe48b4qc22ZZim63R6Ojk6wu7ePzS0KXKkZmcdJmXKIJzzLyEhJzvEk5L9Z3brz"
    "3wOoAaiAvP4+yKeM/nxWx+dx3Xle+yTfn+U1T3Pf49QFI45/qkDNCwlopJS/AQnj8VTvhNDA5tpV8mPDhakrICiZiQoC1WoZs40Z"
    "zMyQrUCxUEAmMyTKIRlyAkBCOg7nNLOgBU3c72N9/Q7u3tuAVpONAjR6Yg+CALOzM1hauIyZmWmlihoYj7Vc+JtJlq3yJdjEzoXq"
    "iBWw9o6sPelyRseIFAEM+fzJCWhzYW7yz42XkWXQdbJ2JUzFY+WqC0IFe4cMbJkrTPnc5+l3wsvvCCAODkexVqZMVDBdVqc1GAuQ"
    "Zw5MfdWzTPNwkMGuy1Sf4AKbt5l+Z26/y4bz5WVjfX20zZnt1/l6aBBjgAlvM1MnDtSoQsYex9SR3ctfMqsrbwz9CjjD5gmPAWwb"
    "vJUDpyE1k6AAmka1tLKG777/QyyvrI8MGsnZGBoXAjONaVxZImPfd966YXxTcQZ0GMBShplmZI6Osbu7j60tClw5tP36rMTaSfuR"
    "4UAGkhZGmv1Ns/RPV7fu/A8A6iBAU8AwmHkYKHgWx+d17mmufZLvz/KaT+O3fFshdwzgpwPYvLiABoCegbQHVgI2EXxPGGBTKhaN"
    "8M+vdmE/ANDEpYFNPqSCCUQJNtFmOiyAVgFlBqDolWTcH2B9/Q4xNrk4LfR8t19pYHNlcYGie3u+2mqeMkHABK8qkVUH2VVqXnBJ"
    "VWFTdgYmeBt4nueo2Nz76Q+bY/WNukLOsxxwwVewuiyOKoaDNpstq6YRinnmyaEmFMgy1D8rl7ogV2TpCrWhsvA6wRHIHNg4LNxQ"
    "XVX+vAPZojjMhOlDqpB5YSlVmXn7cYPrIbspsDJDt+HZSg19jQbFQ2ojVhfO7vELnPd4xizjgjkOetyycWCk66QXBm4Xd8cAhIBU"
    "IRbu3t/ErVurxkbGAhk475LXTTMyS0vzBGTevuF6D889P88UZVmGTrenVEt72Nzcwa2VNXz40a1HUC3pukPlRaolT3gIQtq1BOkC"
    "Gd0GaZb+2erW7f8RwBhI5VTAsE8Z/fm0x8/6uqe59jy+P8trnsVvj9p+/NOkFx3UvNiARiclJLJUAxuY4HvXry7g6tICCoXCaJYA"
    "DN+YlR8FwbxwwYZUKBYKSJThHWdNeMBGE+sIMjfZCvT7fayuk/FwGAS2IBIWUDChFYYqCObCPKZUEEyKLJ45E6+eVPOTaT65hr58"
    "ZW2/G0HIBLKbB5v0nbbMgworsc09yK3w9UnY+1yWBzYP9qIcVcgZqiabtR2v9nl5MGPLp3/gz0MuH/3tbKZlFKviPsMIcP0rK5eu"
    "vwYmBsxw9inXto5xri5vjsHSoIMbZg9PZ6xdhRhSpbjt+wj55cCabnerfhp9PW84y0TadrbqRrs4sa+C2j/LMpw2bfRrrVriIQry"
    "AEbXi4DMNBYX1a6lt28gUmEoHCCjgLMtv7JVk5JUS8cn2N3dx8Ym+bL54MOb7vZr02TDL2I0kFGMDKAcFXq5u6hcSZr++erW7f8J"
    "lqGJMNrj73ken8d1j3Pu0/j+pNec533P4n6wz/zxCw1qXjhA84sK0JwxF0OCJjPD2ISkirq6NI9rVxZQLBXpYjWp5IUEfaWJy/c8"
    "s917tjGNiYlxFKIC0oztiuIqAKY6GaVKACikAgXBvGu3djJZwJkMCIFwRBDMfr/P1GBUkbxNCeXLQQIDCkwIuOUbXpXnWgZuJrYN"
    "rYEwl6G5VbxzP3trLA/+GG54Ogo0OEI7D45y9Tf56t91u0sJt4YMaZp21H80GOMsCiuLLk+ueoYVY6oTMZQ3b17FsjCVCsO8Q/XU"
    "bM1wsm1r2yPnD0iarBxg7ICoM1QpXEWXVyHZErogTwMCvooYVSf9h79HrjJzVbf8fVJMrvv3t3BreRXfNSEKBqrMMJ9nMTKLi/PG"
    "2DdQiw/XGJnVUbOA6tm9Xoyj4xPs7R1gc2vHAJkzVUvSlN75LX0AkHFVwWxZoQ4VoPmfMczQnCXYzvP4Sa97mmvP4/t53fM8f3uS"
    "eoF9N+lFBTUvLKAB3DcwqiJZlpkAfVoVdW1pHleuLKBULMBO+DlmIbdCtbGilOfhiQnyY5Ok6MWxUUXlhbYp3wgGpteLsbK6jvXb"
    "d40fm/w1XMD7gY/G9DQWFigIpud5xo+NAQMiN8k7qinAFW5WQHDU4ggLDchyZeJ1NPfkGKJhu5Q8uMgDATcfYr+sfRJPXK2m35pt"
    "6pxwYL9xQWyNannGFuBqAczfoXPM2lTdMayi0Wov9tx8eYeSAyKY4Ge/68dKXTdpd3NZYMiAmQYKuhzmPnbeARy6sRjYyIMagO1q"
    "s/k6VQFrC3WTyD8nl4YAqGk79rth5mz5aNdSC/c3tsiz7/s/IId4/f4QwLb5qTEgKGgkARmKfh1F0dB74mCPdWPafq2Mfff297G1"
    "teuols4ygNZtwlvO+JERHkIHyATwvKHlx4jOJJCkyXcYoDkPhua873mcc5/G92d5zbP47TyvHfUJ4MUENS8goPnaH0mQUTAl/g5G"
    "VyfLUiRJCiFggsJdXZrHVQVsuM7dTOSeC2j0afI83MBsYwZjyo9NmmZKHZSaZ45iBvKly5iDvtu375D31jNWxZSnpCCYjWksLsxj"
    "empSAZsEUmbsHmaLIXOChk3EeWaFA69RRo55wMF/B6AmXO2LJ2fwK10bDi74NbOUzz+fDy+3YUs0w8Lq7szzTEAbY2jeLqw9RtUT"
    "uffotq0+Z4GxA2jy+etOIHPgJgcYOWBjTxjBlNh8dJ68nLoAI6poi6bAkj2fY0lYP9Ht6QIEDjaEU23+Dtzj0WpCnacdhzB1MnWE"
    "22+1aun+xpaxkdFAJt/xOSsjpTR+ZBYXFCPz9g1EYUTv0PPc9hoxLrMsQ6ejjH339omRWV7Hhx/feuRdS7rtLJAhX1XJIAEElPEx"
    "Y2FGghg3JWn6ndWt2/8LXEDjw7bIKEH3uMefxrlP4/uzvOZxfntW9z9KHhjxadKLBGxePEDzc19zbWhGzeEjkoBVRQG0K0oDm2tX"
    "FlBSqig1LTuRfq0tgZr/ARMramZmGhPjYygWiiZuSuJ4HlbFHLE65wK71+1RrKg7KgjmkBCAI7yCIEBjZhoLC5cxoxz06e3elkrX"
    "TeTaOLgMTF64DDMn9pQFfMTu8FOcnQG040E4Qg85ASmMSiV/P+BG4ubqGrdhzR+Wn66TWzfe3sgLSgnTbq5hr3BtilQbnMU68Tra"
    "5zqnhpIVWAwQ8d/VezIZSFuf/Cevj9MughUsxyQ6TZn/fQhYC0NQWINyya4VuXfs5uMI5xGoxqlLrl76u/apRLGWiJEx268dIMPf"
    "sR0HmpFZWLiMr33lLbz79huICpEFLLl3nS+/jrV0dHyCnd09bGxuY3l5HR8oIMMw4kNTmg7HWgLomBZSDGw+Yp4jAI3e5TRKeD3J"
    "8Xlc91n4/qTXPM/fzuv3s+qNEccvDKgJnncBniTx9YoUcsTvlGTuu+f7KPg+0owYFQC4ubyO5dU75Hn4ijYelk5uGorwNW+z1Uaz"
    "1cbW9q7ZFTUxPoZSqWgmKc7Y0I2S5cnFDVAsFfHF11/FlaVFrHJgAwHHV646GAwSbGxuY2d3D7ONGeOgL4woCGaaZqbkvIGUiDaC"
    "UfMm3ADVuWmUqkELcya4aRLX7UbqIutLR7C7hQEPAhIyswwNZxhcdodtLzdVGUYIQj2CqmAVifqP1K+AASyTpwCEVOwLNYwCM0o4"
    "I8dSOCySaVxwAWjZMWmAsFODEUAyD2aGhD57N47qzai31DPNw0ahK3uasB1nz2ybCdVfnPes24YBfNOPpfojhZXoI4AMeF7IA6Zc"
    "H8sxQJnMcNJsY3NzGyur6+6uJdM+LvvGyzw7O4OF+ct4T9nIRFHkvgd9v3p/5pSUSDOJbq+Ho6Nj10bmo1tOiILhGg0nJ9ZSGCBN"
    "EiRJYlRL9t0O36vzH1byjbjU/XfWNfIJjh923eOcex7fn/SaT+u3x01n5fGoedvJe8R9tenyCwFqXjhAQ63MhQFbRY281o5k/el7"
    "HvxCQQEbMhb85NYalldv49qVeVy9sohyqZjLwU6+epqTUqLZbKHZbGF7Z9exsSFgkyGOYyRp6jAklKT+35ZNCJQVsLm6tIiVVQVs"
    "Apex4TR8khCw2d3bx2xjRjE2kwiCAP3BgMIRSBcWSUgIyZgYwLEPsLLIFapaaFrUYIW3A/+YmkuzNbqSQt2q624Fq7T5aEZKAQQp"
    "3UCSGpjpPA0QG5qy7RMc9ZXzLlzwqgW1tc9gNeNLb0KBZleLHM6KgRpXBJljadkOob5r5uusVf4oYCAE4HmeBSc5BsZR2wwlBeGk"
    "2x/ZC1CHwvwMYW2L8m3EgRq9KgkM7cYxjzZtopP1keSq0NIsQ6vZwsbWNlZW1in69dodszBxACoHvwrINOZmsDB/Ce8pRqYQRawI"
    "0r4noT41Eylo92S32zVBI7e2dnBrhfmRMZjY9smzUpZm6A+ozJqRSZOEqZZsP86/6yF1k8ydy/9kP/NT4Kj0LIDNiwRmRqXnCVKe"
    "FqA8TXphQc0LB2gAOMOST7YmMY7fTL0jBIHvefCLBcWo9AEIfHJrHbdWiLG5fm2JVFFGkOu360ourcdvNlvY2t7FhblZzM3OYHx8"
    "HKVSkQLExTy6tymoEdimiEpIlkpFfPELr+LKFQI2dzSw4VVUK0kBiUGSYGNzCzu7e0oVRbuiwiBS7tCzkQ1J6jTPCqbcnHmWioAL"
    "NmeO5cI9X1vFBBiWSLWBGT0KJOSjN5m5UeedScXMCXhK6Ijc9GXKlGPFbFZy6FoHzECDDakfPYSZHM2M+jOkGVP10VcJfi8DlFS2"
    "TAljqpDQgvUBLEdeXaVblIgSwR6k0YoGeBpIIveuHMhFIFba8rj1YXUakuWsFXQdhLW9clVi9g7jH0lSRHLt2Xdjg7Zfv/8ffkRB"
    "IwcD1m6cwXTB5ezsDObnLxsbmWKhYCSt25s5M0fn0yw10a8pRMEOVlZvuw7x8gPgjORGvyYgkxggYwFf/hU7bM+Zz3mEAtiLHlbi"
    "xwU2j3PuUe896/uT5D8qPWuA86zuf9aJ940XEtS8gIAm3/8ZaNFn7LIXDxy76jry6eArGxgFbJQq6pWrC7h2bRFlFd2bL3g4SaEn"
    "0tNmC+12x6iCGjNTGB8fQ0kBJ4oVlXGJR9JYAxsjOWkqK5WK+OLrr+DK0oJRRfmex0CABjVU5SRJsLG1jW0FbHQQzDAkxibLMpiV"
    "Hlu35Y1988aZw21vQYFk30fvbNJ3C/AVtGaKtLCUgjFH0DOZRiCsqRTFYzEYZ+wkKBwW3eCYcegMGIrhtkSc6teC0oId20a87vkk"
    "HIBikaoDhGAFFwdeRmWh8Qd7t/lnaGAoFWOljaZH2gkx8MABgHlHjsG1BbWmikqNZN6FATaA8IRFikIDVbfeo3bAjWg46su2OXB6"
    "2sT9jS0srxIjY7df23a09mKSFUOgMUvRr7/81g28+/YbKBaLqk7MNsf0DxoMup3TLFNAhvzIbKpYSyNDFAwBEPqra/IgIDPsR4Y3"
    "R66DjBLzrNTuSHxgehCw+TTBzFng5ax7Hzf/p7nmrN8eNX3WgcvjJN1PXghQ80jQ/rOUfunnv/5HyDvWy6VRvYbmLTH8m76e6erT"
    "NHU8D3ueh1evL+KVa1eM8bC+M8ukYT8406In8GqlbIyHKbp3hDRNEMcD1109K9RQufT3LEO318PK6m3cvm392Fj/GPZOzZSEYYhZ"
    "x3jYw2CQGkGYN3wetXK2ZXHPuT5ImOGmzN+rBPXDupsuD2xoCa5CGbpbXe/Y/uSmDaM6YnoQU0fGxOTDPAypfHIsiQNYWHu47cXm"
    "agckuHO4VhXl513dj/LPzrNmxmiWBQc1W97zj3PawJY2/9o1W6XBZ97QmpfLSU6bukBGJw628u2XpilOTptn+pFxiqmBjBl3tGvp"
    "ytIC3lPbrwPfd54v2T0GDKmqZtpGRvmR2drewfLKbXz0sfLs+5DE55g0SdEf9CEg4AcBefYFd4iXU5u7TciO+ZhkbJhkTZAbcMoo"
    "+H8FMA7XKHhUkiOOR30+6Phh3x/n2lHfn9U9z+K3T/vaJ73nUfPCiE8An01D4ReOoXHl1WjQm18GOL8z9dHQ9erA831Eno8sSxHH"
    "MYQQ+PCTVdy8tY5XX1nCK0oVNXKRzrI2qihmPEzApo5yuWi2eyfKeNiu7gDI3KQLWnVHYYTXXrmGxYXLFATzzj0EYTD0bD0HDgYD"
    "o4qam21gaWkejZlpFgQz43IOerJnDcaYFnVC24YwNsDYYDDwYVQ4ZhXJjU8FOw91D4NyrG01KNFAh39CgxVp7zNFdVayZyRh89fP"
    "MuXPRVi3PkgknJc/SrCz3znzxUkv3qT8ULeNAQ76RlaW/HGemTG40rnWPshV6ulnudXi11E/FDAMl6QMzbhhD9F1pkCmI8bcCOCn"
    "x8q9+5tYXl5jxr45ICPtnfpeITxiZBYVkHnrDcfuzN1tBVsP1V/TNENPG/vuH6pYS7fx0SfLOH0EIMMzT9MUg/4AELSYGAwSJMkA"
    "vh+w/uSCw3xywLRTad0z2akR899jJv6kB604npaJeZRrR30/r3tGpUe973HYlWd17Xnn87D3nb8uN6N+NpmaR6nQZyr98s9/3W7b"
    "HpqBH5yEENjY2ESxWEStXkMUhu5qh4MIwLzCTDE2EAJRGCEIPLx6/QquX11EoRDRalhfj2HAZO01FGNjdkWNU3TvNEE/HiDLUrPC"
    "1QBG5ykBZ5usVPn2uj2srt/BXRUryoAH5mFX191TjNPcXIN2RU3x7d6ZoxJwfbVooakBCwcv7FgywGJW6md0MTahj3Kxb/EJl/h5"
    "ZgEW2GD4d/3+uE2MMzYFBw/DAGJIGI5IZ6meTDWZKo8DQ27kPJyHy3CMfGYOIFgwyo9z7eE2EAPLMG3hYkrp/JZvZ0N62SxYf8mx"
    "NCriPBfQUlIctuZpC/c3t7CsgkauONuvbd+zIMY+v9Fo4MrSAr721bcskFEnBfvks7fux0maoNPp4ujoGLt7ByZo5EefrDhA5mF9"
    "ACBj38GAgIyNfi1HOMQ7G8ykaaqC0vYRKaPl4SWcXhzA+Z2nx2Ro8kmOOB71KUd8f9C5J/l+Xvd8Wr+dx7Xn+ft5nsOITwCfLabm"
    "hWNoisUC+v2BiRTNQQ2ftIYTnfF8CvaYHp+gXqsSGxOG6hKaPISe51Vmnu8j8n1kaYq4H6M/EPjg42V8fHMVr1xbxNUr8ygWCs5z"
    "dHm4ykhIiVarbW1sZmfQmJnGxPg4yuUSGSczOxdPMyFQdTTOy4Vhm0rlEr7w+iu4emURa+t3cOfuPfi+r3qhBFigcCkEkiTB5uY2"
    "dnf3MTc7g6WlBTRmpiGEh7gfD4Vz0BJEquc5NjbqtDQRx20LUDHlsOpGl14C1jZD/25tRlzhmhPHHPVIIEPmnHQEqwTZ5lipbMCL"
    "Z4SDBEd/Q/53dH0fMfF+eJZfFc1kUDtxYG7rrZqea8v0r06ft8DTZqF3KOkfc1DE2CsZ1sxcn6sALIOj36x0LtNGwvalmLY3GQi1"
    "a8i2SZpmOG2Saml5dQ3fe9/uWuL11Ifc9soTnhM08t0vv2GCRprnAZZRA5znZzJDp9PB/uERdnb2sLW9i+WVNXz08TJTLY1mT/KJ"
    "O8TTIQoGg0SplvIZWKaRt2+appASKFdK8L087jir38nhr+KMc4+XHpWx0dfKEcfn8f1Rr3lQmZ7Vb4/z7J+WpPuDO9jx2WJqXjhA"
    "MzFeR68Xoxf3WbBG24+GWnvEd0jSZYdRhDRN0evF8DwPYRQOvTF2C/mx4aooCHz4yQo+ubVGu6KuLtpYUfmkhD/JLtru3Wq1sbND"
    "qqBGg4BNpVxClkkMBspBn7ACIq/eEQIGAPga2CwtYGWNbGw8z4MxvGV56NUp3+69tDiPyclJBIUAcdxHJlNHkLgNaCdlkp0etHHp"
    "qNmAH2lB467+dR35fMAFoLli9BQrGeBQKhEJC6byItcCJsWAOIBAGqzlkCC8MKZKFlhaIS6MBkwLWL7DzN5te5ppDaduWijD2FHo"
    "LcUOIwOTjc0yzzS6FUD+LTlgT7+ToYEgbNswVSHlKNxnSn6Pq7bLsgynpy3c29g0jMxqzrOvm4cqsVJbzTVmbfTrt24gDANeSANi"
    "NOvHWcc0TVX0awIyG1vbuLXMQxTYd36WJNfNordfCyEQBKECMoMHMDIsB/U9TVOkaQbPI+/Avu+7/Wvo2QyAs8QXEg8u/WOlhwGb"
    "zwKYeZJrHue3s9J5XPtZBz9nicGR7702XQbw/NmaFw7QTE1OoNvrodvtodPtIY77KlAkOZLjia9RhzcYA5DkcVcEtDuo1+vBEwJh"
    "FJ09sQgX2PTjPiCAj2+t4dbKbbxybZGATbGghL3avUGST02awthqNFtttNu3sbOzh9m5GczNNjA1OYFKpYwkSQ1rAm3bISWkMfgU"
    "Gg+YuhcKBbKxmb+ElTXL2PC2IEBEE22SpMZBn/Y8PDU5gVAEKggmazYBtSsJDtgRUA4OPdVs+bZjgtIaMKtXwN6Vnuydc0qQa7Az"
    "pBK0Nw9ND2Y1zIU/NGmVwcsEHH/HQkKyXVdCIQq311jBjkyyZ+f6nuA7xvRtDM4IwFgDqfMGlzjqt+E+a+6XAlDbmx2SiglRzgwx"
    "7su8Ow4sHRWh4IBOvxThbI+39YIBWEIXDtIAIwkS3ly1pBmZvGffUe+XHOI1DJD58ltfoqCRqn6mf2EYzGjPvp1OFwcHR9je2cXG"
    "lvXse3x88jhaa7J7U0AmDEO1a2kUkHHfg/lFWCBDYMhlZB4EZ1QLjT5zLhjmAQ8+G9iMuv55gJlnkZ4VyDnv9KB386TnHuWZQK7e"
    "z5uteeEAzfTUhAEzpW7XHPd68UjvvE5rMzUJ+G9CIAgCo/uOezGER/YyMHOzvUuqjAnYeDTJxTEgBD6+uYpby+t45doirilgo0EN"
    "hGCTpzB5SknAprXaxu7uPi7MzRrPw+VSCUmS2lhRQoDc10qzzdWsaKWd4IvFIr7w2nVcWZrH6tpt3L17n1azGggpkKXFpgY22zt7"
    "mJmZwiILqRD3B8jSVAEX3Waw34Gh7dZchWJsU0apcvJfOPghBIdMAxIG3DSIcoS1kWnC1OusKWbkotkpn3qewlL8d6qeZUcEzwgZ"
    "yGGevc4Itnz9uSqN0QMSpF10fR/B5GPb1wp+K9h1OSzYzE+1nO0S+j9jx2SexOopLZB1m8FtTIdhoxyylPzIuNuvbyPuD1wgw+rB"
    "7bBmGxbIvPP2DQRKnZpPUqM6aV0a6FhpR8cn2NnZw/2NLdxcXsOHH1H06wcBGWemlzb6NQcyoxkZmLLnfkGaJspWzSM2Rpf7ISLl"
    "LGaGXfBpJPfljhaGzxPMnPdvZ6VnDVyeJzDKp1HvmP82EtQ8z/TCAZrxsTpKxQJKpSLK3aIBNp1OD91uV6miKAq1Wc0+Rv5BENA2"
    "y8GAGBvfIwM9Nlk7b08I+L4H3yfPw7FibD66uYqbK+u4fnUR164uoFQsKtpc36gEmJVjAGBUUeR5uIHZxrRx0Kf92CQyVXY+uX4k"
    "QMaXSrhJKVEqFvGF10gVtXb7Lu7eu48wDEl+as+0bFWubWx2dtyQCn4UErBxDKAJ6GmAp9uDZLcwPzrGtnCvA+zqnr8oLVy16ZBD"
    "QOhVvBbYgI0lDPYsPfTO6ABSl80pT36ssufpX3NgjSEJcCYp/yxkrK0YvWF2hjGAk7lVcp+VtykyD1EqKWME5oI9yb+bmnJjaOFW"
    "RQNMaRsw/xqlBlO8sQUBmdPTJsU5Wl3H+9//EVbWbjt+ZDiQ0W2mVUtkI7OA9959E++8fQOhtnPD8Ot0AKUEUsn8yChj31sra/jg"
    "Qw1k8obTdo7O23ylaYZkMIBQaqHBQAMZH/mt/qNK5AIZAd8fMeXK3Oeo7KRz8LwSHxwPm1YfBZg87J5HveZFBC5npUdp2+f9vAeC"
    "mufJ0rxwgKZQiOAHPqIoQrFYQLlcRKdbQqfUQbtTRLfbRbcboxfHQ8CG0qg+PpyCIIDv+6SK6vbg+97Zqig1q/m+D9/zDLARQihV"
    "lAI2VxaIsdFPlcMCAoBjY8NDKowr42HteThLU2jxJJWKQ9uxOLt/hECpZI2H19fv4O69DYShXb07jrykDqmwpWxsprG4SNG9RaBU"
    "UVLpooSwoa/YxEzzL3P6r4UjhsGN5+WYK41HpAVbnq6jiQ/F2gtWRSR1i4hc23LWRl91xjA26hyTO1wQIfUzbSsLdvMQD8XtdMSI"
    "31ipAAVspETKQJ+2ozFlYaokCyp04ZghugI4Qgjw+NGc7bJHkkgOobNhQEUDG40A1XkThBQap1HfJRsZ8uyb9yOTL4NU9wmQQ7yl"
    "xXkev/l9AAAgAElEQVR89Z03yUZG27VlEnZ7vXDLpdpTZlKFKCAgs7m5jeUVin5tGZmHoQdKmWJkPEG2dZaRGQVk3Petz6VpaoCM"
    "p9S+jys/uH3TZ2MNDODxgI2+/mHg4kkByNO2zGerZZ9NehqQdNa9n0lQ88IBGiEEfM+DF4UIAh+FQoRisahYmx46nSI6ShXV7caI"
    "4z76g4HaSTCq3+qJ0UhR1sO1KgoG2Hi+hygcbTz8/7P3Zj9yHGme4M/cPa6kSCbJPKgSxTx4iqruLpRUpSpV777u22JfGig05mXR"
    "CywGGGC2BCz2tf+c2sbMPM/DYhcz3TPVdXR3dZV45kmKeVMimVdc7mb7YPaZfWZuHhF5UGJKZQQzItztdnP7fvadmmAJEyuqroGN"
    "EV89ImBzYxY3b84az6VEWN1W506rugcO2Ozg6tUpTE9O4MLFCxhrtSCl1FZRRaGJggkJII3VEecsUGfHTEiFW7duYHl5FavPvkAt"
    "y4JBuNTPKQjmC0xNTmBu9jquTFxGBud5GPBP8R5zQzlCVGWGDGCg11Q9R4aIJxpskKKokmXQRH2w4jACHYLq4s87MmjWnh/7STdQ"
    "4o+wLZGIq+/MzT3P+Nbp9Fq4Hx/bLmEI/p017Y2ZNeDpxlC/LILl7bKeGP0XC2pcxa4RD7IZ0ZIyVktrGxrI/O73WFp5qkVLvCj7"
    "QeAMJFqam8GnP/kIP/roz5ClmWa4SNMXAq38WZo1paRC+7CNl6+0+fX6hgEyRtk3nJf4M9AXpZTI+7nhyGgnmCRa4n6J2Ix5S0mA"
    "AxkmWoo1WWq9+maluOkE1Z5COiqw4eWOA2ZGBR9vijtz1OunnQbN85sALcPuv3Wg5swBGkqafZtqa6UsQ71WQ9OIolqHTRwettFu"
    "dtDudKxVVNeENfDmvuqYDj9rmmVIM6DIc7Q7HaRJilq95mW2OjGGVZAmKdKG5th0ul0kQuDhwgqeLK3i1o1Z3Lo5i7FWy46HdFNI"
    "cZiSlIxjs7GFKcOxuXxJW0UVRWEUowutv6EErCl1eHrUjaHVbODevTu4cWMWS0sa2GRZWn4tlYISwo8VNTWBuZnrmJi4jCStm+je"
    "nFtk5o1rjQIGZPhch9hzNV3UwMWI6XRV+ovmYBgdGqGcfx46rVui63MktMkvPSt4Yi2dx53ebbRvw/Hga4XAG+nF8L6HoM0P/xBR"
    "ErV/HFDTgBYAN4f3EIyDFIyRFNTLwAzjbAjBS/t5qXqrY5WKEsDm4xNCoJBG2XdtHU8WmY5Mt2+65VYgx0Qk6pyensL83KyNfp1l"
    "qVMMHkgi9Npo8xAF65s6aOTDJ+UQBSzFqi0KiTzvI0kS1Bt14xAvR5alkXXqJovfKXINZJIkMaIlFZZgPSgdhQb0961nIJQwdsW9"
    "UX6/iWtV6esCIm9DOi5oGXY/Bmps+rpBzZkFNJQI2JDFQL1WQ6NeR6vZwGFbW0Npq6gu2p0ONhIBWTjCBSKUqFrd/tXU6NgURnk4"
    "SYyODVEmZc7w9hETR0k74LMcm4UVLCyt4vbNOdy2saKIgItARGOqUgp7+wfYM+be716dwvT0FC6NX0Sr2TIhFYznYSVc+WA8VjSj"
    "FJqNBj5kwGbl6TOkxjV7bEPmfmympiYwPzuDKxOXUavVbHRvR6SdKrXHdQgIO3dsBxDBdG1zzhrdoSy+lQsDDxQfC4x8K0AKZUUG"
    "Qig75z7wgKecymeQE3/+GhsYYsy9/XJOTOKhBgB+0FOuJG77YetXdrxOpObGZQEAn1cCMwkp/oLV7/oY6jhpUCqsLlZsH9MO8TRH"
    "hkIULC6ten5kYkwpC2SmpoxnXx39ulbLHMcGfrMaGzsOjVQS7cMOXr167Tz7LmqrpUFAxk/6IUipHeIliUCj0UDe135kfCATBzB2"
    "Lpj5dca5nVE6fzT6eQbADCU+wCrCOAqAOClIOW67ZyWdhEvzJkENwLZndu1rBTVnHtA4kYYw4EL7c6jXMjQadbSaTXQ6HbRbHRy2"
    "G1ovpjCxl8CegOFEOHbA4JRlGbKaQN7P0em0tfO9OreKKh9D6PQni8ICG9KxuXNrHrdvzTkHfQzExDwP75kgmJtbO0zH5iJaLZ9j"
    "4wEDGPCAcv+ajSbu3buD+fkZLCzq6N6p4diQrgjf0Dmw4VZRiQE2spD2dE5/bftsbDxxnyFh0noi0uYj5U2RJNZ8WtlR6g9JIIAe"
    "CGCssaTfD9OABTUWSDpC5r3JNHlMPEQVabGRP1dUyFo+cWeHnjgLTk+GygDaJF5Z3onlLFVtPdwqxkH1EMjwuVVOGZY4aOHYzHxI"
    "qYxDvHU84Z59uz0QiOEm4bw5kZBoaRZ/aWIt1bLMIXY2vxq0MZGYgjW//urVK+ywoJEPHi646NelwZXnScC3WqrXa8hz/TuzDvo4"
    "GI0nH8hUOeINK4hVSCJBxB7PWUshijspwBmlndOo7+tOJwEmx633tO6jIo9HUlnerw3UnHlAA4QEUFsdCVG3HJtms45Wt4lWq2tk"
    "2s5klMCMBTLeqSzOr+Epq2XIshT9PEenbYBNrQ5Lxt0fW6OOFZV4OjZk7n371ixu35xHg/mxKfWBcRX29vaxt7evY0VNT2J6chKX"
    "Lo1jrNX0zL29k76uxAdKpnPNZhPfv3fXOeh7+swE+NPj4Na7ClrHZt3o2ExPaR2biStXkJFHZqmVZzUBTiAggYTUU/051lGyy8/V"
    "KaeWnzcpvZKYLrHKs46oKo1uvAdI3BQwEKUMMBJKePo3FuDQFUHlmG4MEV+mkOv7oSEOg7knaQbZeL1LZBHHIEniavBAA+tnyAhQ"
    "Sk+sYkCIz72bWw3EhPEoaEEeCMjoWEtraxtatGRjLfkcGW/eDToTibFamtOxln7y8Q+sQzxFwJCDGG9atPi0fdjBV69eYXv7hQtR"
    "YDz7Vnlxto+GXeOefWu1OvK8jzzPA/PrKjCjL0hZWN0xH8gI76NEGqpIrfcaBo2OTNpYo7REvrlUNQNhnlEAyUmBS1Xeo15/m9LX"
    "AVqGrbqqPN8oqDmDgMYnIuWTpDttJmmKukiQZZm2imo0kKYUPyBCTADmIp3thpGN0S8kUMsyKOPHxnJsanU48ZPuq33TSQcoSSEV"
    "07F5vIwnC6u4fXMWt27OBdG9XQr1NHZ3DbDZ2Ma7V53n4ZYHbCTcoVnPmhU3cGqaCDRb2o/N/Jz2Y/P02Rca2ED4IMvMf97vY21N"
    "m3uTjs2VictIk9QqDyuloAqlxVIisUqW+nk5Thur2hFgzr1hRJ8vBQIVhE31f6NPFJk3/kQFBAst4Z4vhQiwCqFWB6is4Owr/ipv"
    "nvlc8fYtaBEwZtukLKuvkc4PGzKrU4EjzADLWLGZ8xGkQZWkyQ3wrD8ODS60H5k94xBvBb/+7b9Y0RJVY8EMiekMoCGrpbm5GXz6"
    "kx/ik49/gHpNc2TomdvR2ICRDnRJKXHQ7uDly9fYeWHMrxeWcd+GKKimO4rPkwr9yBCQiXv2daDPe1IoGJARJSV2Uf7grwn9jpBm"
    "vq6U8PONjGf4wfntIcchsDkqwDlqW2/PyE+eRn/0b6Z+tqCOnOcbAzVnDtD4NMMdQ/WG4c8rbSpJkqCeJqhladmahvZQOk1X8JiH"
    "riyjc6A9D2fI80L7sTFiMNs/C46oPSAVCdJ6Q+vYdHsQQnsefry4YjwPz6PZbFQ2TUkqhb29Pezv72Njc8sLqeABGykZ0RVu7J4u"
    "ib7WbDSMg75ZB2yyzCeejNpqUdQWtne+tFZRkxNXkCSJMaM3+j2W8OlygnZ8YjRYeZBPXeymz3EN52KYb2QKrqCgJLNMCgCQ5XIQ"
    "h8BmsrAFIjFxteyjZpZSEbGZ5+eE981pN5cIWcgZdM0J8Ns+oHNZAmjmc0rsZJH3YmXzkcdq14auSUrjEC8IGtnr9UrgioMZEpFO"
    "T05hbu66b34tDIeJ5to8R/su0OilwqGJfu1ZLT1cwGtjfj1IFMTXr4wAGS1aCs2v/Xnmk1sUBaTSumEiSdx5KNKH0amqewbBdJbq"
    "O1qyFbxJYnjUNAzMDCs37NpZTScBLacFSIa1f9w83wioOXOAxkvhzhZwV/RfR/0SivhrUpIk2m+MEckIrw6Wono1wbHY/KDNOctS"
    "K4ryrKL4BkqbuemTdtBXR1Fojo2AwP2HS3j0ZBl3b89rjk3TcWysfo0w7Rq6JQ3HhvzYkChq/NJF7cemKNDranDhvA27mfPMjA2R"
    "azYb+PCDO7gxP4vllVU8ffrccLv83YVoYpHn2NjYxM6OVh4mUVRNaHNvK46wXApDhI1+iaP7Riclkiy4KT0n5S8FAetE0BZkJ2Ie"
    "zkEjq4R6Y4kv6VVYtRoGBHj7XOQUcnAsQTS/fJCi7BA8MicYzCLgyWskJ3oMDznwBHgP104GhQcoO4bzRUsRIMPqokMFARohDEdm"
    "dgaffvJD/Pjjv7AcmSRJkAQAgo9fQTvjOzR+ZHZ2XmDdiJYIyCAYajSZTpLVUujZ1yn7imhf2MQbh3h6XGnC1vqQ7T12+2hAZ0hl"
    "Q9IgsPcNJj4FowCcswRcBo3lTYOWkwKSUYHPcfJUgpo3lc4coHGu7uFMgAWPmxOw9UV8JhWALE3RajXR6/XRz0mR1aMN7LwTgprI"
    "OrEU1uWjkAqFiRWVJinqxtybRFH2DC8AKIUkTdBIjB+bngY2nz/UQTDv3Jq3saJovJa40k5mnM9pBc597O0fYHOTrKImdRDMcy1P"
    "FEWEVAkFBWmqCAio0NHO7929g/k5w7F5+oUFNmDKlFQgzwusb2xZq6i52eu4ckWLovr9vnHKFvPvoRu2oRYYa4XnFvwpKQY0GLeJ"
    "TK9LOhWWwDrwQkCTiBxxEnQvTV+FcPV4ojAOTCxKo445zg5DBnY183Xq6QjRmKlP+rmSgrTHJQGscjs9Cedzx58/4jpRP3XQyD18"
    "sbaBJwvL1aIl/mzMvEJoZd+5uRn87Ccf4ccf/TmyWmafj8eZCThdum2lgczLV9jafmE4Mqt48NAFjXSJhFl+orNNIQv0e86zr461"
    "lFuHeK5tN8M+ABCeQzzyI+MdjyzYDpKwszwCqAnaLYHVikTPOdL424ljvGSxOeJTdJJ6Y1N3FkDRSUHLaYCao+TBCP3hecLzrgLe"
    "HJfmzAEawM080R/7hnvyKJNoE40s61otw4Xz76DbdQ74+nkOWUhe3LXr1WOILNtdInjGlidz75xxbAjYeKdwI7pSgsy9GzoIZq+H"
    "HoD7Dxfx+Mky7tyew80bc2gxUVS4gojhoJTWgzg4OMDWtgY2U5PaKmpsbAxFkVuvylpRNkECZaxrlCNeLDUbddyjWFFLq1glqyjO"
    "YWCbflFoYLOz8yXzY2NEUcbcO5xxzrlRbN65+Ih0bzwCoRyB50/L9YegCZlAM1ACN1Zuos0gjKeE6rrFAQPdUNZkWt8SXv2eMitX"
    "RI6JTkFLXEAkQKISHaSUynKAJAlA8bqEu8/Ak5QS+3v7+OK5Mb/myr5sHFyMQ8O1HBkLZCj6NdsdGZDjojoBbfrdPmzjKw/IrLDo"
    "13yPjbzA7HX3REt1B2Sc1VKY6Jm4K2WHePxNYt9KYEaE2UJJ6chpFFjC+yz8BXpWEt8lj9LztxmgDAIEbxq0HAdoHDfPceviv98Y"
    "qDmTgIaLmjRXASwOjj7FhqfxCkyD8fHz6HTq2vlep6eBg3GqFYZNsICF12yPxm7VhTGWeLs8CGa700GapmjU614bBM5o80zSFI00"
    "NZ6Be+j1gfsPl/D4yQpu35rDnVvzaLaa4IP2AQCdLBX29g5wePhUx2qansL01CQuXryAsbEWikKi2+1qjk3iiLd1MGenX49ZwATB"
    "vHcH8/OzWFpaweqz56hl2qtq+BoKlP3YkCgqqdUYx8b026MKyjJqPMBhuRskmioTXwF4hBRmjolDIZUyXC26xeCLqUsa8OQBA1Vu"
    "i+p23TbuAKwYb8Ae4FCA1fGhvof+chQAKRIkkLD6Mt4WYvR3SutAt18YHZk1puzrA5kYN8bNz/T0JG7Mz+IvP/0Yn3z8A+MQj4nb"
    "TFtJInR8MXonhICSEgcBkHmy4BzieQq90bdWGRAX6sgQkCmQZbUgpIb3eLzkA5kqPzJ2KYwm0hnyqCvr8E5pZn+LnZDgA+4zmDih"
    "Exg6Y19bOgkwOW69p3H/tPPglPINPJWcNqg5m4DGJE547MwKh3eGQXkpJcYvXkC32dMO+BodC2q6Pa08mOc5ikLaTZY/OUUNsgsx"
    "KwW/gL7vAZu2Bjb1hgE2HLCxHTlNUiSNBLLQwKbfhzb3XlzV0b1NrKj46nLEX0qpo3sfrGJ7ewfT05OYmiJR1JinPCwAqMSFGnB9"
    "c4NUMKKoDzSwWV55imdfPNdOxhRKQAIA8sIXRc3PzliOTZ90bBhht4qniltqGUJLOs5eCEtd1nHMhCvHOBQWnFm0qrw6aHzCgBrO"
    "BQy5VvTqCvb87PMEzYOyi9Tj0BBtCkBNIipCQggC7pwWlPujhFNLFubZ7+8eWKul3zCHeK6rTFTHxkoO8ebnZ/GXP/0YP/nxD1Bn"
    "QSNjfoXIP5T2Kmz8yHz1ElvbLzSYWnCxluwcRjgjwTRWWC05IMOmqTJVAxm/7RhmZaOsbqAi+7ASdCiqxjyDKwkllm95epvAzEnT"
    "mwYtowKI08hzmvn4/dJmdZqg5kwDGu50znPKZghGOLsi+C6lxPl3zqFRr+v/jTo6DS1+6vZ6WgzV62tRVD/3/LnoOoJNz2vMY5ME"
    "HXedybIMMLGi2odtHXjTEAlNY/1RCOVH9+71+oDo6+jeCyu4fXMWN2/MotmoByd22M2Um0fvHxziYIVxbKYnMX7xouHYmOjeeUHU"
    "v6yjZKvXehljrRa+f+8ubt2Yw9KK0bEh76lMt4PqII4NiaLmZ2cwMan92PT7OSR7jjq2kj7hRwkv7fNMt0pz7oTjMAiwYNRsgqhj"
    "nL0VYBKrM4LI8+bPFtYVIaq4LaT35UtVqINO16Y82zwvLTPifpj2LXBTrD8Se7sHWDNBI3/9u9+boJE91202RofbGJCZ84EMf/fC"
    "Yxgpe5MPm3a7g69evsL2zgusrW3i8cISPn/APPuqAXNqh6uCWEu+aCkxHq45kyM2f4OBjJ2N+OsrKn8E5auPFaMkT6xkuFGnwRl6"
    "S5N3Jv0mOzJC+jpAy1nkxPB8VXk5mImcwE6eziigcXNFAIaIhblo336fcLmkoJURm40GsixFrZahXtfxoDig6XZ7Og5UV3Nu+rkG"
    "NnqzdMTPHvDhb+wDE1smHrAZFARTuNMbxbIqigK9bg8QsJ6Hb92Yxc35Ge2gTwkgccAjXGpKwXJstrZ2MH3VWEWNXzTm3jk6nR7y"
    "nHQ2XIdIB8UyEgwxbBiODZl7rz79InAL76c+E0VNT01ifn4GkxMTaGQa2BC3KBXCRRbnAMs+csd+ocjcbg0wkMDGoEIAw4CPN1fK"
    "VUPnZz9EAs0HAyYEaCKJQjzIMIK4VJBJ4jXtiZyoXcaxUDCEz4AY8j9DoqX1jU0sLq0yjgwLGmkG54FE5cdaIs++9VrNvVtcIT1g"
    "C2igpXB42LaxltY2NvFkYRmf33+sOTIWNLEJLkFeXXUhC+R9HWupVncO8RyQcXPBO0JgAICxWgqVfXm7sQOKt9jZMxm0tx+HJpOu"
    "VWTXiDBkSqKoAXnPSArevlOBZoPqOO6900inBWowQj3D8hwn30nyhtcVcHpcmjMKaHzujCeiYTua3uQrz7gAgCRNUBM1JEnCPAs3"
    "0O/l6PU0mNHBLbvodLro9nrodbVVVF4wAo9Qcwa0q4c9d7suO1F7HJsUyIvc+LHxlYdhxkRbGuCAjSykBTY6uvcqbt2Y8YJgamon"
    "DL0VDgSYe3v7+9hfOsCW8Tw8OTlhODbOj01uAB0EjH8WAhFcNVXX2Ww2tbn3nAE2gR8bzrUBNKBbW9/A9s4LracxN4vJySuo12vo"
    "9fqWIOnHrkARse10EpEULuwC4Qt7TwEKUhMQ/ipziRUIFIA9YzaFxBFhvz1RAIEDQrqlW85ayQIaBoCEUp6bgRiYcY7sdNvKdpYC"
    "mu5hbW0DC0sr+O0//avhyPTtYPxxOWAIASNa0sq+n3z8A9RqNaZ0TeMXNJne+KRU6HTaePlqF9s7O1hf38KTxWXLkXGR4P3ZjiXt"
    "2TdHkgjU6w3DkaEQBb7ZeVT5V1DQyIIBmdghMQAzilUQ+eaJtCvOm6NRRbNKLY4T0bpYy0NPTFWM4TOSwofzNuKz0wIkpwVG3ibA"
    "Mmr7pVV6GqDm7AEaNiWxQIdh1qHvtnn7U+MnI01S1GQGWZfIiybG+n0NZtpdtDtdHReKrKKMOIqiXOs2VelJ+30IOxt51oI4NmTu"
    "3dWm3EZ52ImhCODoeqwoqpD2BP54YRWLS09x+9Ycbkc9DxMQhLagMVVTEMyNzW1MT01ianIC45cu4ty5MesAUHNN3O5KsEIInzgo"
    "pdBsNnGPPA+vPGWeh2GVZl3sJKGBzdoGtrdf4Or0JObnZjA5OYEsa2iLrKKwbfhaJu7YT5wsJZxoivvYsQEPPRCsPJAZEi2u2eBb"
    "KcEBCiG0h99QORgOTHkcJlNPAvg6P9RGqI9D2tHeeDSAk4U2v36+voHFxRX85p/+Fcsrz0qiJf7E6AZZLc3PzeBTY35dM35kEABf"
    "b2zmjpQSh23tEM959nVBI6PWYZFfgAkaacyvG6Xo12X/OTGNE4q1pIEMj35dBjFeT8LLHteD+SJi96P7TAWpKV8WwVd/16CdJawr"
    "tr+dcTBD6W0AMycFLaOAiNMCI28SsIzyDEatN6yzdBQ4Kag5c4DGY+kr2tTtTVgRCGjDFuzkHm6jytvahNAcG+1XRaAOBVnUtRiq"
    "2UOr20W73UDTRO7uGu5Nt9dzOjb+wR3ESYkc+PzuRJa2ACkPayXakrm3V6ew1aRZijRNDLBxHJuFxVUNbEx0b1vcghkuxtAijv39"
    "A+ug76rRsbl8aRzvnDvngmAWOghTAuIa0JgMF4Kt40ajgXt3b2F+bgbLy6t4+sVzG6CQTwF97+c5nq9tYMsAmxvzs5iYuIIsS9Ht"
    "9jxOnWRAxbcIctctMfeIq/Id75mnZv2nQJX1hcHqIbDDTtdWh0Ywh2xKQSppRGEMPHljdlZRUiokelJZe95Dt50qigJ7u/sekHEc"
    "Ga/HJVCTiARTV/Xc/uwnH+HHH/8FMi6SseJbB9hsvEwA0qzNV69e+559PfPrWCojB9/8uo4id9GvS16+/aI2FUWhwXZJtBR/iBUM"
    "Flun4H+rtmsVfiFAWi5TVUVIxe3uVVEgPqvfDkQD/5GE28JR0qAypwFavk5OzLB8bwKwHKXOUfPztitfv+OkMwdoAH4y8h3q2Xmx"
    "1k8EawyxjsyvPsETl4MIGSBEoq0lMqBWq1n9mlaziXazg3angXa7ayyjuuiQjo0FNjw4ZdhxeI+PCFksLg+dzLIsQy30Y9Ool14X"
    "4RCJAzbSABu4IJh3b8/jzu15tFotj0gSqLHSPAMc9/cPsHSwavzYTOPqNPmx0ebe/X7PnoYpaS+rEgkElAmKDWMJ32w28OG9O7h5"
    "cw7Ly0+tKIqP3Q7NcGw0sNnB9JT2fTJx5TKEqKHX6+kYO1wEZRgZHED4rw1THOZXBByQEQ7YgGApA2wEgpx4K3i8SoFEWx7nh4Hw"
    "kqiKjvvCgJ+CiQUdMrciJ1lIvN7dw/O19QiQCcStrE09dIGrU9OYn5/BX/70Yxv9mvoeKWq6pmuQhUS7QxyZr7CxueWAzOu9sHVX"
    "V+RwIaVk0a99jowPZGIvkb7GlX0JkKnYBMT6xH+UMEQ1F7i6FjVCuUH3h7cZpwLfJFPj1NOooOY4QGfUsl8HqKE8+AbzHTXvaeQP"
    "21bAybg0Zw7QxExD7XXlfK74OjXKck441NHYR5hy7ATGFIoTIZBlmmuTZRnqtRoajTqa3QZazS4O2w1t8t3p+MrDfVIeVs5ZXnRE"
    "Thdm0LtKV8ncu5/naLfbJT82vO/OQV+KtKE5Nl0jevj84QIeLSzjgzs3cOfWPBoNP1aUnmZmZmzS3v4BDpZWShybVqul/eT0XCBK"
    "TYcElEoYwHMiEkCg1Wzi3r07uHFjFotL2irKuaf3nzEA9PsO2FCsqCtXLqNWy9DtMmCDMgfE1iVgfdB4YIMDGOHWisMSwgSrNM9S"
    "OFADRW+kolIWLJkl6MogASnncDBjuUIWTOr69HSZORPOKd3u7h6eP9chCn5jrZYYkAnGbvvJo1//xMRaqmWetZIfgNRflVJKtDtt"
    "vHz5Gts7QfTrKiCj+Ie7Xw5RUJgQBSPoyJgDQJ4XUMoAmSxzys1h4+yXiNyJ787VHBJbn53scq0nobS8kjLwNX0LT0bfvjQIyIya"
    "3jRoGQU8nDXAMspcnyQ/L1NauccFNWcO0FQcS6yIxL9GBXRS3k8+/wIQYaXmlG8ISJIkOvZTmhqrqJo19W4262i2G1q/xnBrut2u"
    "DqnQd8rDglmmDBpUeAbl7uwp+X5sNLCpVzjo04d+be6dpA3IotD6P70+/nj/CR4+XsLd2zdw6+asFysqpmSpCbsOqbC/f4CtrW1c"
    "NRybS5fGrbl3r6fNvUWSAFKLpIRSUKlgXAbnR4Uc9JHn4afPnltgYwkxe579fo7n6xvY5NG9GbApyPOw5bjoHyGgsZwXNmduifji"
    "ynA9Cf+PHZMry/QtLPDWdTkOjj+39JfG7I9dc0X29vfxfG0DCwvL+LVntVQWJ7mOGSAz7YDMjz/+cyvuo/8e4KfyQn+TUqJ92MHL"
    "V6+ws/Ml1okjQ7GWhiQOZjRXr4+kFKIgjH7tzx8X4OaFAzJpmlVwNKpgTVA/++vRrxKece+qDxrDxoft70M4MARqvQ3Dp6shcAzB"
    "4rcs0cTzT56+DtAyCiD4tgCWk3JjRinHx8if7bHTmQM0VeaKVdwPgBFmpkMxbJptDCF22hfQ3mWTLNPAJk1RyzIDarrodJpotjsG"
    "2Gjvw2QC3u/n2jqIcQP8zpc7pNgngZowkfJwJbAxQOO2WxoAACAASURBVI+vlCRJ0WikJqSCVmy+/3DBxIqa84CNxURccdbMo1Q6"
    "kOH+wSE2t7bx7tUpXJ2eMsBmzPix6SLPC0gjDuLjKEX5FgKtVgsffngXN27MYmlZO+ir1WpwShv+k+73+1hb28Dm5jamJq9gdvY6"
    "Jq5cRpZlxjmgguO4sE+NdKyVVvhIfDCn72ps6LgkdoJYWdLbIU6ff6AWVoFZ8rXlmW07CyaqmJ7h7p7myCwYjszi8lPNcVMcyFTo"
    "yExPGod4ZLWUOXBt54QtTQHLAbFBI1+aoJGbWy7W0gDRkpfMo/NFS+VYS3Eiz2CWIKulkCPjnlS0Ya+msObwziAww9KIwx71aulO"
    "qf6Kcqr05dua3gZQg1PIc5x832TeMP+oZWLlYnWEfVHA8bg0Zw7QVCW9/4rS9HGRU5i4X5QwaKBHoFwLNq8+WWZIjCiqVsvQbDTQ"
    "ajbQNsCm3emg3a7QsQk7X/7qbcUEaiK7rBtLBbCxoIbEa6biJEnRaGpz726vBwFhHPRpYHP75rxvFcU7ZL4rpS1S9vb2sbe3j43N"
    "ba1jc3UKlwnY5AU63a4x91ZsTu3kG+4VgUeg1Wrhzz68i9s357VVVCCKchwMAEqh3+/j+fomNrZ2MDV5BTa6tzn9S9Kj8cRFmnNF"
    "RjxlJ41uPegTteMo2X6bT44OiOFRsgRi1Do1z0QqBa0vY/rGQIkAmV8f2BAFv/ntv2DROMSzCs/sk5JC2SHeJz/6C+fZV/gQRkE5"
    "s3Xh2m63O/jq1Stsb48oWqpI2vw6DFGgOTI63lX46nLulv7MrR8ZA2Tg37fDGXi8GSHFX7HKegel+CtbTTd9fkzYHoF6dk/F8n2r"
    "0zBQMyydFieG+nKSPDzfUfIeFYCcNjcmVqYqHWWOSnUeFdScOUAj2InVJyTuUBkpBXrtDU8AUECzWbe3Pespnphejr/Z6DJpIpDU"
    "MqRpYpSH62g2Gmg2G2i2G2g2mI5Np4duj0RR2lkcjx4e9hdBu0R6HEUOhqmALM2g0hR5P8fhYVv71qnX2Vxxgqw/PM/D3S4gBB4+"
    "XsbjhVXcvTWH27ccsIlyx5ii6uvdPWsVRRyb8fGLNrp3t9ezJ2zFyrp4RUScNUEeG9PA5taNOSwur5jo3mmpXapLc2w2sbX9AtOT"
    "E8bc+wqSJDX6PZpLpgz9FkrayNPheKg/3jle+L85qNGg0V2j9cbBsT9vsGWFGTfNL4mW1ta1xdBvDUeGgIx9FiGoMf3WQMb4kfEc"
    "4oXrRhhwR6gOUFIZ8+vX1o/MwuIK7j/yRUsOElXvbaRXJQRKnn3jQSPDJJiOjPBES0NLj0zn/RNFud4y3OJ5B2CoyraGDj1Sn4rc"
    "+I6BGUqDQM2ogOS0wMg3AViOCkCO0ofj1H+UumL1BsfkqhdueDpzgIbGKsLjG2BFK5UpIChSOq5FdB6Zgi0RWGon7FKapppbk6ao"
    "Gc/DjXoNzUZd/+80DKipOwd9BGwKGbRr/jCwE4ERiK8znTPLUgAp8rzAIQ+pEGwBvIY0SZA2mpCyCDg2K7hzW3NsmhTdm3FH7JwY"
    "wiyNwur+/gE2N7dx9eoUpqencHl8HOdaLeRFgU6ni36eO46NcmCVTO/53DcadXz4wR3cvDGHxaUVHd07SRwEsPXojvX7faxtbGoH"
    "fVOTmJu7jsmJCaRpDb2+Pum7KXNgl+aD62S5JUYAxwfRYGVoLjgILe24EWBjv0sjWlrTHBnnEC+ItWTHzNanVfadwU8/+aGNfp2I"
    "RIeQUDBKzbznBpoLwXRkXmNnx/iRWVyO6shw3lNMDEx+ZCBgdb00kAmDRsbnEiCrJYUkCc2vR0z2xSmxcILxj0rfytV7zUTL+DNl"
    "QRCdKUS5xKA2vRxxhbzvShoGaoDhD/U0OTHD8o1a31HrPG4fjlv/oHJVC7KqjdjLWAI1R+HSnEFA45+Srft19hkvE8ypT4kYqDE3"
    "4wwQBjJcBq5KKRIdjC8x3ntrmQ6poPVsGuh0uoZj00W3GwAbGbiqjWyV3goovR7lvGmWIkOGvKAgmJqTFJ0lw1nQ4CyFLBywuf9o"
    "yejYzNsgmFZEYnZoAVixnxAG2OztWwd9717V0b0vXRpHq9VEzTgNzPPC6zMfkl3d5vm1mk18/95dDWwWV7Cy+swQSANopOGomX71"
    "+9rz8JYJwjk/N4OpyQkkSR29fh+SBR6l1yhcR+HasZjGdM6paClvjfARKDO/YSIwVxQFXu8az76Ly/jN7/4VSyur6Pb63mN1oiXn"
    "Y0cIgampKczNzeDTT35olH0pHhh1jnFyzOKhNaykRKfTxcuXr7BtgMzC0mjKviGQIWVfIYC0liHv5yiKXAOrSIgCFdGLKgqtc0Xe"
    "u0dNkXMGPxfwq4jkpAGZ9TZae/xcFYLd2CZS2lMqSMAwqOL5USqfwb4raRCoQcW18D6G5HmT+Y6a9+vIP0qZo5YbBnT4vEXzjgpq"
    "ziSg0SdK97184qWTtT+/3NrFZPTL2Tss1q21dFHmJM9OWawO/0QvkCYJhNGx0ZZRGRokimo2jI6NCafQ7aLb61vLoIJMj0dlvCne"
    "81gZpf1ypJpj0+50kCSJpzwcJgEgSVM0kkSLDUxIhfuPFq3yMAXBpPYckCCOiwMar3f3rI7N1Wnjedj4sbGiKKNjU+oJU+qm+uq1"
    "mvY8PD+DhcUVrKw81cCGiDYMsTf/+nmOtTUTK2p6EnOzmmNTr2U6CKYBk8r/A+vfKAJwacEoNn6uB6MLMa6hciCEChA364u1dSws"
    "LBs/MiGQiVgvmeqnJxmQ+ejPkdUy+KbnrtdWJEXKvgRkXr22nn1HBzJ+8nVkNEem6OfGHDzx3ldeWgMBfS0vCigpNZDxrJbYvlex"
    "ZQ56TWJE3s1n5OaQ7TwGQqJgJlJVHMAou7+YXwMa91sJ9by+g+mkoIbyUF2nme+08540/3HLjFJuFEoV1hPOZwhsRqWANp1RQAOU"
    "5wCjAZuYomaopMry+u1pMsnoiemBv8tUAZtalqFey9CoazFUq2PCKZg4UR0Kp2DMvbXysG6XP9n4yvK2ueCXK5Mxjk3H8zxcrpU4"
    "LgRsCinR7/XQA/Dg0SIeLyyb6N5zaBmODRiBsvOrJwUKcMrDG1uYnp5ywKbVtH5yyDGh7rdmKdhq6L8BBvVaDR/cvYW52fexuLSK"
    "ldVnSIkToMyzSNyA+n0dUkFHF9fAZmpyArVaTXNsJIn/uCM9xWgpX0sawAU6wSUg4a8/Xcb5kVnHE2N+vbT8FN1uz3+GfF1RP4TA"
    "1PQEZmcjHBkhSu3RXFCfpFLoGB2ZnRdfYmNzGwuLK3jwKAJkKhedvkFOFQGBLIuZXzvHgFVcGS1aKrT5NY/zVUqxAAdBP21nB++D"
    "wv6JgAy95Mo7bwzIVFwfoZNHvGv65S+IoNQotPtbmUYBNYhcD9M3DViOCj6+LrBSVS6soypPDMTw61XAxkujcGnOHKCpEitxdv9I"
    "Yid7irc/vY1MwRGrUltUH79QtSQMgUmTBEnNcWvqNcOxaZnglx0XToEifIeeh702OctghA3VX0UKWcr82HQ6JXNv1oo5yGo9hjSh"
    "kApaP+LhkxU8WVzF7ZuzuHVjDs1WU0MBA0IslyTQPyJRlNaxmcTU1CQujV/EWKtlzb11SAUiPhHqo9xza9RNSIXZ6zYIZpr4ysNu"
    "QMIPqTA1gbnZGVyZuIwsJWBDEdUdiHBghdoXhhsl2CMRfp+9c4ayOjJfPF/Hk4Ul/Pq32o+MNr82eRQNzx+r8yMzg08/0X5kXKBP"
    "EV2DVjRqODLttq8jY62WdvfKhQckruzLgYzv2bdsqcSTjrVEQSN9L9F8BMPWeWQ3qOh1RUWxrdg8t6GApXTvBIBCBZ/BvbjfmVNq"
    "++ynYaAGOH1gc9y8x8k/SpnTBCujLqZwTIMAS+z6ILDj7Z6jpDMHaCiRzowHcLgyJtuJQssUZf7ywIACJlox3R+kcEeEB4BIEldz"
    "ZOo9YgxlnNtp3YCsVtPRvRt1dJtNtLoNdDo956DP+rHR0b2LQrp+VSw34qoM6j9fReSgr8hzdIyOTQhswlWZpgmSpG6sorQo6uFj"
    "AjbOjw2PdB3thzLRvZcPsLm1o0VRBticOzdmHPQZrgnjpElAc10cM8WkRAfBvHcHN27MYWlpFatPnyHNUvZclFek3+9bYDM5eQVz"
    "M9cxMXEFtSxDt9eDKpTFJVBmXgUMUA1m1KBg5/FXmIiT2mfPa8ORebywjF//5p+xuLxq4lGxnjEQRdeEEJiensL8/Cx+9tOP8MlH"
    "f4GsltEkgoi+C/XhJwIyr17tMs++xo/M7t4QQB7UVUj0+gRkMg/IlEVL8UqKImdBI+M6MhVMJk9vxaZjgYpgVUe24jKYGUa7gk6r"
    "AewCVb5WKWqKgJk/pWgaBdQAb54T8ybyn1aZk5SLpSoQE6sjxpEZpazNN4xLc+YAjcdkCURKCgCkNJue0XcBWTOVaqpuxG4gRCxE"
    "6UlQhYK176r1/d6QS3n6IwCINEU9SbRlkbFAajbr6DZ76HRdAEzi3liOTZ5rRVY2At//juPk2DaD1zs28mgQTKsfE9RpfiVJgnqj"
    "rolcT5t7P3qyjCeLq7hzaxa3b85jbKxVaqskGpQ6VtTivgM201OTGL80bqN7U4Rt65xPKRtGgZz28f8t43l4fn4GS8urJrp3Zp6n"
    "ngxBz1oAPWbuPTU5gbmZ9zExcRkiy9Dr942ysVtvwgsvxNaHB6SFNr/e0559Hz9Zwj/+5p+xsLRqREtMpyYCaoQQno7MT370A9Qb"
    "dacLRmCeiLwxy6bo6wVxZF4aPzKb2z6QcY+yvMVzYiycaEkIgcwo+1ogYzgywqvQvav06XFkLMjkL0ppqbA1Q3nFwLNGRemKQfpN"
    "27uCt8nrGKWNIDvNY7RO+Jl4TfbSn4DMEVPsZD8M2AzKc5y8J81/3DInKTdq2UHlh9UZ2WWGAqBSW4NAzZkDNJRi+jGWO2GpA20J"
    "FVwrxUGB2UTYJkvfXWkBYt+HR0UfaBlxiyGujgChpF+SpglEIoAsc35smg00mz20Otoq6rDtHPR1jY5NnudWedgO3nyxoRJIsdi7"
    "zwav2JhMplJIBQI2dkLKJrpJmqBuQip0u5rokSjqzq153L45h2azEVXSDtOeDamwY0MqXL58yXJsul2mY0PzqxSUlJBSQUKy+oGx"
    "Vgvfv3cXN+ZnsbS8imfPnluHilq86EFD63l4a3sH05MTmJ15HxMTVyAyoYGNARDaiQ0cmBGwnByyWtrf37UO8X7923+xQIbAMgcz"
    "USAzex2f/uQj/OijP0fdKNfadUeAmjhFDFQVSuLwsI2XL19hixzikY5MRLQUSuQ4fS1M9Gu9Noxoqa/9yMRCFAC+S38hBIq8QCFJ"
    "tMSDRo62r1bnHfWgTXn99zXy6gypaRBdjN1z/XNzPOTQasZ6HBjjevCdB0Ehh2aUhXJccPMm8sfKnKTcScvG6opyUIbkC69V3ef9"
    "iQHUynRmAQ0lP9p2+ZRoSbA9Mbk5KW8bhGr0+V0JpphJxE+JALyQfxq+WTq/KoZ0MeJd3vwSIYBEmACY2tS7ZkVRPTSbTbSbbRwS"
    "qKEgmP1+3POwPyI23lgPaIZofLoUBzaddhtJmqJeq7OjY9nnT5KmqKcplHHQJ4SJ7r24YkVRY62Ws36i5yEMv4Q+oYNg7i+tmOje"
    "2kHf5Usc2HSNwzUNaLT0SSKRiQU1dDIWEDjHHPRxz8MknrNjMaCi3+9jbX1TB8GkWFETV5CmCfr93EXwZvOolFb23dvdx9r6Bp4s"
    "ruigkUvGagkEXBQbv75G64gDmR9//Oeo1Wp2TkQiGFeGqLFee4nQyr7tdgdfffUKW9s7WN/YZLGW9vQzi4BIzj2gaqUFMkBqRJJx"
    "0ZK/2vh1F/2ai5ZG2ZdI8wqRvFVlY6BiGI3y6xoKZoQ7y5TuDay7CvAE+dyrNVJyFmJhN0Y9aH8n0iAOQVV609yV0wQrJ+WqHHWx"
    "VIGREKiEbcYI4CgvbbTfVVyaMwdoPLPX0j2+yUdWstWx0TCjXA2zKTKEkEeG5n/Ddqu4MNQcF1dYQk6/6VgvBAuCmdggmHVjFdVs"
    "NNAmyyhSII446HPcGeEtGYoSHWPWwMvqvmVZBmGVh9tIEu3HprTWhNOXEQbYyEJqjk2igY0OqaA5Nq1Wk+k+wc03q1Mp5Rz0bZmQ"
    "CiZWVKvVQp7n6HZ7yEmMkSSQQukI2ExExJ/B2FgL3793BzfnZ7G4rKN7p1lKHXBjUoASCnmeY319C9s7X9ro3lOTE0jTVAMbpcFT"
    "QaKldRc0kjvEc4/cORL0zK+npjA7ex2f/kQ7xKvXaiYkAD0R5a0jXUzflZA4POji1avX2N5+gbX1TTxZXMH9h09GChrJk/Q4Mjqq"
    "e57nyEpWSzz513TsLokkqiNT3q8cmBbOumgQBiilOFT324G3ZEcRW3lcHF7tSGfFeD/Do6bXW4OWjjL0OLD8U0Kc4FI6CgA5Klg5"
    "rTInKTdq2UHleR2jrvZBHLEQCA2qO1ZP+OpE05kDNAB8rBB1ChF50VX5Z3l7AfTmPPj5eU/DmirrRr0nqFgeIHo6jp3j6EQrKLp3"
    "qj0Pa3FUF61uF+12w+jWdH3Pw7kGNgrwRE4CMEAHwXIhcGcIpwU/cCdS6FN6mhqODfdjo1yF4fB0SAWtPKxFUdrc+9GTZdxlnoe5"
    "qXEpCCYI2Oxjf//QiKKmMDU1ifGLF9BqNS2wKYoCCXF/hO/bg9Cmjj2l0Gg2tB+bOaZjk2V2TuzUmGea5znWNzaxs/MCV6enMDdH"
    "wKaBre0dfPHFOhYWCciUHeK5Og2YMSB4cnoCszPX8eknP9SipXoNiUjsnFiRkl1PTPFdKrQ7ZH79AutGtHT/wRO8MhwZP1XvcdyP"
    "jBYt6bWUmaCR1UVd/xxHRnvMtlNY2erg3UmFr6fwPoak+L5wRKQUzRrbVYfo4dsS1S3TIexPCOUUU0gIR2CTHZm78raClVGAyqh1"
    "hByVUQBO9DWJ1DGIvVnF6VFAnEtzJgFNlem28xjsXTRT6HNkzGHIbUQeFqzmiDmgwLYednIGwo1NowIbUTnc+UIFWSaCSYSASBIk"
    "NeHCKpC5d1NbQ3Usx8YoDpNVlPFjw4+Yjvti2rIspWCAgEU0Qe+QZSnSLC0BGzsXohxoUIdUqFvlXgWF+w8NsLk1j9u3YsrDfssu"
    "4vQ+9g+0ufd0yUGf4djkZtzKzb/3Bpn5hQKajQbu3b2NG3MzVhRlFVbZ60fkpigKG1Lh6vQkvve9d/H7f72P/++//HcsLK1qc3Y2"
    "BuW+whMtEUfmkx/iRz/8M9TqNQdgqEGBCKhRKHj06xdfWiDz4GEVkKlO3LNvrVbTUeHzvg0aaec/Wlr3i4cocNGvy3zU+PHB/yaC"
    "q7G1GfqIKbfi97H82x4dWP4BJyAVaZMV9YF8+MbEWzkubIk5Siyn0Z//dygN4tjwdFTAchbByrAFMoQd4OWrmq8qLs1xOTSD+mHT"
    "GQQ0nNthiC4DBb5FkcMnAZ7x6tKUw2TwlH1NG0rvaJaowAc19uQNgwO8Jkx54crxRP0N90QbK9A0mqapZeFrbk3NOOjrodXsGlGU"
    "CYDZ7VpxFNex0fjFzQ/BFV9C5oCMiNrI6uTp2HCrKDZztkY2hjRNtTl2vw/0gM8fLeLRwjLu3r6BO7f86N5CuJqcrhKcufeBtoqa"
    "niJgcwFjY9qPjQ6pkFuwqnh9AkiQQCYSxKBqNpu498Ftqzxsg2B64Nh95EWBtfVNfP7gMX73z3/E8uoX3hx6mNV0QAhgalrryPzs"
    "Jx/jk491rCWHOYXXRzt8066UCgeHhyZo5Ausr29aq6VRgAwfSsyzb79POjKxZy6CSoRVznYhCuLtj9SrEkgZUGowoinXPfD6kIoq"
    "uhHu5LFs9J4Rrh7cREVD5TPVEbb3P6VIqjr1V6WjApxYma+r7KDyJ6mDg5Bh8zEIhMTqifVpGJCx5UMuzRkENDxxkOEQC6OD9rfH"
    "UUE5gwM8vom2nrmKdcBBjQEutp0SJ8Zvkj8xRyNYmdCKytxPU6GD9SVaFFWvZWg2tWVUq9tw3BrPj03PxYpSFHPJ1GqAjapaOsEc"
    "8jEJADVPeZj82DT86Q1AXJKmaCaJ8TPTQx8Cnz9cwOMny7h7h3RsfI4N51DQc1dKYX9vH/v7+9jc3Krk2BRFYWdZWNe+QCITJprS"
    "9TWNKOrG/AyWlp86c2/+XOm5CRJhSUu9OLil+dSefScxO3sdf/nTj/HJj/7C9/UTgEkHZjS3RimFw45T9qUI3GR+PTxIoQMNPpCp"
    "BUAmGVgFPVIOZMgh3igp+hbZevkCrAZGx+VsDEuhWK90f0AZ2CKnizAs0OUDH/Kekn7WdzgdZfRHBTeD6v+mgM6brqOKgzIMOMXm"
    "9LgcmqprpXTmAA3XPwDYqVtZcmITP9H7M6x3UWWO7SUREvz9aaDiXbCRKanBQYJw5pU7rQX9C0MzeH2n4VFZUh4mYJMmyAzHptls"
    "oNXsMTFUxxNH9a2ODRdF2T8WkIWpanXy37Usg8rgzL2zFA1DtKsc/dlYUYVkwIZ0bOZx59Y8ms2mfcY+x8af2r39Ax0Ec8N4Hp6c"
    "xLh10GdCKuQa2OhqCMQZI2qlvfhq6yOFsdYYPrx3x5l7f/Ectcz4sWGiGKvnYx+uskRRiARTVycxN3MdPzNAplGv+84YwZeQcs9e"
    "CChJoiXtR2ZtYxNPFpZx/8EoQIbBhADIZLUa8j4DMkF/wkS7z7GATNU7JLyP4VUcE82Ulp7wqxmJ+A9j4kTAzJEwhXKfHrbl3FJ+"
    "XZT3OtePI7f+bUpHBTMxLsEgAnuctk8KNE6DM3OSflRxZ4aBjticHpdDU9U3AD6X5swBmmGJiH4V21wEub0Z9o9pjhoo/nxCfo0K"
    "rigoCW1tM8QEQeMpxoWJ5eccm/AaYK2istCPTaeLbrepRVHtjnXS51tFOXNvz3dNqZPseyn5N7VVlAY2h+221vsZGgQzQSNtaGDT"
    "7aEvhNOxMcBGc2zC+fHfGyuKWjrA5qaO1TQ9NYHx8XEbK6rX65l4TX45qRQgmJM+qQ2HyUHfrZtzWF55qv3YiMwDaS5wKRhHhomW"
    "fvQDNOo1DZ6F1o0KFch5KqRE++AQX718je2dHaytb2FhYRmfG6ul4RwZXpfPken3q/zIVD9kDQQVkiRFmlZxcSJ9qtiyROxXxZnP"
    "wwpHAjXs0EJXImX5tXBa6TBxbIrC+jvKsV+xb8b9pnfesG0EnF/l3x3Ype9wCglvbGerekzHBTlVZU+j/GnXU1VXDIBUnW+r8vBr"
    "x+XQhNejO8YZBDSOiFiTZ+82PyEHW6coZTXXmc4IYAk7L+hmkBEyc413gsxxlaKYiM7xWcjNgSlfBWrIcsqrn1dBm60QSKAtkbLU"
    "+bFpNXO0Wj20Ww202w0DbJwfm26vpx2leVZRztOs12YphTu9P2dZliGDNuG1DvrqtdLYeXtlqygHbD64cwN3b98w5t68FmXmWD8d"
    "4uDt7e9jb39fKw9f1Z6HL42PY2ysZZWTpdTjhpQ2koJQ7vRrOWgQaDab+PCDu7h1c16HVDBWUdSeIiBzdRKzM9fxP3xKQKburNzg"
    "psw+d+FgNoUo+PKrl9ja0qKlJx6QqX4aYZKyWrQUi7XkZtOtU1L21c+leqtwzyOOSqIAxj43Vo+wf3iHjp+GgBkva4y7MQBA+dkj"
    "/TUPexQgU/Ur3md/r4mXFQouMAh9HgkOfsvSqKBgGLAZtc6Tlh+1jlHqOWldMTAzKuAI664CNVX9iNUxMJ05QEMEhFKVxZPOG4n3"
    "VLHJEDCwjViw5IgRfSrKa4mfe+b8BKVsNn7SEh6B4x2wDtQCzOs2T6rX8IQU1a1sIe7HpsicAnGz0UCr6Tg2ZPJNHBsKLaDFTqZD"
    "UYxNY/XXI4GTEGHq6N6pATYuVpTn0M7MEY03TVKkjRRSFuj2ehAQ+PzBggU2JIqKHRZIt0ZPl8Ku5dhs4+r0FK5e1Q76CNh0uz3k"
    "yunRmFogEk7czfMRAq2she9/aIDN8irW1zcBCPz8r/5nNJpN3Jibwdzs+7h44R37TERkXliPNZAx5tdb2ztYW9vA4yfL+PzBY7yK"
    "ABlfvcpfLEUhkec+kKHo19qvjZunWHkBrfAspdQR4mtVSsKxpILPQakMptzyqtgv3xA5PraoJgYwR+TIhIn4MSP7CB4MbhWAHEAf"
    "QGH+C+gz1rcZ1MQR9dE4Bqiog5cblk4DrLxpoDJKfSq45xO7atASazM231X9GsS9ifaFxE5nENCoKIDxQU65nAM1tKVXJ2d5FIiT"
    "CIgIt2t5HJuqTUYZz6eDGo3iVf+Zl8CS+ea8qjoQlyTal4mO7q1jRTUaRnm42bAiqHZEeTin6N4xvB0sQ95lB2rcPFDRLNP94MCm"
    "xvzY0Fh4hdYqSkoDvAT+eP8JHj5ewge3b+D2rTmmY8P6Qc/aAAkppQupQJ6Hr07j0vhFtFpN9PvaUkvKHBDac7MLrEkox4mKAKDV"
    "0qKo7394F4D20luak5CzxiZEmDKdwza+Mjoy6xubeLywjM/vE5AJzu+lpeUGHuPIEJDhoiUfnEQc4hk/MjUKfnlE+ud1cRCHouJG"
    "aZdjF+ybGylrl5x3u3ShXC4Ei/5PfWgIQErVa36UmYrWIQChDLQ5Qp8j/ZAAuuZ/DU6lLzXfv83A5iSghq4NSicFO8PqOM16Tlpf"
    "FQgZBbTE6h4EIqv6UVVXNMVD3b6lafXBr65tbG79Ta/Xez/2xquA2IeiHCEEfv+HB+h0u8iyDOfOjeGDOzf8SqwYwJUXXn2jrA2T"
    "TxcKSrA6hCidfrniK/WbgAzxRewGT3mruiSARBiOTZYhI1829RpqtRpqtQy1WmZ9y6RpiiQRzjkd41pUtxHTBaniRsCa+Eqp0O/1"
    "IZVCmqVOLMdAA6VEaP8mItHxlPJ+gS9fvsbCwgqKPMfFi+dtfCbP9DnokVIKvV4PX331Cl+9fKVBjFIm4/nICwAAIABJREFUMGhD"
    "h0KQxHMLCb+wHA7Bxk3PJgQxHrwJgKGSOtbSzs6XePrsORYWV/BP//IH/Jd/+DUWFlfQ6XQZl6k8n5y7IqW2FFNKoVarQUoJKaUV"
    "P7r1JUrf6WeRF8hzF2vJeQQeAsLdcP2JHnhoEMEYIjnCe+x1oi8OwKNEjsL3raotPrc+kya+6Nk5JuhceFVE/oftUju68yIxIFJo"
    "/bPK6RlAwqjeeqOxd/7C+b9/+frVIWvcbh+Rjn7bUtW4Yg8k9gBj5U6rX6eZ3tSzC8GfCj7D72FZ/nnU+8PuVdbTGKudDUCz8uC/"
    "X/vs3/1vf6uU+ruXr169v79/UJmXm/WGUbAFyoDm3t2bLA8RrDIQ4vcxFNi4XZUTP3bF9pHa4GU5QebebhX7o1x2n3yEfTUpEQJJ"
    "mmond2mKWj1DvUbApoZalllQk6Y6Cji3EvO5NHxeB/s25TPl9SfR1llK6bhJSkpNgKmMB270/0QIpFkGIXR07Dwv8OXLV1hYXLXA"
    "xloisXmN0dxe1wc2SgH1Rh2tVhNZmulAl0qWnkc4fm/uCf/FRFgCUCZo5DYBmYUV/NO//BH/9e8dkBmUONaThUSv34OUPpDJskx7"
    "mRZ81v21ZoGMiX4NgVKZoUDGm9gQxA0/gI4mxXIAsgSRKsqX6w1jr/F74XvlffHqoA8RXPJ/sLmOY5kSiKLbSeK4Ynmea2YlgyLh"
    "DIeJ13vxwvmrH9794N/MvHe90el1n+zu7e5Bc224Pk04gO8SsAnvjUJkR2nrtNKbBCpHTSGYiS3C8AQwKpg5an+G5n+rRU6rD391"
    "TUB8JmXxCy0GAeybToSdiYH8DTVu7hhLPieHspYd9gEIolgL63yuLPKKyMNH2MU5ICv1E5r9rcyWZEcpNKBWiqTwEWm8AXTWKgpa"
    "cbhho3s30Ow00G42tfJwwygQmwjfeR4EwbTPoGIciB+DwkxZlqGW8ZAKTnnY7udsYxdw5t6kPNwT2o/NI+vHZh6tVsM3VoPbycmS"
    "i2JF7e3tY3NzB1evTmJ6agrjly7i3LkW+v0c3W7Xxsgi8YP1C+IBzZBLqs2/yWKq03GxltY3t7GwuIwHD+PRr1GqyR2YtPl1DmG4"
    "VnleGGVfLloKgTx9FbYOFzQyQ2k/GmWbiXCOKmUxXqXDwM6QHLxvkYwx3kq18uzge9HKKxZ1OLpho41eDzcsCkdSUUtM90eZ60oB"
    "58+d++tPf/ijv969/cEvP3/84D98sbH2GkATQANAHVocleHbL4oatGro5RKRe2HZQWn4wj7duo5a51Hr5fWr4DOsU0S+V7U/bL55"
    "u7HyA9NbCWiePf71NQHxWVEUv8gLHQDQqb84BVt6ocsExSRfe9IDHUSKnOIwqAFLjtwJn5+2AdLNAGBNvV1O4g5QI+XnElsR/Lqn"
    "vwL/KYYbpaUhgiCUATOmbRo+TQUBv0QAaaLFEqmJ8N1o1NFq9tBuaVBz2G5bBeKoufeJtz69aSvhex5uk+fheh2AE+dwRWIFHYwy"
    "adQhTfTtnkjw+YNFPHyszb1v35pDs9Hw5zDQZyIl811m7n316hSmp02sqLEWilwrJ2ulaX892MrN87bER8FT9t158SU2Nrc9h3j2"
    "mQ6Uv7i6ej0XoiDP+0xHhke/ZuuPVyOEiU6udWTKVkt+uaqdqUqBtkLnOSw9Wo4QidM31rdR6hHer+BbqRKfBzLK0o7lCa/xXTt2"
    "xPX66Z2+ykBmIDBjfyigLkXivvDOOz//9KMf/3x3f/+7DmyAOLipItY8z6h1DkpvAqgcF6SMmvi8DAIzg67H5nkU8DMohSBKAW8Z"
    "oLFARha/KIoCSkprBg2A6WcKC0TIaV5VUkrpmDR8JyOaoxh44KENgt05Zn0gOEUEYRdnumx67J2Q/aXBEVnEZ429pY9biuvQ8ExK"
    "QJkI08Q1cCCLKTWb8k6MpMsLIbS4yfiy0RZRdbSM8vBhs41Dsooa4McmTMPemPhqFhbY9PMcnU67xLGx3AoCt0ohSVPUk9RYLXUh"
    "LMdmCXduzePWzVk06g2PrCnvfdDzIQEHbLa0VdTU1ATGL17EmI3u3UVOHBsGrvnDKWSB9mEHL185ILO4uIL7jxawu7tXRcX8yTGV"
    "kkM8QDAg0/etlkRY2K+Tx1oqAxnllaODw+CdnX0bQGTLyZF33k4cZATjqDoFVHfSlBnWV9anIV2vYM6MntihKAQ1pcZK/S7nqhSf"
    "hdfM3nbhnfM///SjT36+d7D/yz8+fvAfvlh//l0GNoA/0TGOwbcVqBynvzGQEp6vq7gvMfAxjEMTlg1TtOxbAWhWH/7qWiKSz5SU"
    "v8gLaTky5N/D8R2AcFcIzbaj8I+BA6vaYE8xGhQMnVvGifEADwETDlBYm6WOKFix1TCTc16VYqDGH6trgK8qvzL9x5alUz9g+6FF"
    "UcbzcGrEUY06Gs0Gms0OOp2OD2y6PfT6fS+kApsUjLZWERAKV6aWZUBMFMXxDNxcQvjRvbWDPh3d+/GTZdy+NYsb87OWY8Ogkftj"
    "HqNUwN7ePg4ODrG5tY2pqQlMT07i4sULaDabyIscvW4fhSxgraGguSiH7Y4WLe28wObWNhYWV/Hg0QJes1hLnogzMiUKgCQgI3jQ"
    "SC1aKulcBRPKdWSklBA21hLVHu5D8O5V7opB9ipuTbnG6psj7WijbtMVw/LxQGzMgysd3H58rYc7dgwMVj0FL+dQS7c4YAv3Av4c"
    "Lrzzzs9/9tGPf757596fgE018QVGW56xcoPS2wJURm2jiqycFN9XkquKfFXJA0jfKKB5+ujX1xKBz6RUvyhk4b2RUblxxVLjlkAO"
    "OziOBPdLwmsnWTM5lItySoKmFf0ITluWJ2K4JK5A9Zau63JAiOsIueK6k043uFwfndIdgdZ1KMDjGHm4ytTpGDjOZ0+WGcXgLEWW"
    "ZWjUa+g2G2iSfk2nmmPjJiU4ZYZzyPtSwREAYqIoMvemphQzFdcVUnRv7qDv4eNlPFlYxa2bs7gxP4Nm0wAbLpI0nREUaVwp7O3t"
    "Gx2bbUxPTWJyckKLolpN66yub8I9kGhpc3Mbi0sGyAQhCsL1pcC4azA6Mj1jfl2voW9AYzTWUmneNPEl0RJ5kC6n6j1iOHjga7Wy"
    "lkgbsf0rXBXlPbKyP0ETnuKvueeB1RFS6SAUdjdaojqFYJlfZ8ejIRWEcx0HT/zQwhXS9dJSEfAocP5PwIbSIK7BmwITR5nH4wKV"
    "02ijCuDFXlw+h6MCpJOCMK/8NwJoVh/+47VEiM+kkr/oFzIYInNVJ9zOpAxLgfuh8WdtCPEkDocK32wWzI2BmmoiZLy+BEBAf1Lj"
    "Psek9HTtAA14YfagSqrK5aC8Gv1EG6RVjTZ1eKz9qA5RuR0CNk4UpfVZGg3jw6bdsNG92+2uju7d6+t4TCSKsqCGt+b6apsVLseg"
    "N8AXRXWQJNpBHxQ5FqS8rhbtoC/RsZy6PYhE4NHCChYWV3Hzxgxu3pjV0b05MIh0Qhpgs7+vRVEa2FzB+MWLuHDhPBaWVvDs2XNs"
    "bG5jaXkVDx4tatESHzTKYMaNT0EWUvuRgQYyGiz1PT8yVsm5VI2+oGMtyZFiLcXn+6iHpaq9adAeVVVHuWe+XhB7Hymn8H+XcjMw"
    "U95pw1IquCrYuhh0aC/vNvz15m+t3/8hYIjKVgCy8DLX6yJldAh4QXdB7wlHfAI4f+5PwCZIgx74UcoOSicl5G+6jVHaHQW4VNUx"
    "rG+jjLFUx9cKaFYf/OqaSMRnUspf9HPpCKzQpJiSft3cJkabAw8gSGyJkvMx9uk4EpwjowHIWKuF8fELEEmi2fLUthAeaCqJkmA2"
    "j7DP3kkfZu8oB72sTGQ9BQRjcru2UA6gVFQB693WDb5UQLE5gflePvLq8SVJgprQ/klqmY7ureNFddHqNNBudn2ODRdFkYO+IA3p"
    "3sBUs1ZRhQ9sTF0cSpIlWpomSNK6p2PzZHEVi8tPcevGLG7dmLUcG0ETWUqMY8OATbPZxMrqM/zun/+I+w+fOCBjuCV6eNUDdFZL"
    "QJbFgYztQQTIhBwZDWQGn/xpfTLsbe8oFRexkJK5D4JHaOdIqfIIEG1LRH9VtEqEfbSX0QNT/hZQRetU6Uq0E5HftB81W010Oh04"
    "cTjgz7df1ntrFYNOKrKHCGuuEAzDGURcPH/+53/58Sc/392/98s/PPKATRNxYCNwpLf3rU4c78Zm/NsGVE763Kp27mE7eoS4Dc03"
    "LAWshDecVh/86lqSiM8KKX8hjb6FBSgWtETiyigXLJAI8IMHj7G98wIUB0dndESapxBkKKXw4OECPrh7C69e7+HPvn8XN+au4/GT"
    "RWxtv9ABCY2ipdsQIj5tbAMIHo/wgIL1IcPMzBEZZxi/SQdPZHWa6x7QYnhLc1SS8vzRnERAFT89EhH3Plm/uLWXLJQmuobwdrsu"
    "urfPsemh2+2j3++jkLIEbMLNlU8lJ02VC9T0s08ecUkUVZ6A0tqQUmrnZUKgXq8jTRLcYhwb7nvIzbupy6sTeP16F1+sbeA3v/vX"
    "YHzOjUBs6XjRr41IDUAUyFRMgMeR4fGZIpPgXwlpXaRuT4TjkG+5fLn2aMtH32iqwzPE8ob3fQ4G58IGXJhSvT5nJrQStLlVWC68"
    "zvpSymuObEJgbGwMly9fwrlz55CmKfr9HtY3NnF4cOitu2A4fpuMOwMojI+PY25uhvXf/yQHobF7fE529/d++YdH9//jF+vPd+GA"
    "TQM+sPk2gRoV+Tzp/9Oq521ri/8nK4lh7b+J/vE63+xCXHnwq2tpIj6TSjkgAzhOC3sRyXSa3l/9MjMrJ1P2/oPH2N7esa79KVFd"
    "JT0U4QOUixcu4IMPbiFNUigAaZLg3DvncHh4iCdPlrC988L5HWGbGzl6GzRhpcCS7DOWTAtU2PaTQJwl+voG2+DYJia00zztyTbx"
    "z6mD2vY2y2CcvE9RMKQgpbHAMXok3S6FUdCgRgfB1PGiotG9+djYtbDHHvCp+KqUQj/PUeSFjRVl+2rmITYTsig0sEkS1Gs1JEmC"
    "2zdncfvmnAU2UjoFdcAnMFJK7Lz4Cs/XNvH7Pzzw+y2EU6VifT45kOFWSwmLfk3g0+WLElf3tZSfXfUIOa9Dua88Oy3ReHvAMTaa"
    "IzjfK41Zse/sXaES4UPxqysB+qoUioP8n34feD4hBMbOjeHK5csWyNBBqt3u4PnaOjrtTrDmgnqDavkYL45fxNzsjB6nEO6wyL67"
    "/cwHOSHAVcoAm4ef/6cvNtb2AbTM/wZ8bs23JY1KeEfJ8yaI9tf5f1i78pjl3tS434yn4KeP/vHa//nv//e/VUr+nZTqp1x8QwRS"
    "M1jMCyTcjhgCGMvFMQR9e+dLHBwclAivt8Gy6/7LqdDpdrG2vgklFS5ePI9EJOj1tOLo9evX8L1330W328XBYRvKiKKciXa8XjsG"
    "Gpc98TgOxzBlY97H0r1IWb4n89hNHHhZb7uV5MQpBhP48zY1Xo8ZPv1OEmEJapamJoyCC6dQq6XIUu21NjUcBDKf9x9VlEUQjJPQ"
    "lrtG4Ifup0bcIqVCr9eHUgppmtr5izUhTEgIQHseLooCL1/tYnH5KYq8wIUL51GrZfCeiJl4BQBK4fCwjfWNLXz18rXXa6YWBQgN"
    "QlyIgrr2RFxI4505BDPhM9O/tWdf5xCPB5ukafLGFy7SoNYq7gwv6+pwXCm7pIR7NJXJvfrhpXJ/gn4cB9BUdoA1GM6ELe+NZXC9"
    "xwEzQgicO3cO01enMTkxgbGxlgk1kaDT6WJjYwubm1sG5Oo92u6HkeGEejN0v9Gs4+L4RbeKaD/yuDDCuwfvnv/8m43G969/7/2/"
    "ev/d92qH7cOlvYP9Q1vI//9tS296TN/EnL0tz+m0+yGANwBofv+r/3ztwvl3ftVsNv8nLYEhbgOBGfbi8A2EOBC8MtolCNwAuHjx"
    "PPp5jv2DQzYMV4ctRrcs58NVJ5XE691drK9vQgEYv3gRQgj0Cdi8/x6+d3UanW4Ph+02AxnK1ssVecu6NMJynBDeY+BG98tQCN73"
    "Eqjh4M0OzO0kpk7OtfJDNrA58rha9Fe4cYhwfMIr64CSzp+YUAopc9BXq2XIDLghV/zapDq1fVR8mMMADetHSOb9PECSasseckSn"
    "lDTAhs0Xn0ZoDleaJFCAFpHlEl+9eo3F5VXkeYELF94xIRX4etVE5PCwjRdfvsRXL187gMV66WItwY+1lKYOlESAh/suUBSau0Wx"
    "loRIRiK+lQy6gUAkJhKNdE8hmq+SQ8TKef2o6OJgQOGeYJyT5LcZB3H+zXA+BnFnSmAmAC78GrmcOHfuHKanpzAxOYGxVkvHL7NA"
    "ZgObm1sm9IWzaDSQpoTJaJe0/VAO3F+6NI53371qrOLMfkPzpF9e+vDveWMvzZpes0n64eUL4//jq73d/+ew026bTFxB+NsAbErb"
    "yjHLf93pbZv3b6Q/pw5o/s3P/5e/ybL0r9IsRaPRQK1WgxCJ04VhL5XbjVx5EX4zhJM2nDTLMDVxBe9enUae59jfPwhAEK+Mt+OA"
    "Ec/6+vUunq9tQEqFCxfPQ0Cg2+sCAph5/xq+97130ev2LMfGES2fsINfM4OybQV4hPoWTcrlK+dwRNn98UGI49IE/WGcm3gKZOlB"
    "3pjIjbeXJDr+U2LAC3FtMhP8MjNRv9M000q6iYsdVCmW49yjEACXp8y7lyTa/LyQ0nJGLMeGzS6vOzGAATAcm7zAV692sbj0FHme"
    "4+KFd5wZtND95oCGE3lp2oUCanUCMkUJyPjj8X+VgYzba6Pcl+jDLc/t4J2mGkjYWQu4LvydqGqzqsLjAhrOVRm1Ob9Nfz251eBz"
    "Uz2uVCSF4Mb90rOigcwkJiavoDXWQmY8O3dLQCaswSIaeHsJ58hY7o3ApfGLmJm5jitXLus1asCKt3+GACf6zvvzLqUyunJanNzt"
    "ds8pqdZevPryj97UlWb5rSOwJ03fZaDyNvSBp8r+nCqgWXnwq2tLy6t/u7e3936ea4drSZqg0aijXtc6CooURCt2CG9roA0nBEFC"
    "6x9McmBzsO+JMzhwKIEk/kto65VXr3fx/Pk6pJIYv3DBcGy0q/nr16/hvXevotvt4vDwEFyElsTG4TCN+Tlw544QhGA/sFwXfa+0"
    "h9KmRNGgaTOzxYXta9kPiqmAbfT+ZufX4fUwqMs56EtcEEzDsdGfhmuTmgjfRhxF9XrAhlGS+LMsDSJYOzon+WKRUqLX70NJHd2b"
    "1pSbPzsqCJEgMbop/X4fRSHx6rUWReV5jgvnNbDhgOZLI3KSUuvIKAXU6zVIJVEUhQFyaQWQce0LMRjIVBP6mC6JN7gR0jE4PUEL"
    "gxWG4+WjN1C1RfB1jUDMMwK6Ka1z/3clh4kyspcv1hL1YoyAzIQGMmmaIhHCcGQ2o0CGuLOOQ8O5tqxVdm98fBwz19/HlSuX7eEx"
    "BmZ8Tg2/z+fCcZalVNYzdqfTweFhG4eHB9jb2wcUWq1zY//19e7rfTjYZeFXMGNvGzEcJYmK72+i/m8yvS39oHTi/pwKoFn84z9c"
    "+z/+3d/8rVLy77768uX7z9fW8Xp3D512B/1+rqMAp8aXSb3uARtvPwpfBzqk0CklQsmzWoaJK5fx7jQBmwOQYkiJ0zDkRCiVJlxr"
    "axtQChi/eAGJEEbHRgOb733vXfR6PRwetgGlHJem4tUtgxW6YaBEeBr02FWcgLnd16uPnzI5hyb4Hd5jxeE2soCg2bljfwX/Thum"
    "zxWitjXHRgObLEtRq9VMhG8NcCyoYaIoPTUKsYcm2G+fdDlrrdhcC2jl7zTLIJXjnGRpasfo0X9TP4/urZWaJV693sPSigY258+/"
    "g263hxdffoUXL75Cr9cHoFCv16GURFFIO0aa2zhw1f+LokCex4CMG318DfsAoJpfMCyNqrcCr71yV0ashI0lBuqHAZrRmonMVgSw"
    "V7cXnhzKoNthb4Fz58a0aGniCsZaY0jTBMJyZDaxubmNTlcDmTL4I9G6M5iwPmWUvz+UgAzToUti7z3fR8x7GwM0gEKeazEpAZmD"
    "gwPs7ekgrp1OB+fPn5/+/t17fz3z3vu1Tq/3ZHdvdxffzmjeR+3z2zLGt6UflL6u/hxl+yqnxT/+wzUh8JmS6hdSaVPjh48WsL6+"
    "YWoXaLWauHL5MiYmLmN8XDsiI/fzvV7fRDMuSubZAKz+jZYW+S85P6VwDkin3cHK6jNsbu84VjEnWsptQJx3LuBORUS4a1mG999/"
    "D9fff8+AMG3WfW5sDO12B48XFrG9o829aZPwnNcFOxa1X3oETH9ISb0flJSevb67OeJEnjay0ALMT8xkntXn9ZG+RIhnCJj4J42Z"
    "10u/CylR5FqptZ/30e320el2I56H++j3+tpqyUZY9wbrAasSS740XD5TLl+RF5CyQLPZ9Pscjpe1JaVEbiJd1xt1CCj0ej28NNyZ"
    "Wq2GvJ9DQUVCFPi1hre05VMywNJpBAIfTYYMBs8z5Gf4hC2oIThIxDmKQVv2AFKRSqA0BOpV4lHBs5Tf5Ui//TyMkHPAHqz1mCgp"
    "WrfZY7j5dZYRUBbodDrY2dnBbuAxulQf+yNpH7SAxjQoNJCZnppEo9kYEbCEQDgcv6AtyADqHL1ez3Bmumi322i328jz3Pbx0qVx"
    "zM/P2mexd2CDXpJ597fBIZ9in+H3b+r/29CHt7VPAJwr1yOlpc//2zUBfCYV+ZWx2wYePV7A2poDNJRarRYmJi5jcuKKBjbnz6PZ"
    "bEApZV6gHvLQEZsKiK8BNWTy7TYdem0dUep2u1hZ/QJbW9vRMYQEjCCPrZNOOonWB7l27XuYef8aksREq04SvHPunAY2Txawtb1j"
    "/McIV79ifl5A+1V8U+OARsGEIfByMIJM820q5xsamW8nwm1U+lnY7CCzazbN1Ds3J2FB0wWNDx1Hhp/0rCIkf14BCFNKm3sXeYGe"
    "Z+6twU2n20Wn20Ov20O3pyNKlxz0RYhdrN+idM8fp4DWyZKmfjZMb8BhW+THBtBehHtdTQCUguE2CVaTv8poSnkSQriwEaUUL1OV"
    "z282fMaI5KE+uBthW9XE3fXNW0PmewmMBusI/iUvc/V4/fmo6ht/18pKuzGxaiiyi7+nfpsCY2Mt50cmS+270Wl3sLPzggGZCGBW"
    "/g/qswwPcdCGC9PTU2g0G050bN97vk7L7yWfNw5y6LlpMakGMpozo4FMp6M57P6zVBgfv4S5uZmAqyuwd7D3yz8+8oDNWXfI93UR"
    "7Tdd/7elT0P7d6RFtfT5f3McGeP8zfl/0W08fKw5NAqaY8A3FiG0I6mJK5pjc+nSOC6cfweNRgNQQK+vgQ1t7pwoSqWBjFTS+bAJ"
    "UklXRSm0O12srj7D5ta26aMj9J5jPy7uMCmxwEC/f2mW4P1r72Hm+jUtEjB5zp07h8N2G48eL2Bzc9s6xpOhQznLCfL77nM09JwK"
    "VkaPzeRlY7PjSfxTWpIk3sbFx0dJKhdywhf9Ka+d8ERPdcU4NbYuznEKuG6U0/dj00eHHPS1OxbguJAKxkGf8WMTzo3rMJ/XCGH2"
    "JxAAUG800O/1Qa4BHOWNEISgPlkU2N3bQ7fTQ62W2XVCXfOJbTWR1g7V+sFVH6CM/qIKNwSwZxm+LicCNK5DIpLH44zYSqLFS+ui"
    "CkSGnT86dyaowS3mEueixJEKByI0l/bSpUs4d26MiRSJI/PC48g4S6VIP9kX557C7U2WI9MwHJnEgZjyoSIGZuIzSQ48daywvuXI"
    "dDo6EG0/z91eQPuEGQc57vPFWrDrf3d/75d/fHT/PxpgQz5riGuTwXFr3vZ0UsJ+krJfKxB4y/4fu48j7ZOLf/j7ayIRnymlfuGB"
    "CfPiaXGRJuIrK8+w+vQZAAYSAECRvol+IcfGWpicuIzJyQlcvjSOd955B42GdojW6/XQ6fY0m1NKK45ynBnlhj3g5Med23U6XS2K"
    "YhwbG0bBbFKWMBsCrMFM4vx9mM0vyzJcf/89zM68r0VRZmzvvHMOh4ca2Gxsbuv+hyc9xjZxm5kDAW6+2JhCboPyN2ra6BIzv8Sd"
    "8U+zHNzAbpqAYt+pO7bi8gZvroWnM84NKnFo3EBdB8w4pFTIDau73+9br8MkgiKOTbfb1Z6H81xzVFC1VbtBxu4HTwP1eh15vx8V"
    "OVWBGV5vr9dHu932vTvz9oIhx1Ic0PjtHgnQ6JZLfah6UTiYiYGJ0I3+ILFUCdhEEPFAMIPBcxX2IcahUeyPf9t1Ig7gApQX1E8H"
    "Mu7ZlwBEu9PGzvYL7O3tBe9S0I9yEyjpy0BzZKamNZCh95qLl6hdDiS897wC0EilRb8kWiJdmXZbA5k8L1BeO77YbmJyAtfeey8A"
    "NH5fAGB3f+///sOj+//puXbINwYNbohjcxbET1XENXbtbfj/tvbra+vjQKXg+7/7f6/9X7/4t38rpfw7JdVP6aWjLjnlNfNCmlPF"
    "ysozZt4qTF7z0xTu93Ps7u1hd3dPi5sM8a/VMjSbTWMVJVAUXClOOa5D5AX3Ets0CIRMTVzBu+9OI88LHBw4c2/aZ4hQ27pN9+11"
    "86mUsubeRVHg4oXzgBAmThAwc/19vPeedtC3f3DoETuvm26X8LusnGzebFue5IdXJkwnY4qANpvtO6uTXXObPAFOH0RRG9QobVwx"
    "UFPqotcOK2/uJQk5xQusooyjPjL5TtPEOuhLyEFfSWzoNVy+FvzW6yKFLKQF2nYdeJOMyHWdCqNXUyWicHNenZIkhZShyCkkTKMm"
    "n2LGuxWuB31NRNoql4+DnjAplxUi/M56UZrnkQY7pA/Be8Uu2vK8nZiuk/L+MD8yxiFekqZIRIJOt2Otlrqk7Os1VwZVymvEXDHf"
    "L42PY3bmOq5cuYJ6rW64xM4xZVTh17xHOvyJCPKZLdiIermyL1ktkbJvDJRz7pKC1j17773vodGo27rtOgr2HO2Q79pfXbv6vfr+"
    "4eHK/uFBB2dTnwb45vt2TbQrAAAgAElEQVT6Tbc/avpG+zkQ0Pz7f/u//uexc62/ytIU0tPtcCcEmwyRa7WaeP16D6vPnlsCpZOy"
    "QAHuCvJ+jt3dPc26N8CGHI81Gg0LbKh9aich9iu9tLE+USNEqoRArVbD5OQVXGVWUVFPxnZQoLfVnUD+f/bepUmOI0sX+zzynVlV"
    "mVmvLKAKQPedJgE+urW8Cy2mR3dxZ0wm/RP8Aj3u7GQm0252Mi2keyUzaTFmMmmlhX7AkADZPT13hiRAPNgkgUIBqHe+I/wu3I/7"
    "OR4e+SgUQICEk4WIjAh3P+4R4eeL87TXaZ3h6OgE3//wI7I0Q7u9BsACGwDXr1/D7lUbefi8b3TjYAuo3XCBk1/btF8gGEdQRCcb"
    "kwK8lwM82HC3RoAYuejkpDesfg4cKcMs42AmbJu1y+r7Xc+9yO6H4tiYmDXWzbvsA/RRLJsk5hXFpisgIgpq6FipbJ5tf5v9/SV6"
    "42+oOZ9ZzyTHwaM9zi6JTZAaq78Yg4+XOMQy7ct2Q9A5qyx2bQy8zKsRo2kWDaYUj3Jefx4UsZvMX0RFkX23nft1uVRyXks//vgE"
    "T5+wgHiufgxQyvMhqOl0O/jVr69jc3MDFRviwgMT2g+3HsTw9Yn/aQ0BZAaDIc7P+zg7O8PpGQGZMCUJI81+SJJB/86VHra2Nv0a"
    "VPhhY1rKshRKqU9a9datxz/++f+DUTm9K2qni73QF+/nbS9vO51qJqD5r//Lf/O/INOo1apoNusu9oZzq2VvAZeW7O7u4NOPb+Lo"
    "6ASP//y9c5m1l+a+iJRSmEynODk5M+7ewxEm04kJDV8qoVaro1azcWyojSQCrEJgI77CIMBKuVzC1uY6dnrbmE4nOD87dxcSUHB1"
    "ETA7ccbYyrg4NlmGtbVVAHBfbDcYsOn3B5Gv+diiLMfEFwu/kPgFOWG0RYGKAybaHZcLEO3H/6JF8ToF9LM93w3R68fijlMcGwrQ"
    "x+PXMHfvsnD3RqDaCknJwVxXSqWSABOOEbtxx2r6uU/TzHqAaMZQREtziwHs9HUc1CkEVMUlKqAQL2vYprx//glBMJY40Co2Gl6m"
    "xCV8RdcuXHT+J4e5/NmnK5TiEpkNNBt1JKUSFIyNzJMfn+IJAzKAnAMJVgJDfravoNDpdvDrX1/H1uYGKpWKlcYoZtjPAQ0/bq+j"
    "a/g+8kDGS2ROcUZAxuasK3pvCMhkaYadnR5u3foQnU7b9B1+UIq1QiHLUoxGY5yf93F6eoazs/OtJ8/3/z2MuomMhN92QPOq5W0H"
    "AGF51+il4uieCWj+8j//13/7/MWhiZugYYBNo45SucTsT+AZE2NOKlHY3b2CTz6+hePjE3z33Q+GQVXKDNQEX+wAptMpjk9OcXx8"
    "IozTymUbx6ZWdS7UTi0TMmCBZCC+bGgRgDIGy+VSCVtbmzZAX4pzl1LBMP+4xN6DDS+RNUZ2PvKwATYKwNBKbG5cv4arV3ccsMmC"
    "lcS0qnOLMC0Y/qtIHqOLiiQ0fH7jv/3inr9OXi/taxRHAPJ8bBCuHtx9Ev05CZZ5fhLrYVYuS1VUmUBN2YOaUiCxyauiAoBrt+ZZ"
    "zjhq9TS6Q+F77p9bB2jCe7nE0pCUSsicl1N8/i9UVFg/BmbM8bCfsBrfhuDn1UsRXQXXzus5APPhtRxq87FIILOJRqNh4sgom6Lg"
    "xyBFgWg6b4DMbWOE5BXG9flXv75hJDI2MSr9CQAjwEsAYsI1z65Z02mKyWSMwWCIfr9vJTIUR2ZknBWIwlBiZAtJZHo72/jo1ofo"
    "dDr2HbM2haTeEmsTRcieoN83QObk5Nit5S9ODv83SK+ndx3QvGsA4F2jl8rCdM8ENP/V3/ybvx2Nxjg6OsHh0TGGQ5MBtlY1Ehsj"
    "rje5afhHHL1giY24em33Cj755CaOj0/w+M8/oFwuo1qpSOYWMOHxZGIlNideYuNUUSzysGVe3uZDci3Fvvrpyye2IFSqFWxvbWBn"
    "R9rYCEPd2Ewb8YADNbB1DLD5EVmm0V5dAZRURV29umNSKpz3rQt1pAeaT7BFIyY5YbhinlQlr4oyDfgv8eWYqASyfvxFffsFMABP"
    "dP+UvIuKpDVJyQboK+eC85G0RkhsjJGN+ySXDNr/oijCHJfl4QunSNJbBGh8N7HJVOKvlCSB27a8r8WFt2OKZqdUeG1hewFjL+ot"
    "B5Cow9nvyPyyDKCx179CCe+nADI211KSi+z7FKPRGIWqJfYztDsxj6KRanc7Hfz6VwzIqESAGZ5kNi6Nia1fphMjkZkEAfGsamkw"
    "gvdMhQBYQrWUmoCQvd42bt36AJ1OB0kp6FPcL/sR4YDMAKen5oP0+PgYg4G3zXlxcvi/wrtykxv3u1TedkDwttM3q1wK7TMb+Z//"
    "7n/Q6TQVTLXZbKC3vYVebwuddhu1WhVpmtkAeVm+ReGSbDxa7tz9I+7df4BOp41mo+G8iIgZASrHIBqNOjY31rGxsY52ew2rKy1U"
    "qzUAJrvyaDz2IlTWb4xJmtPerVh6bpltfzDEg4eP8OTJPihVg3+hA4DB2iNRLKDcmJMkwe7uFRfHJtMaiUrQWmkar6iv7uHpswPD"
    "1DRfEJEHNIBd1PJjUYqlN1AGbMwqMYbL+ybvrfAc98gKAZSGtsEBqY6fU6h4qgjp3eVBUeghRK77wt17OHaB+QbW1dsE6BtjPJ4K"
    "ryg3brZXr9cKPIyKafQ40KTHmO/lJHsXU6CNlGg8Huco5IBzfpH0uW0wh7LEwG1x65FXW/Z9IdVT8AFS0NdibUg6xLPHrnBgWSk0"
    "W02sr69jpdWywRABKBNH5tmzAxFHJte27xLiqJDKWIlMp4PezjbqtTq4iig08uUfF6F0LXaPXPiDyYQFxBvagHhDAbaFPU9AYzpN"
    "oaGx0+thd++qk3jOokkDyGygzPFojMFggH6/j35/4OI08fL199/+FYAugFUYYFPGsrf6pyn8i1P/hH8/df9vPf1zJTRaZ45ZKaUw"
    "Hk9wdHyCl4dWYgONeq2GZrOBSqXiKPYvqdcFk23Etb2r+O0nt3B0fILH3xkbm0qlnOufgxrjFeUlNvSilkplVKtVVCsm4V/mVGGz"
    "JBR5UbOT8NhtuWxSKuzs9Gx273NJmyEQ+YNeEkEly6zE5scn0JkxHlZKYTwaAwq4YVMqkPGws1FyH+r+i0hIOcKxWfqpTpGUxs+r"
    "p9Op79yarHOAhwBSMOrCIubISrJiQMs9X7EBBZIDpZRJbllKULI5oZxXVNnY2VDeJJMEMyKxsY0pALVaLeqynRuHG4+vCxijxyIJ"
    "Tb5EmJIyXk75wHr82nC+LA2x26vZ8WCsuY7dRXFmWdhunCx2MPwrKpFzqqCvZdooOE/3TyWB11Kj7mLJDMnY92nMRsY04J4DfiT4"
    "Tc9Dt2skMhubG6iUbVLSmNoIgfom8jKEa0pMtcRTFKTiA0/STu/D1NrI9Ha2ceumlciQaimUBjFVU5ZlmNgUMGenZzg+PsHJyYmQ"
    "yITFqpwoLg2pnN4FQAO8OTrflfmYVX6yMUQBzepmE7VmBf/293/5tzqTgEYpY3A2mYxxeHyCw8MjZ/xqjIcbqJQr7iveSRdMA+6r"
    "JLHRdz/9WAIbY2NTPB8T4RU1QjqdIstSJKUSalWjiiolzCsLUsecM2KzXyL8S4lADZRJf7C1uY4rvW1MplOcn/U9MeGq4+q5f+xx"
    "s8msKuqHH54g0xrt9qoFiSZX1LVre7h6pYfRyCwU2hqr0lejAyycRtsB/7KdpXaKM14FzbkfwJhKHkCJlAkkmQm/hGMSDcSBFpf4"
    "uOsIeFL9gGylFEqJMsAmKTkbq0q54mxuSuWScwdP7ELsgilawta7HdSqFXcuC/rRuR8e0ShYt+3p1KW/yBfeQhw4GAYRcdsWQITe"
    "Qf+rCEOpEMCwh6MA5s8FEA6P+scjek2+FAE9P5D4nORbWWSVLOrN0K7QWmmht71tsl83GjZhaGKMfZn7tQ7qxoBMDiCw8wRkNjc3"
    "UGbGvgQWkgDEzJPOeFo8kBkOjS3e+Rm5X596GxmiOUe7OTadTjG1qqWbNz9Ap9N2nlXugyykEcaz0+Sy8zYyJ8enzsjYfMz6m+Hu"
    "m3rnAc1llp/DmN/KMZQAD2Doj8pf//4v/zZzgIa9ZGwok8kER0fHBtgMR9DQqNaqaDQaJsZHlllwwaoy5pwkCnu7V/DpJ7dweHyM"
    "R4+Mu3eZS2yCr3oNbdy9T89wcnKKwXCI6XiCTJscOsbGpooSt7GBZ/LCgwD0VUR9+WMEdqCMu7exsdn2STAtcWKNI/BEtIbqFGWu"
    "Pzk+wQ8/PoXOMqytrkDDe0Vd39vD1as9DEdj9AcDk0OKLS6cRn4/3NxGAU0+gB6vrN3iF5xl7QggE7bB5g9izIwJB8CY/yYVE42P"
    "j4sNTvRKksBEJd4jyibBjBoPWxsbE8HafKFevdJDq9lApVJ2X+mUGoIzgRw9dsxZlhnD9QgrjcVwyQ3DSgyiX7UBaKXpzRfWEZs6"
    "kuQEJEfKAhIa1neesfuOlpasFFzP2xH9FY4hT5e7TpFExmS/bjYJyCgMRyM8efLEJI0cjoJ7FgME7oyQZpJQtWu9ljY3N2306ER4"
    "LomPpsgHlGKD5Pde26ztzv3a2sicnJzi9OxMSEZyYIbROZ2mSNMU271t3PzwN2h32iglJbYeclDln4ssMylqBv0Bzs7OcHx0jJMT"
    "Y+xLefz4LZUwHkWA5l2zoVmmvJUM/4LlnRlLaXWzWXjy3/7V7/82c4kXGUNi/8Ie58BmODCqqEq1gkbDuHuT/YOThpARHHux93av"
    "4pOPb+Lo6BiPv/se5ZJhTvILU4nFzbh7nxpV1Gjk4thUKmXUajXUalWUSom0+WBjFAsKHyOXJjE6K5WKlNiwAH0A5GesJxvcpofm"
    "UgTos15RWjNgc30Pe7tXnH7aAzMxAD8ZHIxxIGIX31w0YviqMQlIcJv9+PiWXafEJZyzyAVbgC0lQZYDNMF9iqr3nO0QrMTGS2QM"
    "uKFYNgzcWGBDHhu/urGLlZUWA0BllBLD7IQnH00FRwnK2BA4CY27JjIHshUBDpIiQCPudRFg0Lm9HA6kOSq4hjPQcJpnARR7m2Ys"
    "d0XyEkZBUd0cPREZDVsXIqI0ACz79cYGms2mBzJWIrP/dB8jploSLUTATAhkuETGxZGJuV8Ha52wnUGwde9SJI4MARmhWkrzQCzY"
    "TimOTG8bH35oJTKlxEkuY38AXHqEwcACGeu1NHBu3zPuIbtNEUBD0YLf9fLOMPsFyjs/lhKTyKjw769//5f/TuvMvVySkUL8oHPj"
    "yRRHR8d4+fLQMGHyimr4ODaAWcRjL1M5ZmNjGVSO6TIiSBV1fHKC0WhkdMOZcfeu1+omqZsNYOYC3MFLTjTgVu+QJpkMzlxHAfqu"
    "7PQwndgAfcHkRpdzHTB0WBubE6OK0plGu72GJDEGp0oBN25cx+7uFUzGEyOxCdQ5JGHioEz0wcCMM7bVfuxyUiVQ9YdCZqL8VjAU"
    "CZhyX5yMttD2AAiyjAf0RFiOkwAp6kPZyMPW5Ztsa8jtmzyiKPrwv/r1dbRaTQN8qmSHQwH8SE3lQZeYCg5omOHo7MLeI8sp45GC"
    "g3ljAMAzeikJ4+eDVsR+ftWahVri7fHbdLFVsKABNrf56ZzVEwfFMo4MqZYSBmSe7u9jOAolMrK9RYHMr8n9ulw2H0D0EcRsTsKY"
    "MnnwoNh75oGMMXznXkunLiBeKuLIMGDLJDPTdGqAzE4Pt25+aFVLNveUCGWRuPAWUMq6X5sPqdMiG5kZYNZ/uPlrXpwc/nv8PFRO"
    "7yLNsfJzGYcrpVqzwh9LAWj+5q9+/+94QkdexCILzvzMdjw2EpuXh0dGlAuNmjUeLpfLJtEk/yrlX/HK2NgQsDk8OsGjx39GYhlU"
    "SAxXiYwnU6vbPXUSG2M8zCIPK2X0vcTgAaZVCBabiJt3whaoaqWCra1N7PS2MZkYiQ1rToyviN9R/ySx+fHHpwAUOp01JEmCyXiC"
    "JElw48Yedq8aic15v4/QvimcR3Gc9aUFouHCFgZS3EF5n91weF9yJAwo+edGtE2b6HzknzUHFZgxs4MXguF6pKCUMR4ul8oolRNr"
    "PFxhwfmMxObGtV3UalVUKsYdnP6MxMaqqxIPbDI+L9pm3ra5oOYXqXKiGgZoxwFNKKGJlkC+r4LD81etoho6co+XLbHay7ZYNBIp"
    "nVII48jUWYqCEZ78+BT7Fsjwl77ow2MWqOFAplyuMBATuF5b4OCBPD0FDMAov6RRioLJeIzhaGSMfc9kQDxuQB5TibnIvlmKKzs7"
    "+OijD9HtdrzKNVHyg5Lt60w7zz2zjp541VKBsS8vSgV3if0IAE0FXuX0LjHWd4nWsLwrtOsF/qKFA5rc39/8F3/1389aqKXExut/"
    "/ctpbGwOj45x+PLILiTGxqbpbGx0YVZqWOCwt3vFRB4+PjEpFZKEpVSQM0DSFi+xOXUB+kwcm8QYj1aMISj1TQuNsl/5eemMOc4X"
    "K26HUymXsW0lNhMbxyb2+Vf0RPkFyUguCNjoTKPTXoVKEkzGYyiwyMNjFnlYLJb5zmRGbQi3Tf+Vxwmi6wk0zPmu50xas4O0wNmH"
    "wrttSykVV0EJgMLoYniGAdAIG2YAzTEZniuqXEbV5orqbW9CKVipDcsjVa2gytIuGBsca3/Dkpou7uWUt5+hISelhAXWY2N318Se"
    "mjn9XUiConLbEFzGSnzo8+djMcICtBYcIyCz0mphZ4cHxPNeS09+fIL9p6FEJm4zJs/l3bMJyBivpYoDBC4FgfJqVf7850C3G77Z"
    "0dZryacoiNnIpJ4UDsgYram1kdnZ6eGjWzfR6XaQJCURmM/QSPmfrLRUa0wmJiDe2dk5To6PlwIyonAuwsqLk8P/AJOkkgOa8KF7"
    "G8vbTNus8jbTvTRYKagvSqnWrJDYjycMM4Dmr/7yv8tCt4+gKMbU+TGz44+NJ+TubSU2WqNaMcCmVC4j0xmy1NIoVDJ2UUgS7O1e"
    "sTY2J3j83Z9RKhlgQxS6nD7wzGIymXgbm+EQk8kUaZArqpSUpMqAjcfbDeXFxA7c0IJm3c/JeHgyneLs7NzRJZgzG5sl3i7Otjdl"
    "VFFHTBW1trYKpYBRDthYryjkn2BarKgP0jdJEXrwr7CTkcCDF3GtQ7Gic+I4ni6x4OeIjbyBDn3ZRmiHfZUqtrV1NDgwhbPZKpdK"
    "KJV9rqj19Q7SNHXX0jNVrVQMqKlUpB1OqYRyKQGsxGY6nQdoyDYC+Ztjq1BgPXn/5gGaxRDLIoBENiTbXbx6OP5ZNWcBtDxokfX8"
    "c8qBzMbmBhqNuo3sy1RLT5/mgAyAPGBhXebiyUB5G5mNDeeJKdcDQ5/YhpJk+HMkpdFaI5umGHOvpXOfNNLYquQlMuEYCMiYyL4G"
    "yJRKSXGqBBvLyhj7MhsZCohngYwKn4lXKC9ODv8PGEBTRzzj9tvMgN+V8jbP4bKgZenCAQ2BGgZofv/fpukMdO5W6eDFZS9yyGQn"
    "1sbm8PDIxbGpWa+oSqXs7BW4uJb3kKjESmxu4fDoGI8ef2+YUKUspQpB8SkVTjEajjBNbXbvsjcepqB32umIC54NBeTADUlsEsMF"
    "yqUytjY3RBwbrbPgToYIhwAEPHO3gOT45AQ//GiMh9trq1AqwWg8RqIUbtww2b3HoxHO+ybIm7gHgfTLzxNf0nNQCHOfOy/gYYCF"
    "/jhDBuFUB2Yk6FW+qv3K5dMibQQYnYWIhkAEt0vw/RppjQE3q6srGI99YD0CqgRsSBVVqVZQs+CmbG1xkiTBZDI1br5RQFMAZDj5"
    "MCqnqWVaiv8rJrWotgTwQfcXkM6wIwtULjZ+Xqa/xesbYWRMImOMvAciRcEwL82w/0j7rUB66QfG3K/XUS5XmATXP6scqABsXQj+"
    "A3senWpJAJm+d78ejRyQ0SGdM4BMt9M1Epmc7Y784ykKeByZ4cADmdA271XLi5PD/wt5QBOWt5khv83lbZq3eZKXWdKZZaU24hwB"
    "Gi6dcaDmr3//+/+myJ3UfWm4BTs+nwJ+M0bmbGxeHjIbG4pj45NgujqOwdsxKMoVZVRRjx//2Wf3Fl9Lvl8NK7E5PcXJMcWxSaG1"
    "zxVVrRhg4zyCaPGwQEtig1BiwxgpTH+VcskAm942JtMJzs54gL4IE7Hz67ZMokE2Nj/8+BRaaxGgTymVU0WZlBSmDyGloX4ZZvGL"
    "lzznGBaXmAXgQnOGQPSyKzjDlWCGXcsqzfpG50f59zXNlzxgdnISRPggj61W03mVhVIjpZQ3LK6UUa16GxvyoppOpzg9O48AmgJ1"
    "jZYjAKwNTZrKL3hRd8G1ig+/gBHxOxeTCPH6s0oo8cgfL+5XlvyRWdeurHgg492vkyBFwci3o0O1UdwuJowj0+m28atf3cDG5rqL"
    "IOzXIb+NgQUhVbP3ksAFgEiKAkrgeOYkI5x+RjpoLZqmU6TT1KYouGlsZJh9jDQ29u8cGfvyFAUnxwbIpMyOS3EkM2N9F+th8WXQ"
    "Gnhxevj38CqnMErwa/tq/5mXnxLIzAIf88DJooCF9zW3lGrNSgl5MJMAwO72zlqz2fjX1UolUtW8uPyly1/hKXFf32wLyDg29EVV"
    "rVat8bAJ0JfPdSTVPqSKOj4+de7eLo5Nwco8mRrjYcruPZ2Q8XCCatWoopQygdM0Baqid7xwtVd+wJB3rlwqY5Oye6dTExEYkafR"
    "LZR2nI7BMamF1jg6OfUB+tZWAaUwHo2glFVFWYkN2djk7pBbrxiQ4YCGLfwx+2BHjVNj+a85r6ZjYxJfs74NrtLLz4MkmK7MjYW6"
    "J2YS4hrlZlICJ6XQajadhEVzepR8xggsk7TGqKPK1kbsBFnKxfPzwIwcgY8UXFDPjST6xIgr8mAocg2fG3HG7xY1MUsiEwM5IcXz"
    "Vl/5ltutMsa+TiJDQMYmjfyRbGQoaWRUoiGlMgLI2K2CQqfTxo1fhaolyPdS+WdJvKuRrZN0wORJ8tmv+0K1NBqFXksh/dxryQKZ"
    "mx+i223njJCdJIiBKwFkTs5wfOyTRqYRg/QiNfOsu6YKHpzpdIrzwfn/czY8/xrGKLgKaT+jg+1FS1H9y2L6PyV4eFvKLBDyKhKX"
    "RQDO3OcjVDmJvy//43/8/w+evDgZjcYfdTrttWq14l6wkMkCiK6kccNP5Umzu5OxMR4mGxsAVhVVR7lcQuq8ovxLY1kHFIyV/q5V"
    "RR3ZJJjEhLgaI/wkIInN8ckpBsMRppOJjzxcq6FWrVrpjo96PJPnBHNBAEjBqKMqlQq2N62NzYTFsQlXcieZsf840OElDsZ4+NRk"
    "984BG6+KGg1tSgWyhwo4jBJzqtzcIAaEMOO+8wWekAWbr3DecgBXR8CQrCGYrZAmwfet+DlImpzEy9LdajXd81Y4PntMJcobFluj"
    "4ulkimfPX2A8mdBwZ4CZ+PtoAE3G6oWwg8AMP3/ZpWDG2eEYmMljGHl+WcoVa4KADE8aSQlIjUTmSRDZV7owO0A+B8gAJtfSjRvX"
    "sbG5bo19/T3nmaVDMBM+80JVziQyPkUBt5HxkX0dzZx+7SjGdMqBTJiigH8w+A8gBWVtZIy3FAcygwGLIxO9D+xFmwFiRY3g5k6n"
    "KYbD4cHZ4Pz/fHby4v+GlM5wddOrAJpF67wHI8uVi0pfLvoX63/pEno5ge0rAOrg6MVn//ztvb87ePLidDgafdRtr61VqpXgcrvH"
    "RJvsoDifK0rBKsYBGFXUIZfYaI2qC9BXMjYuWsOxPc83vcRm7wp++/Etk92bxbGhOoIMC66mPEDfcIipVUW57N6VqotjI9ULka9q"
    "+kKjMTtG6sXV5bKxsaEAfSaOjQ6a8MzdyycgQAIAp4r6/ocnyLIMa4Eq6vr1Pexe2cFobGxsdGjorfiu/+EZgryU0xZUhtPbw+Gw"
    "oK8YwHWV3W7uer6ohl/INK+sbiGgEftAs9m0WZQ9TeGfbIdJbCpljCdTPN0/wGAwDEfqi579dpZKPA5NgDZzJYQIl1EIWBaAMSDa"
    "p+RzOnelyl08q317mQW1UrXU9HFkrPv106dPJRC16mABGkPgEgEyHQIyG+vC2Nc/K1LS4kEzAw72j2zolF1TsiyW/dq7X3N1vpDE"
    "sPGkqfVa6vVw69aH6HY6zhXduV8TsGFrEUX2dUDm6BjHPI6MZv0WFP9xU3yV4lfavtPUAJnzQf9/f3J88D/1x8M/A1iBt53hEYIv"
    "AmbCa2cPI75/kXLZL97bVmIAIwQeWcH+RYEL72eRYzMLSWioFH5MHxy9/Oxfvr3/d8+evDg1Epu1tWqlIr4qixYrzoSjoMdd6I+T"
    "u/eLl4fmJdQZqrWqC1Nv8u5o6pl9pVimmyTY272KT4MAfTyOjRss63c8nuCY4tgMR5hMuVeUSamQOK8o2GigRkIEtvBRocXJjU/y"
    "f5TLFWs8vI3pNMX5ed8BPCcNYpKMqMSL+tIaR8cn+P6HH5GlJvKwAqSNzZUdjGx8C2cj5HGh+yEAI3xOLAgaOMgyR0ROrOgtdujT"
    "TwWBWhoj9UvTZqfQLfocfvPJjAEowIMf16f/t9nM29BIWwjJtPy0mN+T8QRPnh7g7KwfIQpRNUxYSiWvcqLpiI3i1cCMQnzigNn9"
    "wvUp5l8Hx/m5sGWGcIq6MFUNkDESmY3A/XpoJDJPjLGvoMexXIkcTUqC2UBmk4BMBMgu8pfLlq3DgHh9HxAvSBrp6BRAxuxRHBln"
    "7EtxZJSynksycJ9KSCKTYTwiIHOKo2MLZEL368tg7fTO2S0DMv/hyfHB/9gfD76DATItyOjA1DtniIv2Om+fl5Cfveqo38ay7PzN"
    "AxuzwMpFwUwRDTH6FhlDYVGrm82Yyik8lmv04xsf3P7o5m9u//aTm7utlZYDKwByBpJFzM0ze7bSWWaeBHWazQZ621vY2dlGt9NB"
    "vV5DmqZGTTSd+oUt+MoheqZpis/v/AH37j9Ap7OGZqPBCfTd0yFLd6PRwGWd32UAACAASURBVOZGFxsb6+h02mivraJWqwEwHluT"
    "ySQXp4ESIFK8Evoj6ZKnNfgDMBwO8eDhd9h/duDnlEtqAqYaTDQnAqVSCXu7V3Dt2i5KSYJMayRKodFs4Py8j6++vo/9/Wd5dQdj"
    "WPyrN7ErF2f2HIwQqCVX0YWCzYn6Hjzk5oYALGeajFEphqrCCMQc6IbSrW63g9PTMwmg7PWJe5791PIhaa3x4uUhPr/zR3z3/RPB"
    "MP218+egXC5jMpnmAEV8+pYFNNHXFxIcqfDRifYl6ZH2KTO7FfcioESb+W61mlhf76LZsukJ7HM2HA5xcPAcp6en7nnKuWDbg5we"
    "8wwwY34GZHq9bdTrNQ90i7aBlMbPkweAirg5jNfSdDrFeDzBaDRy8WQGg2HUtb8IyGTaRPbd29t1QR09oI5LmClFAUmD+v1z9PsD"
    "szaiYA0Ontdo4a9c8A5Qk2maYjQaHwzHw78/OHv5/8LYydRhQEwVPm9TqGYqYqgRKnL7s64vAjKvAmhiTP9d+APmg5PwWLhdpO6i"
    "tMw7Nu/3zGNqdbMZApdCmxrki/74Vx/c/ujD39z+7ae3dldaTceMeJllYMaZhTtW0BkZcfZ6m+j1ttHttFGr1ZCmmU13MJUMJ1zU"
    "dIY0zfD5XQts2mtoNBtSGkGrSyBBaDbq2NxYx9bmBjqdNtbWVlGv1wEA4/EY4/FERvC0gxNgJtOOJj5+CWrMCjIcDvHw8XfY3z/g"
    "E0CU5hizmOcAJJDh9PVre1BKIdMZyD7h/LyPr7++h/1nB0gp7kSI7tyOlFoUgREuzfCO9J5aEwiQty/pLwI0UeNm4WbBALUmylkI"
    "gHDelEKnvYazs/PoMxqXNNHTaZ6rFy8OceeLf8Sj735AyCCKAE3IEEqlMtJ0Wnid7/cixQNgCHoWATT+ejkUabgq+uHdxkhWfNcD"
    "mVarhVKZgAwwGBggc3JyGqwnBfTY36FqiaS4nU7bAJlazQNcBliINnrDQpuZENDQ1jgtpJhMpnYdMG7YBsgM2JoU0i0NfqccyOzu"
    "ung6oW0Mv1daSyBjgvH10e/3HZBxcx15vmcCbi3PEKDhtyJLU4zGo4PhZPT3B6c5IFOBDJ7HV5VZjCugonAbq6OC/ZB3/RIBDf8r"
    "Aiqh5GVRSQwXNRZdE56b9/uV6hCgoVIEZOYDmxsf3P7o1m9u/+6TW7utlkx4KVQw9BJFGLJokBEUFgI22z2TcqDb7aBeq2E6TQ2w"
    "SVO/aAjJiGc3WZriMyuxabfX0Gp6iY0G2AJCvwEohVazga3NDWxurKPT7WBtdQXVag2A0VmPRmOW9dYzYdd/sIhoOynkEs5BDaAx"
    "HI7w8NF3eLr/LDcnHMBwJh39ONZAqZRg9+oVXL+262Lu0Fz2BwMjsXl2MDMyqGtd5e+NADOKXRsUcsensYdteJK5lMvOYbDm8fHx"
    "+8VBjZO2BPMEQACaAJ+5MUheIGf3+YtD3P3iT3j4+Pv8vQ1+y2P+K79s3b/z85SvHxv77FVaMsB8LR25JtaLrJ+nbUFAAwiJTKvV"
    "sm7R5rkZDAd4tn/AgEzkftO7HRwk2p2qCRbIbBuJDAEVf185aLFEC1ADV8dJZui7RxuvJSORGWM8GmM44hKZlNFU7Lk0LZDIeBCT"
    "BzIAkKaZi2EzC8jwOQ/LTAmqzt8+uqVpOsV4PD4YjkcxicwsIEPbkBGhYH8WswzrEImzeNZFAc0i9LxNf8tIX4rAzU8phZn3u/Aa"
    "xbJtXwqw+eRXH9z+6OYHRhVlgU0O0Ng3o0AK6t8Afo1dhGRmZpLYbKHX27ISm7rR5Y6MKzZ/5p36xImnzaL02Z0vrSqqjUa97hc1"
    "scr7BSVJEjQtsNnYWEenvYbV1RVUq1UAcMDGZMGNLWp8tG5ty9HmXIkBDKwq6unTfT9HodTBbotUf9RuqVTC3t5VXL+266QhiVJo"
    "tlro9wf4+pt72N9nwMaKtcVXfhSQKp94j90j3oQfZ65yHozFpDPBA+KaYc+KP0bzF/vaNqXdXsP5eT94RiVxITPwaocQ0OQHlVOP"
    "aL9PbRcDmtgkBW1HgKUsiwAa/szkepF7/PkULamwyTwlSqHZamK920VrpYlyqexipgyHIzx7ZoBMpjNHSIweDlwYYeDD63RJIlN3"
    "RDppjACqKjKHEdDDBmdsZLxEZjQaYdAfYDAcivso33sJasjpwACZqzZhJGZIZEz/UrXUnwtk+NyLWZzzbOWKBqZpivF4dBlAJjyO"
    "gmNFTDmsB9Yn/cU0DRctIT0x2n7qv2WAyizQMuvcrHGH5+bN1zLnF76GAxoqIZp9ZWCzstJyPYN9nXPma075L6s8EwleSF/JLJTW"
    "xqa3vYVuN1BF2aBl4UJM+1ob3fXnd/+Ab+59i3bb2NiEgCuUiFC/mxvr2NxYR7vTxkqrhWq1Cq21W+xS61WQV7/E3kmSRlDyTFvP"
    "boeDIR48+g77VmIzC9ho1qodruizVCoxiU1igE2i0FppYdAf4qtv7uGpBTa+DS3mQCCVAFCFX8O8fmxBjS26MXUTHw8HRwRaPNP1"
    "FRxNrh8zQ0WAJgTORWrTFy8PceeLP+HRo++hc/fT00nELApotL8YvAbHlL6NoD/wl1IFZ2LHA+wevZ69P5YA3w+9F7Fq9v1stQyQ"
    "aTWNakkZO7nhcISDAyuRCdsPVYzuOP10O46WTreNnV6PSWRQ+H5wsCeLf24J7IQSGWMjY+xkhsNhTt3t77dUh5EtzZWdHSORsaol"
    "DlwcsIGXGhogwyUyxkZmMplgkSJUyYi/f0XF5Jj6yYBMqP4I64L1G4KZebagi5ZZzLzo+Ov6m6cuou0sYBOqlWa1P2uc4bFZv5e5"
    "9qLXmJscATXuXLC9ALD50BgPf3prl6t1gDijyKxqJvxyKjQs5i+mVQn1trewvb0pjIdHo7FQRZm6dlF0TZgvJyGxadT9JBSodgjY"
    "bKx3sbHRxdraGlZWWqhVa6Ckb6Px2IYyV/KVD4fFVGRcTcXVUAAwsKqomcBmTqHmSuUSrjnj4RI0NEpJYiU2fXz99X083X9mXdZt"
    "JVIvhUNhwAH265aMic11Zhw8EnRYQnBB/XpA6KbKzQfdQg7l+DHejWL0dDprLnozB10huE6SfJR2rTVevjzCnS/+EQ8ff180zRFA"
    "Q79VocqJgwY2EMtcZfsFr4avlFv/6TgDMkE/8kBAkxgDIyyoYoBMw0pkWiiXyg5gDAd5Y9+wj/Dd5M+AP2X+7XY7FsiQhDUPDDhQ"
    "8XMWmTwlnzFv7Dtmxr5DF94hNr/hOKbTKXSm0dvZxrW9Xe+xxNZA+cFkaKQUBTFj32VASWgbN9cYGGTsuzSQsT1EmQ7fxo7FGGu4"
    "zQ8tD17eJKAp+lv2+tjYZ52LAZYMecByGSqlcCy4hHOLXjOvjjgvbvIbATYRVRQ3IDVqc//c5l72WOMRFYGR2Gxie3sL690O6vUG"
    "0nRqogLbxYCv33zhJ6+oz+58iXv3jI1Ns9kwNHAJUgBqNIBGvYaN9S7W17tot9ewurJijYdNErjxeCyNb4OFW9qNaHGOOuOeUgNm"
    "YwNtruFAw8+P/1qVk+frlBITnPD6tV0kKoGGtukBJLBJ0xRQeU+0qFTNMRAGaGy/sxbkEFxkbMzuX1GdHQ/bytHmGVqn014I0Ehj"
    "Z2/T4yQ0CwCaOBAhCc1koTq5sV14mY6+pqC5mSdtiDZlTyqVoNVqortuJDJlG9VXKQPED56RREZHblgewFOf/p319TrdDnZ626g3"
    "6h6oOEBQIKEJpCFmbGwsti9yv55MJk4iMxgMvEQmmEUhObIfItPUAJmdnR52d68iYca+iXue8vRkmfYSmf4A5xcEMv4WsY+E6Fvi"
    "i/NamgyXMfY1TccZD9/Gjs1i1nxfDike4T4Gbuj6i5YixnrRv1hbsyQv/FhMwhLO1yKGvaHL/DwaZ/1e5twibV+4/+hNfpPApki3"
    "64xGeYeKIvbG69A1vDSbDez0trDT20an00GtVjURLEcjpFExv/lH23bT6dQZDzsbG0RyTNmqWpugf/V6DRvr69jcXEen3TYSm5qx"
    "sQndvcMveAdq7MLtFvdg6SC1FEASm8d4un8gr6X6YIw5d1vkwi6Mh0smYFdSMkyq3x84d+9QOpYHDh7UxNbQULUTtsWZS9G1NHUe"
    "KOlgqkz/XkqkxXg7nTZOT8/i6i6aEKWCr2mTjsMAmiPc/XJBQOMI9kBEKYVyqYxJDtBoVleMNj9PsTnxo3dtFKpXcjXyrc0EWLYJ"
    "pWBsZNbXsdJqolQqu/gow+HQ2MicngaBHWWDoYo13FL/3U4bvZ1t1OsEZJhExj3nMSmNJDyUUJEn5GQyyXktxVVL+XkyH0ReIrO3"
    "SzYyys2HiV2Vp4skMiObtiR0vxbPehEZKrK/QEnTFKOxdb/+6YFMyvaLwAy5gof5CBfhRcuUIqZ72X8xIBc7vgio0YgDmdhfODYs"
    "sL/MuaL5W7bO3P5n3ujXC2yMjc3vPpVeUaENDS008gM7JoGAq0dfO9yottVqOhubTreNOhkPD4dCYkMti0U0M19rn9/9A765/wCd"
    "9ioajYb/wrL0cKZLWrNmo+EkNp3OGlZXV63rqAE248kEWZoKMT4tikJCE+EzZoHX4HYHw+EID8gryubAoqbdwp/EbGzEZ7YDNnu7"
    "V3H9+p7R9QNIbEJHYzx8H/v7B85dPVQh+nsB1yZ4Lzmgouj2uraclxiP0My4kP8apkmSTDfH6PwZAEbldHp65q4t+vrlYFDD358X"
    "L41R8KPvfojWA4AYOBGAplzO2ULEpSGStmI1bAEhavmVXbN/8vR4OlqtJrrdjlctWcY9GA69REbrXANhm/6Zlu8gvQZdcr+u1yDA"
    "SwhgIoCmaPzmFcownXKJzBijEVctcfdr//aw1xaA9VrKMvR629jdu5qLI8NTFXja4ECUUy2dn6M/GEhVpM71Gr1h/Ow8CR6p1MbL"
    "u18TITEGExIZOzePUcfsPLjUpRT8cUCDgNbLADRFTPkif/MMdotAySJzVARmYrSHx4rGuuh1i/y+SJ1F6AIwB9BQed0Sm49v/eb2"
    "b627t1kXtAcJ9BvBAs5AhCBKKbENz8s4Nh1UqxVMplPjlTRN3aJHTIszXQ3z8psAfQ/R7ayh0Wi4xYnT6vdNgw0usbFxbBoujo35"
    "GjQ2PhFAAwu07Oe2u3t84Q/GOhgM8eDhYzx9um/cs2lBF6Ju/yRIOMN3rI3N3lXcuGaADSCBzVdfM68oBdGXgpeqCdUam1MHYoP7"
    "yKU7eeDj51lrJtGCnyP/5S5VD/w5arc9oJlVQrBG9Dx/cYi7X/4JjwsATSh9M22xdmEBDZPQxOpI/mDnIMKgtbg0X2dRFZWW/wTt"
    "2tYUjLHveldKZJSxkXkWATL5duRxKY3xz4uLI1Ov+3spVEtsPoLjcsz+SdeA/ViZOq8lqVoaIU0jcWQiO+S15CUyiZ1vD1yE2tI+"
    "i9xGhhv7EoBSkmT/jBfeND69/r2PlQsa+1IXMYYju4+fC5lu7C9FnCEDEsyU2V8ooaFymdIZPoZl/2ap02bNxbI2MrP+cEn7i/y+"
    "yDWzrl9of6mb/dpVUQRsmg3xFQ5oAXBcR+yL2mKgHKARnWhviEpxbLY3N9HpGlUSeUWlaQZuy2IooNVCg2xs7tz9o4tj07QB+viC"
    "LRYfS3iz0cDmpgnQ17VxbCjysPkqNF5Z0a9UkATJq0MkIwjsDXSGwXCEBw8f2wB9GmTLENqUuI1mxLp5Nv+USxbY3LiGUqkEaG1d"
    "2Jvo9/v46ut7ePrswGSeDgAAw2N+TNozFblmwUUbdgQwABTeWaP+yWTb8OkaiqU0Jg7Nydm5n9UIv4jZehH98yQ0MVVNyGDL5VLU"
    "3df9yx8qVq+4RAZh6xQBGnHbo/37HeG1ZN2vaZ5NZF8PZPLqtli7wXPOtosAGZLIztvykmXZDCAzLPA6E9QC2nzgZDozXks2Ird4"
    "xpikiOaO+jcSmVEUyNDNcKTH1pSCwp+f2DqYTm1AvLcLyKSRY/mFwQOaMqOVRyIu4jEXLUWMuGhsRb+Lxh0CE5qHGKgrAkOz6JoF"
    "AmLHZl1/0d/L1rno/sVu/Jvxirq522o23WVOAgIAFpRwRkcX0Rf4LEDDi0up0NvG+noH9Tqpokwep1Di4mxcrPSGUirc//ahdfeu"
    "yzcw+KEBJCpBq2UD9NnIw6srK6jWqtA2qdx4PPbAKgA3TmoRYwKWThmZ2MSxefToO+wfPIeXgEnAERY78znpRrlcNsDm+jUkibJj"
    "MjFGBlZi85TFsSmyk8q5ZDPJXPhFG7p78zYpYWjo5k6DEKrBENBYG5rwlnm+7j2xuEEw3c0XL45wlyIFw7Egdy9CdVMMUIReTjGv"
    "n3wJ+Uy+sClwe+F3AmeWvJ18t+betJo2IN4KC4gHayNzcIDTkzBFQQBqWOP8d/gMmxQFW6jXAiDDAQI9wyp4VhFIbJiUgtTHk8nY"
    "fUDMtJFhAM/PiXnvdaaxc6VnvJaSUi4GEwLaAOQi+/b7fW8jo8WswD9N/O7E77W4U5ZGIZ3RF44jQ53GmE9IUBGzvCiQifXBAU0V"
    "PrUCSWkuE8zExjLrb54dCx9vGrkmnJewftjPZQOC2FhnnZt3/aLXLEPXrGOvdvPfnLt3UzACksb43/55jzNC+YXspS6mMaUUms0m"
    "ruxsOVUUuXsPhyOnCqJiwIKME+MjDz9Eu72KZqPOUFjAoKy0oGSlG5sbXQNs2mtYWVlBrVaF1rCL7gRplromvM0IYwJcPcWu867f"
    "5reCyVbsjIcjN40v/oY3BF+bDBSUy2Xs7V7Bjet7LI5NYuPYDPAvX9/D06fG3TumrtF0LxjQ5Aac0rNI3jfDrzyTEOAoYAwG0CRu"
    "aJyWTnsNp0HqAwkoOF35YgLrEaBhgIGYYACgY6VcrgQ2NMHzEmViKn/tjEs5Y1cQj3OuUniO3o8uqZbKZSTWFoSMfcn92tPA37ng"
    "eGSfA5md3jZqNteSVBcyaYu9/6H0JS+J888OeS25YHgDG9l3OERaEEdGzitF9tXYIffrpOSCA4LTG9yAWIqCQdRGhq1lbFxsxZpd"
    "XBuejrdcIhMCmqJB0nFlaa3AAxqS0rwuQMPHNQtgzJPA8LGnwfmiduaBhWWZ/6L7i/y+SJ1F+ptHX+F1l3Lz35QqaqUV7Ud84Stl"
    "YoY4uxbtrymqQ59hZNy407PApttBvVZHlvlcUS5GjFNHSfXPdDr1STDbxsYGdJVbGfMMmwL0bax30W63sepUUeTuPUGWpYIBcINg"
    "YZAMD2TgKaQfALSMYxMgxNhXpruBgbQDAEpJgr29q7hxfc+I3AHrFdVyNjYEbJwqj+ZMMDYtGBcHM0WAAgrifmQiX5ZnfEnC6lOb"
    "ADrtNk5OT6NxZiRT9nPDn6UXLw5xx3o5SVDE689iRKFRcIyR5ukKAU0xQPE3jzP4WMMhAFGgyL4dm6Kg5O79aDgScWTC/vOqJv8O"
    "eEmify/J/doDmRDQ5iUuRYCGS2qM11IaVS0NBgMhhRWzJ14ZljSyZ9yvfa6l0OhXzin3WjLu1yaybzpNoZGPw5QHwE5ENLeEz1qa"
    "Zm+zRKZIMsMHTn86OEcSGkp+SVKaywY0MaZbZNtC2xCszAM0YRtFvy8CSmJjWGR/UXCyyDUXpXke/dHtpaLZN2k87E4EqghY5pVX"
    "O0lVAV9McwQHwGZjvWsjD6cYDIZuEcwxY8Dt8wB97fYaGvW6ABYitxCTetTrJgnm5uY6up02VlZXUKtyYONVUY452LFoGiPbD9Z7"
    "qXbTcWATSjHYxAgJjZDewEQeFjY2MGCH4tj8y1ff4MnTfesJosV8+MmDYFahlIbOeckJBKAjVVvQmIyZw+judNo4OTkNwJObntwz"
    "opQSc/7i5SHufvlPEUCjXRuw8EAO0rdXLpcxHucBja/vh5LnbQX2KeC3nY8rAEJBl8Rkm40Gujayb7ksjX09kJF0cJpDaSF1RP1p"
    "+3D6pJH1QLrC7J4YQOFjiO37e6eF+7UEMhRHRoM+ROQw8jYyO72e9VoiUMcAlaPX9x8a+wrVEiviPdOu56ULBzPGa2npXEvUQIwZ"
    "8W3sWMiEi4DMLKlMZtsimki1pIK2Yc9V7HhoTJcJaGLjm2e0G45zHqiZZwczDxSE22XAwDwgscyxZX4vQ1/ROGduL1s8B+DNAJtP"
    "P7m522q2AGjxMgOAUon8IqfKttEQBHF2Iwh2wGbb5orqoFarYTqdmlxRVu8tliH2W2sTIdQlwVxbde6mwhYAfmEjwUKzQTY2697G"
    "ploFYGxshqMxsjSjAQnG5NRNAWhQdm0Q6ip7fmiNhylAn/Mw4vOBQEJjCBeXGQZdwrW9XaOKKpk1JkmM2uL87Bz//NU3+PHJU/uV"
    "CtcO0eMAFQNPToLCAA2p0dzUa+0iTce+dMO5BkyE2ZOT09xxXvKgBg7sCEDDaQE9Yx5UavGQeHoMoBnH+/aXeygScGDNLsyPmv0b"
    "DE/LfwCrWlrvdtB0AfGMFMIY+z7HyelpSIBowtOTVyeBPXdSIoMALM+WxvhxBNfZ3rOcRGbo1EvFSSPlXBrD/Ay9Xg97u1ecjUw+"
    "GB7RZH6QaoniyJyfn+dVS+L+8Bsbu4MLFFvPeC2ZgHjPzw7fZiATsx+hopB3xwarA3uMJDQkpeFGwRctRfMQk8CEKqNZgCY2Tzo4"
    "F/aPyP6sY7Fzs/YX+X2RehfdX2aMhdvXAmiovKkAfU2bUsF8PXvGKypEGgo9pGghprYcwRbY9LZNEsxOu416PZ/dO1T1mH4NsDDA"
    "5kvhFZXLAA1flew+TBLMdRN52KZUMLmizBfgZDJ1qhw+JtceRR2m8ecnQdi0DAZDK7E5AIELOwvm30jySQ9+pHSHJDaUKyrTNglm"
    "s4mz83P8y1ff5GxsSH0RSmdCKQ0soIBSSGzfRuWU5eaB9jjNVAjQ5MGMf2Jy4Ij1LwPr0cfkjBJ5EOcCGlYlB0KCY2HvnNnnH7S8"
    "aqnZajEgowSQcQHxFBsp79fhFu2Zc8CkQxsZDlZUFCz4DlVk30lErI3M1AatlECGvJZiNj5azKEMiOcDSxpVtiqkkceRGQyGViLj"
    "k0bGgK1SEtAsYm9lRy3mdDqdmhQFk9HbDGSKJBa8TQUPVrihLyBBkEKxhGaREptoPg9FwIODlWnBeIokUPP+MGe76LlZ+7Hfix6b"
    "9fui+8uMMbbNHXutgIbK6wc2f3H709DGxjLdeVIYfo5LLkiU7Lgr4Jjxjo1jEwKbySQIS84YX6YzZJkJ3nXniz/i/rcP0W1THBs+"
    "DXALNrkuK6VQr9exvt4xNjZrq2i1WqixAH0uu3fsXWVMJcfgLH1aZ+aJshIOmVJBe+CllANi5qcEOEJlZdtPeEoFMh62c3ne7+Or"
    "r+5h/8C4exvG4hmt+ComBkDDYuCTVEHeCBqec4AzXympWO92jNSBfeHL6xjQkncJGsBLZkNz0RICmplsTeevELYvjEhxr2mXmDks"
    "kGk2fIqCctndW65aylxkXw2INjXrP5DI2C0x8tBGhprxqhquvgnohrwXXFKjNQJjXx8QjwMZOXV5KRKplnq9bexeJRuZ0D5G+Ui/"
    "lrxcQLwwsi+7R0RvOCZF7+HsOy+ffWhn7DsYvzUSmRiAKZJm8L79EPMu2SV7HbVDT3gIaLg0p6gswlBnqcSKAE04L7M8lGJ0LMLA"
    "Fz03r5+ia4quu0gfF6V9ke3Mc28E0FB5ExIbo4qSXlEAhH2I+Q35pWkP0kKX/2K3V1qGziMPd7s+pYIxHrZxZCANdjN3zOj379z9"
    "A+5/+8hEHmaJOwkQCG8tS5cANjZXVK1mkmCO7aJOUgrTlv8CzK+XEXWFlskxh0PpFRUCmJj6KQQfBAZKBcCm1WqhP/DGwxR52DTp"
    "1YehXZQDGZYZKnY3Q/uXvJTFtLPOVE6x66TkKP9cLJLLKVbMVzYA6DigifI2Hf+laaP9cu824XNsLmhSZN9WEEdmNMTBs9DYV7Ja"
    "+c5Qv6TKdAcBROLIMKlMKJ2ZB2ZiQIaSRlLmawqI5yQyYsr4b7NPqiUy9jUOBaZTrxYmGhP3bGdp3muJS2Rit4665t8vNA/zpDPu"
    "PdZGivQTJY1cFMjMM/zl/fNCdjPcgykENBnyKic+Xl7CMfG/UDrEx0VgJQbEZqmUYu2/CvOeBwAWAS4XPTar3UVpuqxxL3ruzQIa"
    "Kq87pcKtD1kSTGJADNC4hdrx+uCLs6Bxv6h65trMZfcOUirY/vyCT9xHu0X587t/wL1vH6K9topGo27E204qYfa5WzJgjIc3Nro5"
    "YAPAhm+fItMyCSb1Tj+dhMOdloa1xKgAn9372TPu7s0NN4OtMvF24ObbA6ZSqYS93SsmpYLN7k3A5twaDz/dP0CWplLdFACpmLu+"
    "eBgCWymxb7ni+joBGgm+ELRN57jhsNZg2bZ/gHzHgucmOKLZv+VyGaPROAI8+ZPIx4AAVZjzYe+5Z1uZODJdZyMTBsST2a+5xDL+"
    "VvhnmocHABRLUcDiyDgQY+kKgE3ufYwAH/oYmE4nzntoOByiPxhgOPDZrx3JfKbZeKapkabu7PR8ZF8HYEJ6vYRQZ3o5IDOnONBf"
    "+Oz4OeASmbckRUEMyMwy/A1pCAsBlSq8bUzZXs/bVvCgpwYfWG/eOGgMsaB1/Nw8O5lZAG3eXC8y34hctyzoWKTOIu0UnZtH92Vt"
    "lzn20wAaKq8d2NxkkYcZGOHAoNAdOEIWBzPylELLAhuysRESm5TiyIRieS/BSdMUn939A+5bG5tWs8GYNJc8cN2/Qr1hsntvrK+j"
    "01nD2qoxPAaU+Xq1STAZpnGLOjfWpF8+dk0glrdlOBxaVdSBY/COyQdzQ+J515/4CjXGw3tkY6NYgL5mE+fnfXz1zT3sP3sOHcSx"
    "id0z6aUkA/HROKg4N3Wtsd7t4Pjk1H39h+DL9UfMNaDh5ctDfP7Fn/Do0feFTGme4acBNCPEwAs/psNTouSlKJzWZrPpvJZKuQKd"
    "+wAAIABJREFU1v1aoQDI2LGL5yXaJZNA2mtMQLxtNJzxuw+hIIGK35Fgxs6Y8vv08M7Kfj2ZeNWSJS2YM5LIkI2MATLkfu37VJJe"
    "231mgYxPGrkAkCFyZi4xOWQanFUuIN47AGRiYIa3E/YbTgR5L1XZ+AiocMmJQj6wHqmbeH/hH5fAFIGaZYx6F5nfZRn2PLCw6O+L"
    "1Ftmf9axi2wvciy3/5MCGiqvPwmmdPfWgHPt5YbErlLQsfkRUavwOpoCkDWwvbUpJTZZihEL0CfF3kwdZRfcz+/+Efdtdu+mzRXF"
    "KXMMxzIbBaDRaAh379XVVfd1bMTyE2tjg7zEiIMWdyzCyBiTGwwHePDwO+xbiQ2fGz9lHmRwJhleSxKba1YVBQ3nFeWSYD4rjjwc"
    "64/fF/Hbjo1o6lq37bCOtJmRkije37KAJqZaKJXKGI1HOdaWeyajzevInvlBxuzr1kam5CQyxvjb2ch4XZGrTP3lnwF/jIPrTptL"
    "ZLjtEwc0cmQC5LBdCQBJIlOcokCzydHsH+3us40jQ0kjd0MbGds5A61ELwcyMWNfMfGXvJqS+/U7AmSKwEyMhrAQ/Ty+TANe+gJI"
    "IELX8tQHil1XRAOdm865pkgKAyw2t4vOdbhddH9RsDLvmmX2Zx27yPYix2btA3hLAA2VN+UV1Wo13WIc4420QAoGxvT7SsHadbCv"
    "Zw3BBHlKhZyNDbMRcczTqnjo93SaWhubhxbY1CEkNfYfbjehlBLu3t1ux7qKmySYk8kUo7G18ckyZyuT51nFTIzUUsSYeRwbPlfi"
    "hjGVjZvLAPwAxnj42p7N7s28olqtFgaDoZHY7D9DmmUIa9O8zwI0sXOd9pqV0ChxPFYvBqReHh7hzhd/wsNH36NoveZqvxjoKZVK"
    "RuUU1mPdxQGNPOCnl7Jfd7GyYiL7hhKZk5OTQNqXb0dK8PwRrf1FbRdHpuaeQaMylVmlw/eHZiY+HuWkltNp3muJq3ND8BIFMlpj"
    "p7eN3d0rUIn3WhL0MQkNoK379dTa5sTjyMi5C0AbPZALF7IA0+8ikClSzxT1Lwfut2QMXGdj5oBmAm9wy5NTkhRHz6Gn6Dyfg3Ae"
    "FmHiFzkXnl8EoIS/XweImXXsMrZF+8sCmByYAS79m+Jyypvwivrk45suCWZuWQ2+ooVImkloQiYIwMVBsRWx0myi1zPGw51uG/Va"
    "LQ9sLKPj0YfJjmWaTnHn7h9FriijLqGqEpAopUyU3qYBNltbm1jvdrC2tuqMh10SzOnUMTXZTsB2xflANWWLU0U9fZZfyxUz1w3U"
    "VOE5wGb33r3qUioABuxQgL6vvr6Pp/vPoi7a/n4J8qNgBwDaa6s44oCGqaPCcjFAwwzR2b+8GEAzEnVo4+cmHFH+kFLkfh0kjUy8"
    "15JJGpmxNvP32h3jz5j9HaqW6tbTjgMC6Q2UBwyzAE2W6UC1JL2W0nQazEf++SUgQzYywtg3kA5xwAWExr5GIhONI6PDmWPjsqQs"
    "rM02tTFNp+8qkLmIVMYP3RQyCCZ1Ewc0Ch7QkNopYXVI3cQlMEVeSLOkL3xOFmHqRfuLzPki+xcFLcv2NevYMttFzy1yfplz7vdb"
    "CWiovE5g8/GvPrj90Ye/uf3pxx/utlZaAdNBjqEJ41T2WzQaSC94XfKK8qooC2zGYxcGXdgtaPOVmOnMGULescbDJqVC3X3x0qJO"
    "PxPr7p0kCVZaLWxtbWDLJsGkXFEmncPYZhenlAqMUQrGJu1K/DExYwBMEswHD+MpFcBodBKaCKCki0yAPht5mLyiSglaTYo8fA9P"
    "95/l6Kc55yoEdywo7bVVHB2fFNrohLZWoTHyy5dHuPPln/Dw0Z+jo0D+yZJFGwA3Go0ME+R1VHE1DjoEkGk1bYoCw8AHwxGeOyCj"
    "Rb0QxLp/5wCZnd62CxAJxQxpw63KGwKHtikAhB1ZLLLvcDgyQEbMhfZ17TiERCYSR0bclYBeHhCvMNcS7z337PO3kfcRlhDgAum7"
    "BWSmkCAmBmbC/ucVBW8QzCU0pHIiQDOFl9JQPapL45jlVh2Om9NbNFfzjsXOF51bFsgsC1wuAljeJHi5yP5Sv99qQEPltQKbGx8I"
    "VZQ7IWwo4BbvJAA27nq3qEICAGrDMu4mMx4mG5ss88DGtAXozACaNEuFSipN05kSG6JVKRMILEkSlEqUBHMdGxs2QN/qCmrVKrTW"
    "7kuY3KUlcLGjCw1ALQORBsSe8Q1ZHJuY3Yifk9C+Qo4BSqFMKRWu7yEplQBtkmAa42ETefjp/jM3f7y+VBtKgAMwCU20fyBCupec"
    "aOO2ffeLP+Fh1G17DpixbZTLJQxHIw69Cq939WCiJDebDWsjI3MtDQdDHDx/jtOTMwZcYmBG2k/xa/jZbqeD3g6plkKVTQhc5ESp"
    "yD63USkGMt5riUMF8VzCgiGmWtrbu2oi++ZAlYAbUMrbyMyVyETuG7+v3lvJjTx6G7n68R2TyEwjx4oMf0M65j3QBErILqbG5iEG"
    "aAis8Po0tlgQv1lzESuzGGhsnovaLepzUUATHpv1e1bfFwUtizxT847N2l/m3ELH3glAQ+V1S2w+vvmb259ar6gQkOQBje8yF5VW"
    "ewAA6JwUwrl794yNzfp6F426SYI5tHFssixzf9yFmn/N3vnij05iY2xsaOm3RqxJglKSuGSdANBo1I1X1IZJqUBeUVprF5iMSzz8"
    "eCyAyRigcePM/Jcymw/jDjzCw4eP8YQBG+UnQkppSArC5omDEvKKunH9moljk2WAMnZD5+fk7u0jD1NgQv6k5ABNew3HVkLDQSw3"
    "ZC0CNdDFcWh4P4VeQnauvJfTgkWxXEsrs9yvwUCZfx7zoKZgXxkgs7PTc0EcPQj170HoUp97xVT+nmvtvZZGo1HURiY3VxG6TcJY"
    "m6Jg76pJjupAFqOFAyt4GxmSyBgbGaPSWqQU2c84bXNkGujMOyyRWdReZlYp4jkEaLjbNp8HDa9KIppiDHCWS/UiZR7IWWa+i/Yv"
    "AlguAlouA7DMAyYXAS7zrl2kfvT4OwVoqLxuG5tbH/7F7U8//nC32Wy6hTD8IhU9BVMdc/2lCoK/WlXUlZ1tazzctaqoqUmCaWPJ"
    "eFdqv5gTk8yyDHfu/hHf3H+Aztoq6qSKsionktJIzxEDbDY31rG1uYFut4OVlZaR2AAuVxTZIQhJDJfUhH+eI+buytCqolzkYUaP"
    "k9I4QKPc/CQJ+7q2yxqlVLh2bRcKygIYCHfvg4MXxqjY2nJQe06YZWnstNeEyqnIiDi8l3QuBDRinm3FKKBhx0sRQBM+nARURYqC"
    "iPu1z7UkiSgCM/mtqUmRfXlAPGngG9kXUhg2Cv7oaRlHZjgcuii73EaGy1L4DaNxTIWx71WjWgppYWTQM0CqJZICeYkMl+7lb1es"
    "MFO5hco7ZOwbgphQzbSIvcwis6KC/TDtAU84SfSHHkq8hPM0D8hEeUDBtTGgUHR8HghZFrQsClIuA8DMO7bo/kV+L3MsevydBDRU"
    "XrcqygAbo4pywCCyeoXxWEJGL4gL61upz8pKy8ex6bRRq1bdwjudspQGWlQFYOK8pDa79zf3vjUB+poNlJLEp09gjJ3Ah4IBVFub"
    "G9jcWEe74wP0cRsbE001D2CIEepMS2Po2IRawn2uqGfC7serLuC+4gWADKRcAFAqJdi9egXX9nahlDKBBJVx9x4Ohvj63rc4OHgu"
    "3L3JyJjuC3k50XwWDYHHteH2NBzQRN3JY4BGO/YMADMlNEbKElMtJYGx74mNRO2mVLThQY0EMdGAeDs9YyMDmnsm9TMoJgpm/PDz"
    "hr/Oa2kywZh5LRkgM3AG6r4oQSvtpzOBTEwaY2pK9+siGxm6r9FbES8hdoyUdxTIzJLMUJshHfNK0UzR8QTS2JfPCY0plA7xsgwt"
    "RfTMarPoPswDJpcFXJYFLIs8M8ucD/cv4/es47PuZ/TcOw1oqLx2YHPzL27/7pNbu6urK4KZcSbhj9mKOkyUaK7n3j1UmbdpjIc3"
    "sb21hXZ7DfV6DWma5QL0uVXbgovM9kfA5v63D9HttGHAmHeh5fRRn8YexcaxsaqoVquFarUC4xU1shKbac4Ik7ZZlnkxfMCw+bVU"
    "+oOBTIIp7DEY40zY7wDUaDuOJFHYu2rj2KgEGhqlJMHKyopx9/76noljo7VVGdIcIOK2raOgJidxs7SQl1MRoAltLWKG1DFAY+6w"
    "z7W00mqhVC4hsakghsMRnj07sEkjM9Z2rEQkNFzyBmsjwyQyeYmklHxIEMMlMxLMhMa+Jk0Bz34d8bTzt4Kol0Bm76qTOkrQm5cO"
    "ZVlqJUHG/ZoDGVLJgdUJhTuvUtI0xWhksl+/o0BmGtS5TBVT7BzNQxJs+Xj5+IpoiPU5D0wtyuyXASQXATKzji2znXfsIvsX+V10"
    "7CLHZ54/fd7/eQAaKq89QN+tD27/Z59+tNtqNQvBAT8Wk9AQCV71Ic8T4242Guhtb6LX28L6ehf1Wh1pOnU2NtK+ReZfMu7exsbm"
    "228fmpw9zQZUonKPApc6JYlyAfrIeLi10kK1UkGWaYzGI288zNoJv/S1hqcv7FDLuekPBnj0+M8uQF+iEskkA2mNnaRg/KbfEjMe"
    "LgXGw/2BD9CnM+2++TrtNRydnIgv/JhNVLgfAprHj3/IPTmLgBnAqJzGFtA4IGNVSy0GZJQFMgfPDoKAeBKwhBxAAkoJHjqdNrbJ"
    "aykACHGwEEpBzI9QSuOBzPyAeALMCNqLjH291IhLjzhFUrXUzwEZR/lrADTvOJCZZfw7D0jwsgyQCY+rYD8sMRqWATGLtrsImLnI"
    "uVnHLrKdd2zR/Xnn5l3/KsfnnZt7zc8O0FB5rcDm1x/e/vjWB7d/9+lHu6srTdBXaKwUghoyjDQXmWs5YUq5r8dWq4md3jbzijI2"
    "NpSAz4GZzPdBAIPsFe5Sdu9OG41mww9MBV5bjGk1Gj5X1NrqqgU2VWidYTw29g88CWaoGuBqqdxMajjboCzLAG3cvR89/jOeHTwH"
    "NGM0DtAkAfMJ5s8yR6UUyuUyrl3bxa+u70EliQM2lATzayuxSdMM7fYajo6Oc/ZR4X0LwQgZER8eHuPOlwzQsDmQz4Ksz4+b5JQj"
    "py4zEhkW2TexNjLPwuzXtqcQELBvztDmivbJ/bpWr9kq0tCXq5OkhIZ3EEpqFgMyfD5CUEo0plbN2Yu5XxOYsaRwuV3eRiaf/boY"
    "0MixLFsMkHnrk0YuAmRCyQzv43UAmaJzl9HWondzUcCxDKBZpL1ltkX7lwFWFgEvyxxb5Nwi5xe67vR5H8ClCVffzvI6gc2nv/7w"
    "9se3Prz9u9/e2l1pNYvVFIIpLnLv8gsqqaJ2etvobW+i02mjWq2ZrLvDESYTa39gF3fhEWWfg3RqkmDeJ68om5GcGKZzvYVngkop"
    "1OsmV9Q6S4JZrVYBABNr2JlGbHy8ezdJDZj0yh7nUiWqNxz5XFFk3OqYasSOxjFENlf0VymXcG1v17t7QyNRCVotk1Lhq6/voT8Y"
    "4MWLwyigCe8lG56j4+XhEe5++U+zs21zZh2e0kClUka5XGY2MmVn8zQcDr1qiUlkeH0CNbJLBmTsVkGZ7Nc726jX6oVSDrFlz0XM"
    "VoZAMIHnYvfrSEA8unfazy+lB9nZ6UXcryV9HMxw1ZL3WhpgOp1E59yPRxahNgxvdkFxEpnx8OcCZOYFyysqlwlmljm+bH2gmKEv"
    "CmTm7b/Kdt6xWfvLnFv22Kzj884tc83S1/8iAA2V1wtsblqJza3dZlPmXeILNTAf0GjqKFhpuY2NiWOzie1tI7Gp1WpmQR0bVZBY"
    "LbUxhtQ6M1uYr+fP7/zBSWyazUaxsbNpBIDJ7r25Yd2922s2V1QNWgOTyRgjmyuKwAWPnSMbtHPjO3D2KXx+BoMhHj58bLyizODl"
    "Z5cFH5wp2stseHt/TalUwvVru7hxY8/lilKJQqvZwr37D/DP//K1bz8Cmmguw7unYAHNF3/Co+9+iNSiumLwuXOdThvb21tWtaSg"
    "VGK9lg5cQDzehpg7ux/OcyiZce7XVrVUBGZoDuPzETf2zTIjkZlY77jh0HgsDYZDY3clhq/FnNA7IrNf77qkkdyGh0sQiY4sy5y3"
    "lDP2tRKZIhA5q3hAa+hTvtNcse/dwXD0TgOZRdyyFwEzQOFMzTz3usBM0fl5oCB2X+YBnIts5x2btX8Zvy96fNHzi17zynUJzAC/"
    "EEBD5fUDG5kEE8gDGlrco+oT6oCdDPepvWazgZ3eFra3t7De7aDRaLjFnXuMkLGwtka7FDMmzazE5v5DdLsG2AhGZwtXZ6lEodmo"
    "Y2Pd2Nj4JJgG2JDR53SaGhA1S+1kDzlAYifBS5fIxmaIRy5An68ovKJYO6RG86oqv18ul3H92q7J7p0Y4+Hvv3+Cr+99K2iim1O0"
    "EirflYsU/DgGaLSAIPnTdtAbGxvo9bZzqiXvWWWuiwEZuR8HMiSRCT2WuFqJAwYHIGi8AYgxNGVOIsNTFJD7tfQeygMxGpeII2O9"
    "lkgNCrtNhMqLJDIsRUF/gLPzcwwGg1zW7cULA2ta3uvwQXCqpcnoXbaRmWf8e5E4Lm9aCrMs/5o3x+H2VUHLskDlVQBM0bGLHF/0"
    "/EWvvbT6HMwAvzBAQ+V1q6I+uvlBLvIwYN8Qy+CdUTA8gwTAbBbot3JAhntW0e+WzRW1s7ONjfV1NBp1pGmas7FxkpOM8viY31ma"
    "4rM7f8C9+w/Q6ayBpEwKPtCcZm7PVIzxcNd5Ra2umlxRgA/QR8BGCKYEYNKCFj6hBkh5UGTcvR+bXFHazxMxPjfBdNxOJt9PLEMv"
    "JSXs7V3B9b1d/Ph0H998862r7h4ALpkoUHUp2EjBX/4THj32gMYBtTnvKAc07fYanj9/4Yx93QwVgJrQZgn8OBS63TZ2eiSRoTFw"
    "dRIHNXQsPlY2K9A6w3SauuzXxmspNPaV446Br2k6hc6MjYzLteToCm13PN0CyFiJDGW/XkylGx+bAC4FADydphiN33kbmUVUTBcN"
    "SndZgGYZKcwsCUzR8csCKvPAyCwQclmAZdb9uUzAcpHrX2s7IZgBfqGAhsqbyu69stLyJ0h9wBbPgB+bTpmaaZ73DdnY+AB9JqVC"
    "mqYYjkYuQJ6gwdYnScg0TfHZ51/i3v0HThVFQMrFmFHK9WloVWg2697du9vB2uoqajWTUkHkirLMlpiqeKJDIAIGaDKjLiMj4sFg"
    "iAcPH2P/2YGTJrj5sTSRqzcx6XAuaS5KpRJKpRKGw2FELSQlFqFKju7hy5eHuPvFP+HRd9/7egjbkkUHg09sZnEuqaJzAgwwIBMF"
    "NPCqpXq95sbv7GAU2LzMltKE05FpExJgOp1gNJpgPB7ZmC7DqNdSMOIIkPESGan6itEVSVFwfo7+YIDJZGLndFm+K+Br1J6Gys8M"
    "yMxTMRWBmeDlKCyvAlxix19FCjPr9zIg5V0EK4tec5Frf4r2XIkBGSq/aEBD5bW7e9/0NjYAX3w5k4kQoORCXwRo3PWJwkrLBOjb"
    "IXdvC2wMsPBxccJoxhpGtZQGEptGo+EkNALQsL7JO2drcx2blASz1XLAZjyeyOzisYlm0hQN2MzjDMwwUGOAzQiPHn/n3L25NCUJ"
    "AEjO5ZsQFBuLnwe4V5EzVhOxWPlrwCQ0AtAUlxijj1+jxT4dIu8xh2WYZCsX2dcBgpjkJZSAgG39NaYLI5GRxr4+RQGB1RB8iREy"
    "IBMa+0r7GMWeeVNIrRULiBdKrxYrIeAsBjQ/E6+lIiAzRV7FFHoyXYQpXQagCc/N/0rwpQhYzNtftt4iv5c5tsi5Rc6/6vU/dbuF"
    "ZRaQofIe0LDyJiQ2n35y0+aKQoTRRDpnInjOEGOAhtchr6gQ2HBVFG+HSzngJDZf4Jt7D7C2tupyRbn+83okJBbYbFp373anjdXV"
    "FdSqNlfUZIzxaIw0zYRUQYzVDYtUax7EuABsBMC0dkkweXbvMEgfwi0fB5tHrUOmLNUfOcNppfDyhY0UXABoQmlM0drM+xX7fC6C"
    "34AxKN7pbZuUF2LcBV5LAjzw3/C0KThwy4EMBcOTuZZUnmY2vDiQiYEoecxIZIw6q9837tehbQ6P3jy/MOCiAQ5L6d2i6XASmZ+H"
    "jUxRGoO3GczMu6aItlkAY9Fzv2SQ8rrbXqosAmDC8h7QRMrrltjc+tACm1aTidvjJa7uYF/AbpcYsGebSimstJrYsaqoTqeDWq1K"
    "bqbScNMyOWrfx7FJ8Q+ff4mv791Hp72GRr3B+gumhxg/fK6oDWdj47N7j8YG2Jg4NpzBS97ApRCaVDJCUuGlTM4r6tkBoC0dgeqJ"
    "Axvk5lACPFIphUapXNJDEppYcsqwXTFPwfxFpTIBkPESGlOn22mjZ+PIEI0mVk+BbQwHMEAU5ACwWd5lHBkCMk4yEo4kAsSmVs3p"
    "gUwCiiVUHNcmSBrZH+C8TzYyaU6KshigkZWcelfLKzRgUxT8LCUyYS6mmCdTGP13Uca2qJRlmXOx6y4KLC6z3iLnFjn/qte/LW2/"
    "crkIaJlV3gOaGeV1p1T46OZvbv/205u7rWZLgBrO2gvjr8xbzEmyYKUMJqXClgjQR+7eWZo5QEOqJ5PKgAGbLMNnn9tcUUF2bz4Z"
    "oWrD2NhsYHNzHe32GlZaLVSrVWgYm4jJeGqBTaD2cQP1vYTndWA4DG0C9D20NjaCaTKphZRGmX9CuyYzr5SSIQkAAJxr+MuXR/j8"
    "i38UgCYGZJxELjhGHUpQwNRMVhpl//cSmXotL43ikplCQBM/VhwQr+8SpXK7HXmLtJvHPJBhqqWI9IhaINUSGfv2+wMM+gNMpuS1"
    "FKrE5r0D7CkkxFLAGqe/DCBTJJW5DMkMlWUkNEXnFu1/USnNIm2+Cni56LXLlLcalMTKZQOVRct7QLNAeRM2NjGvKEBKaLynk2Tu"
    "CsT4GEGWoYUSHsoV1ettC3fvkU2pkFlDXG5X4oiFcbP97PMvTXbv9ioa9brj1BzU8Emi+DmbG+siQF/dRqmdTCYsjg31ZLiQY+yM"
    "aXIpSk5aY+keDoZ4+NgE6KN5E/PB7GFo/hztOUDj63CgqRKFly8MoHn4+Hu27ITGvfyH5KoxOxmxtXR1uEQGESDjbE/8VoKGiFTG"
    "0lEU2deoeCZCSiTApdspAjIcOMXsdiCATL8/cMa+Jvu1n0Aal5jRqA0NSeEQLVy1NJ2+BzJsG9K+bLkMacyssgyAeZXrlr12mfIe"
    "mLzm8h7QLFHelFdUa6XlP+m1Z6q0gIcGwq4RxqClZw8nz5RWs4nezhau9Laxvt5FrWZSKgyGQ0zGExeIz9VkoAraGw9/c/8BOmur"
    "aDTqCKUA1CXVTxSlVPBJMNdWV6y7N5zxcGrTIQAepLgx2n+Mx5Q/Ju1s/PXGK+qRjzzMbWtI2RCooMRc2uuLDI1fvDzEnbsW0Li6"
    "jlJBs58Mf7AQyNhtp9tGr+ezXwuwIiQeRTYy/n7w54AHxBtbFeBwOEQ/cL/OqcAC2l2uJZuiwATES5iUKJAG2bmnmEkj2yd3v46V"
    "pQBN9A3zV/xCVEuzgEzMk+l1MNvL5C8Xoe91jOmdAiXvGiB51fIe0FygvG5gEwvQBxQDGVeZnSv08gnaozg2ve0tdDpt1GpVF3l1"
    "alMaEFPiPRupBpCmU/wDSWzWVk2uKG6rQoPlticKaNokmJubG+h22lhhNjYO2DgPGuoQ4BKakHnJVAre9sZ4RQ3w4KEJ0OeADdHD"
    "59BPpgeHLFs5v1YpJVROIbMPJTa5foqADHz2a7KRIdASSmE8eJkNYGifVEsURyaeNDKQHgXzbu67zH5dchKZmNSI3SNmIyMlMvk4"
    "MqQCpf1wAumcsIeZIZlJ0ynG4/EvDcikQd+zxvI6yrI85nXS8s6AkV8aELms8h7QvEJ508CmUDIDzu91DrwIBsNq8aZMSoUtbG1t"
    "oNM2wGY69XFswhE6BmMBw2Q6xefk7t32AfpC4MAlR9Tv1uaGS6mwstJCrVZzwGY8Hlt3c+nh5AGNV2V4hiv/KKaNi2Pz6LGT2ISq"
    "JDG7TCKWs2Wyx16+OLSA5geEEoxg183dXCCzY92vOVAJbU8cf/fj93MQ3itYIJPNATKMbgZmQhuZTGfY6fWw64x9Z9jy2AE7icwo"
    "zLU0FeOPF2Vb0cG+vGkaeUAjgczw7w/ODn9JQCZUK80CMq/K7F8HL3kPQN6Xpcp7QHMJ5bWrom795vbvIhKbWUUGm4uBGgYQmJqm"
    "2Wxge2sT21smCWatXkOWehsbRppj8FrDxYjhSTB5gD4BaEhY46QH3sZmg2xshCpq7LyyPNNlTD2QnABeWuVBjc1nZYFN30Ye3t9/"
    "DsADGy6Zce1w6UwgdeJeTkKSQWTKnbhkBl4iY+LIKJ8wlIMDux/eZw8S+fhpG6Yo8HFkvBu05BsexHiAZlIUcIlMwu6rpy9MU2DU"
    "WjZppPVaIm8ph5NegW9xm5hQDPYLtZF500DmnSvvwcfPt7wHNJdY3haJDZ2LHQuNjMMYL8Rimw2fBHN9vYN6rW5tD8ZMFQXA0kCB"
    "8Mj2JE1T3Ln7R9z/9hG6HS6xQZQpA0CSKDTq0sZmxRoP88jDGQX6s/3zyXVcnQANiDYLbKxXFBk+D4dDPHz0Z+MVVWCXxOcupNsD"
    "mh+YJMPPY8guioFMzd+fhOUzEioj02eSJCiXS6jVaqhVqxhPJhiPxpimKbLM8C3vtTRxkhEPZKTRrcRdUrXEUxTs7e5aiQwcbaF9"
    "DAGaWIqCQb+Pie2Xq5NepThbbvcPfs6RfV8FyCwMYkKGX7CuvfbyHni8L8uW94DmNZQ3IbH57Se3dldmSGyKAA1trTAiJ6EJvZua"
    "lCtq2wToazTqMgkm4FMUWNsVXtIsc6qobqdtbWzgl1QmuVHuhJfYcGDDIw9PJhMJbMKJYoAGwTh95GFvbzNgAfrMONgdcDY3XLpk"
    "Cgc0AiA4NQibj3lARin4WDIeLCSJQqVSRr2xrqWvAAAeM0lEQVRWQ6vVxOpKC+21VVQqZZz3Bzg779vgcybD9Wg0cuo6D2TySSP5"
    "fea7GtrcWxsQjyQyfA64uotvtbY2MszYN4zs68Upl1j0L9b9+pWAzHvQ8L78nMp7QPMay0+piooBGn6OCzIk0wfoC9+pd5QN0Nfb"
    "xpUrPWysd9Go1zG1kYfHk4lT5fAV06lodCSlQr1OxAQqMcIS5jcF6Nvc3ECHqaKUUjY54sRJWyzlHkwIZh3Y1IQGxPbawXBkvKKe"
    "msjD3DYntKEBgBcvDnH3yz8FRsEMyARqFW7sG2aVpjEbAFNBo1HH2moLnXYb3c4a2muraLdN1GatgfN+H6en5zg5PcPR8QlevDzC"
    "y5dHOD45wflZH/1BXwCZvMSowGspy5xExngtccleKKUyWxEQjwMZil9j7ylhmaWkMxxcRsp71dJ7IPO+vC/Ae0DzRsqbAjbNVtM3"
    "xgANSWPC3rkAwmx1bstdwZMkwcpKC1d2ei4JpjMeHg5NEDTHIaWbLo88/NmdL/HNvQeWOTccvUKtI6QAynhFba5jc3Md3Y5Jgll1"
    "EpsxMx6Gs3tBAGgI+GQMxDj1CttqndnIwyZXVDgPDtgohRc89QEDh2YWvKSn0zG5lvJxZAClElQqZTQadXTaq9hY79r0ER2sra1i"
    "pdVErVZFpVxBkhgV32RiXOyPjk5w8OIl9vcP8HT/APvPnuPFi0McHh3h7OzcSWS0/CcYdyxFQWgjI6VGNL2k1nIB8QjIpDIhqpfi"
    "yGdtbqEpjDz974HMeyDzvrwvvLwHNG+wvJE4Np8aVRRXLy3KPKLB9AQzN9IDAjY+8nAb1WoNWRamVGD6mUCllaYp/uGzL1zk4Ra5"
    "exfYqtCWvKK2NjdM5OGVlnH3BpzEJk3TKIpzGby5ZKZovE5iM8SDh9/hydN9k6QzULu8eHmEOyywnoMLtslOt4Nebwv1Wp0BGCOB"
    "abWaWO+2ja3S1gbWuyapZ6NeQ6VSQalUQsKNg+08ZJnJi3V6cubAzI9PnuGHJ0/xww9PsP/sOUbjMZtzN7pg3wfE6+1sY29vl7lf"
    "mxtH9EqbGUvDeOwC4p2fn3tjX/uscClM6Hbtjbv5A4j80x0BNO+BzHsg8768L7HyHtD8BOWNGA9/+pEANt64Fc52JvSEykki6JjZ"
    "AUlLiMkC8CkVtrfQ7XacjQ15RVFdAlbh33RqJDakimo1Pc2GB8p9kmi0mg2sb3Sxue5zRVWrVegsw3gyxXgyNgayHKwA1nDZjzUE"
    "PU5ywVVUWYb+YIgHDx9jf/8Zu2MKL18e4vO7pHIqBjLlcgnttVX0tjexe7WH3vam9QKro1KpIEkSoYqRUhHj9QStMZ5M0e/3cXxy"
    "isPDYzx//gJPnj7Dg4ff4cGj79DvD5j6zf/DDb5JIpNlMo4MB09OPhbYyJCxL+VaOjs/nxkQj26ere7nuQjQ+Cri1ijApup4D2QK"
    "xhOOBcB7IPO+/LLKe0DzE5bXD2w+uP27337kjIeNZ5KX2BRFG5a/TU1PHXNhhpeeUIC+Kzvb0ezeMc8qHx8GSNOps7HpdttGFcXs"
    "a2zXgGP0pv8GC9DH49gANqWCS4Jpxu88nuzgchIaulLD2QVlTKpDXlEUoO/l4RE+v/uPePjIRArudDvobW+h2Wqit7WB69euYm/3"
    "CnZ6m1hdaaFSruQAG3l/aWaMzKVAWgOT6RT9/gAnJ6c4PDrGi5eHODh4jkePv8e9+w9xcnrOqPf/hNIZ6bVkVEt0TxMlAQ3NN6CZ"
    "11JgIxMJiJcvMUCTBzNcEuOfO/VLDoj3Hsi8L+/LEuU9oHkLyusENp/++sPbH936wBgPrzSdxEN+xWvBYKSERkp3pG2O8iIfBSTq"
    "P7V3ZsttnOkZfgFLJBYu4AKAJCRZshZqszOVqrGcSuyxcwm5juEF5CA5zQVMJUfJ0Zw540kqd5BK5SBeZMu2RJmLRMmSSWEjCRBb"
    "rzn4978bACkRNCV9bxXcENjs/ruhUT/zflvSmu49jfHxcTnd2w8C0wkKzUqjMAzh+b6siprmDfqSVnWW6R4wxyaTSbPck/lZ5KaZ"
    "Y8PKvVUfG5/ndcjSZnGBZnIHd3LUmowX34dVRT3B/Qc/4dt7DzA3N4urVy5hdiaHc6VFlJaKGB8bkyXY9hPHBMJEZD0CPB3HQavd"
    "QaPZxN5eA7VaHeVKDVtPn2HDAhnx63GODOvsyxri6UMjVaJzNE8GQHz5tZXsG6eBISfNiVIL1/7e8b9SBDIEMiTSUURAc4o0arC5"
    "ef3qyge3b5Sy2YwJMFaoKR5o2KeJpNlFxmzsph6K2UwahUKehVZmWLm3ABs1JygKUmEQIATge2ykgij3jvSx0cJRRo4NnxWVn59j"
    "oaiJCZk83Os5vPOxaNAH6M/ZuHXYLo4OgGEY4qDVBhAim8mIG8K+hD7jEuQdtj5X95yBgOu4aLXbaDQOsLu7h2ptF+VKFU+ePsP6"
    "5haazQNzzX1AxvPZvV5YKOL8uVIfkFFrU3k6fUDmUI6Mdp3iuOIjvq5YGOJQQyBDIEMivYwIaE6hRgs2y5EGfYNCUOJz8aA0K5HY"
    "gyqZFCEK0zkBeB8bmTycQyo1boSiVEREBxsV8tEdm9z0FOtjAxOeEsbTkp0/nU4jPz+L+bk5TOfYdG+RY9NzHPQcF4HvG9fBzg3T"
    "mbHWpu6HFbqS9wjGuvQuyepaYYGUKld3XQ+tVluFlmp1vChzkNnYQvPgwIAxM7Sktub06xLOnDmjvhcrsVlfyWCQkXcoomijPHXF"
    "dkJwP6ChZF8CGRLpVURAc4p1UqGoTCYtQ0fxgAH+0IZ0RvTwk+geq0JBZlgLgObY5DEzMy2ne3d5KCgR83s6OPi+Lx2bXG4KmXTa"
    "6qgrft98qMqRCnMzmJ6KjlRwHFeGwtSlm6BiX4sZhhIApvYV90flG8V8BYIJhSPj8hyZJkv2rdXqKJer2OIg02geIOZ5Zn43sKqW"
    "SiXWhG96kkFkz4HrekbfHqG46deddoeV4iM0rkHzqqwLipCWvEb9FtjnJpAhkCGRjkMENK+BRpo8fOnays1ly7EBYl0JdWY7Wdcs"
    "K9ZDGCJcJVJV0nykQj4/zx2bFIIwgMPBxj6/eC8SiD3fx5ciFDUzjWwmEwGqyI1KAKmUaNDH+tgIsGE9XVxV7q1dbxzE6GsyXRrl"
    "OiTEPdKcEPWL8tawczsuWu0Oms0D6ciUKzVsPfnZAJmoOWKuxR4aWczP48byZZw9ewbtdhetdgdt3mSv23XguKzTs+/7cB0X3V4P"
    "7XY7AjJsqeZ9HZ47Yy5Wvwe6y8NCkAQyfa7HvhYABDIk0iAR0LxGOrEGfSIfxPr3VDSsE///WzoRYC4NoCBHvQ+NxGKxTadTKBTm"
    "sVgs8qooM3mY7wzA6h/D3QXf9/HVN/ew+WjLzLEBDLjRz6v3sdGTh+0hmDZYRSu/+ldJyes2nBlzvyDUHJlGU+bIVKq8ammTg0xo"
    "g4y4FnVU3/MRhCGKRVa1tLhYwCd//VssFPLo9nrodHifmHYHrRYbk9BqsbLvRqOJZvMArVYbrXaLTb+OSfaVieQxfyfsfcRfjtiE"
    "YP65BBm390WlSSBjXY99LQAIZEikw4iA5jXUSc2KymqQYOaIWCeOSQxW+5kujZ0MnOUjFYrFPGZnckil0jz80ZPhE1XiLRyRUMFB"
    "EMrp3jIUZS9QrJ9fdDKZlGAzNzcrRyqcPXuWVxaxOUg2WMmKLgjYkf+R1x4nATM+D+u0Wm00mwfY29tHtb6LspYj0zg46HsO6QRx"
    "oJPTrznIfPbxHbx36QJbRyhmG7F8mHani4ODFmr1PdlRuFypolaro9k80KZfR4Hl0ECjOVE20IRQyb4dp0sgQyBDIh27CGheY51E"
    "5+EPbl/nVVGAeEzJ55bIGdESXwHTrVEMYAONcHyAZCIh+9gsLBQwx/vYiJEKag6RGWbR5fuB0aBPBxsFQXp4DEa599zcLOs8nM0a"
    "QzAdh/exsWFlCMzoMBIEIXqOg4ODltVHRpRfmzky+qFD9QaAFVoqLWFxIY9PP/4IlznIiCZ8Sf6dhPzce/sN7OyU8ez5Np7+/BxP"
    "nj7Hzk6ZdxRWX2pcYrgCGutn+l8G4dbFQBF33ipdl0Am5nrsawFAIEMivYwIaN4AnZxjk4EONQos2J+kM5NMyhwb+aAPVX8XHWo4"
    "Zcj9hWMjZkWxUBTvPOz7EZABXxEzgdSsqPWNx8YQTBO+eLgsqcJC6XQKc7MzmJ2dQW56CtlsFmPjY0AYwnFduK4nRx/wk0JAGhKI"
    "Kc9W4wEOWi3s7zdR391DtVpHpVrTyq9b6jjaFWmngACZkIeWSqUlLC0W8LuP7+C9i+chuwonVYM8ATOdThf13V1s75Tx9OfnWFt/"
    "hI3NJ2i12ywMp626nwMTlxcjvnqd4+xKJwotEciQSCcpApo3SCfh2Ny+tWyGogADMvolCrPdQrkVAyLt3xPvJ7LZiGPDH5DwPFFu"
    "DRmCEQ6MOIcfBPjyq7tsCObUJFLplISm6PoUUKRS4xJsdMcGYCXVokrIfBapqq8QQBgwCGpZIFPmnX03Hmkgo26iuk/af8yqpSUs"
    "LhTx6cd38N6l80Yuk4CqZCKBIAzR7fSwu7ePcqWKX37ZwfrGYzz4aQONRny11GBJfB24D7+TlOxLIEMi/SoioHkDNVqwubpy/dqV"
    "lfdvLZey2SwPKWn/PgtgACJAA5hQE/YBGnGcBICJbBYLCwUsLgjHxpwVpR/XTjwWnYcl2PDp3lGoAYwwGBjYzM7OYHYmZ3QeBhLw"
    "PA89HoqyRxQ4roNWq4NGo4H67j6qvPz68ZOfsSH6yADWIy2a/BsBmcUiy5G5eEE6TBrRQHQWZhO491Gu1BjIbD7Gg4cbaDSaMV/n"
    "8YrNWnIq3V6XQIZAhkQ6cRHQvMEaJdjcfPeqVRUVE6qIBRrIfQcCjaZkUo1UKBbjHRuz47Bya2L72ExPIZ1O9XeQwPqyIBRgk0N+"
    "fg4zuRympialY+O4LlzHhe8H3JExG+KVK1U83nqG9c3HaDZtkLHDSuyN5/varKUSlhYL+PTjj/DepfNyP9lMULhkQQzISEemH8gc"
    "xnU5nHzfp2RfAhkS6VcXAc1boFE7NiwUxaqiAGkaDIQUsZ+I9cQl1WoGBAunJJMqx2ahYHQe1kcqGMfRwlt9G/TJ8FkoHz1BECIM"
    "Wal4ArzzcH6OjVSYnsLEBCv3TiaT+GV7B5VKjYMMHxr5VA2NtBN74xwaj8+ZErOWFheK+OwTluwrQ2tifSK8xUFmd28flUoNv2xz"
    "kDlpR4ZAhkCGRDoFIqB5izT6HJvLK7dvLjPHJiF2FLtLe0FCjPFeC93IvWU4xXR74pKH06lxeL6PTrcLn4eiBDDFhqI8z0weTqf5"
    "idU+slQcLHk2+U4SmXQac3MzmJ+bZbOiJqewtr6BR4+eYOdFhZdfq6GROl/pwCQ+kSCzUMS5UgmLiwX87ScfsfJr+Q2puUtIAIEf"
    "MJDZ5Tky2y84yKyPFGTEKjzfo6olAhkS6dSJgOYt1Enk2Ny+eY13Hk4Ye0pg0SwYfcaQtGT4TnH9beSxEglMTGSxUGQjFXIzOYyP"
    "jcHz9OThUAMCE3JUjg1zbPTkYcPZ4b8rqoeEYzM9NQnX81Cu1LC2/gjf//hQJvvKa7RCSwJqfN+ctbS0WMRnn9xRIGPlIgEJhGGA"
    "dqeL3d09GVpa23iM1Yfr2H8VkNHv+QBRaIlAhkQ6zSKgeYs18hybZQtsTFrhR9cLh5VLo5s45qwma7EcdDKZNBaKeRTyeeRmppEa"
    "5+XeTg++F8S4PwpqgjCE5zLHZk2ATWpcAQiXLIfmi3NdD7u7+6hUa7j73X24rqsdn/1HDy8JgGIgU8C5cyWUFov47JO/wpX3Lhj3"
    "QP8CgpCVX+/t7aNcruL5cYGM0BCgIZAhkCGRXgcR0JBGDjbXeSgqm8lE+tNFH+AmeRwGaNR7IJPOoFCY552H2UgFVhVljjSQVVGh"
    "mhMVBAE8T/WxmZqakH1skLCAJmRJwbVaHZVqHV/f/dEIKdnvxYiChWIB584tcUfmI1y+9K7sH2PeOSAMA3S6PSu09AgPVo8AMqHG"
    "KzZTipsBGPdcvJdDI6mPDIEMifQaiICGJDVysLl2mfexyUTDUFpzPS0apYVc9K3ugphQY49UWFgosJEK4+PweIM+13VZiTYU1IQc"
    "IETejOd7+OqbeywUNTmBdDqtNeJjzovjuLyaqY5vvv1Bm/EUDS2J8uvz55bwu7/5EJcunpfDK/UGfwDgBz467a7qI7P9AhsiR6Z5"
    "EHGOol+X+TOjql7/JrWf6TzDHBnZR+a/YILMGIAzYCCTtH5VbAlkSCTSiYuAhhTRiYDNzeVSNpuWh0om+7swgCpTjv2p9ZTWuwJP"
    "ZDMoFgsoFvKYmZnG2NgYPM9Dt8s7DwMSEPRZUbLc2/Px1TffYX3zMXJTk8hk0gBYR1zHcXnn3zq+vvuD/F2ELHEWIVBcKOJcaQnv"
    "Xijh04/v4ML5JSRFPpAGcayzr8qReVGu4Dkvv159uIH9xoHhsgyaeG3ecfH0VdaLIhDTrhGzlrpO7099QEY4MgQyXAQyJNLpEQEN"
    "qa9OBmxYjk3ctG67Iiph/1xf1IAScZFjUyzkUSjMIzc9hbGxcfi+h27Xgeezcm9R0cRWKDbcaQn4dO/Nx5iamkQ6lYLjuqjW6qhU"
    "6vjq7vfS2dHLrxnIfIR3zy+xa9Bf/LrCIECn08Pu3h7Lkdnewdr6I9xftauWIvO7h0pPTBbH0H4KQObIlLkj859QIDMGBTJnoEBG"
    "hxkbTsyDm+8JZEgk0shEQEMaqpMAm/dvLZeyE1mWpxI5k+bM9HVptHCU9vgxZjgByKTTyBfmUMjnMZNTjk2n21VVUfKCrMZ7YH1s"
    "vv7mHtbWN5FKjaPZbOGXnTK+/e6+MTTyXGkRn31yB+9eKCGZSCKZTMpcGQEzQRCg02GhpRflKusjs/4Y93n5ddygyKPIhBn7roU6"
    "yPypclD/Dyg3xs6RsV0Z80Dmtt/n+pZAhkQiHbsIaEiH1kkkD39w63ppYiKrDj4gETjUyrpZLnF0NpPd+0VAQiaTRiE/j3x+HtPT"
    "U6zc2/fhiOThBGSOi/Ij1IBN3/PxP//7f/jh/kPUd/dw4/pVTE5O4eKFEi5dPI/U+LhcVzKRlBOwk8kkH1HQY+XX0pHR+sgcJaTU"
    "T0aoiS+Ei4eWyl2n9+8cZPSQknBjBMSIl/3d9fu3o58zo78IZEgk0rGLgIZ0ZI0UbC5eXbkpOg9nM0ZoJm7Stjq7CkmZu4YRx0Z3"
    "PtLpNAr5OeTz85jJTWM8NS6nZPu+byTrMjjSpoYHIYIw4KdPSADSxxKo5bHqqF7Pwf5+g/WRESCzuoZG4wAhOKAdO9CwtVgg82eY"
    "4STdibEhRn8/7DvUViC3/UJMBDIkEunYREBDemmdxEiF9zXHRkCB3MmaBdVvNpNx4DCUoRg9JJNOp1DIq3LvdDrF+tj0eqxSSR6A"
    "wYbMubFHN8iNWksQBHJEQbVax85OGeubW3iwuhYpvz4uoNGvTYaW3N7nlWb9z4iWXCfF6bWtDjI25MQBjnF6bdvPldFBJkAUSghk"
    "SCTSkURAQ3pljR5srq58cFs5NpFRBuIAWuWQPIB2cn1/2QHYOlYmk8HCQh4LxQJyuWmkxvl0b4fNipKwEcKoahLjEUToCwkgDEK0"
    "Ox1t1tILbGxuYbXv0Eju7rwq0IQq34c7Mp9XDupfwEzu1W+R/YDXgUZ3bfT3OthA275smOmwQEMgQyKRYkVAQzo2jXpW1M3rzLFh"
    "nYeVC2FkiRj9bMKYRxZiHRr5LgyRSCSRzbKqKL1BnxipEOfY6IuQQyNlQ7wdrG9sYVXrIxN3lRKErHWZi7fuZow8z4sDGeHGiIe6"
    "DgPiJY6sA4weirIThONya8QqBwFNv1DToJATgQyJRBooAhrSseskwOa2BjZ2bo2anm2e0DiQ5tBEnm4hZB5MNpPBQpE7Nnykguf5"
    "6Ok5NhwTfD4cU4LMLzsstCSrlvQ1xtyguHCTBT9hGP+7gOzsK0JLX0DlxgiQEVDg8q0ABP0W2CBjv+JybPTva1jujA5R/YCmH9wQ"
    "yJBIpL4ioCGNTCOf7i0cm4w4D39e9UkgjsuvCXWg0d9oycgJsM7DRTEEU4aifDiOC9f10G63Uecgs61Nv5Y5MgaoqHUYbXeQGBpq"
    "CkPhRKnPfM9Hrz/IiPwUl78c/hJAIx76tjOjJwofBmiMZWrbfiXaw5yaQZ8TyJBIpIgIaEgj18jBZvnKyvu3r5eymbT5Q/0/FqAY"
    "4SptZIHu6+jVSuLk2WzGCEVNTk5ibX0TT54+Y46MGFHAq5aM9VjHB9DXbYleKZTPwn/nCCDT014O/0wHgn5hpmEwYycT2yvu59LE"
    "Ac1RtgQyJBIpIgIa0onpJMDm9q1lljwMRKucYpryxYadNOYwysb5voBybFLjKTzeeoqv736P+w/WojkyWo6NeZZEf5gJtUPogRwO"
    "NJ6sWuoOAhnhxHT5Kw5mhASg2Lky+p+TGOzOxIWcxHaYU9PPuYl7EciQSKRYEdCQTlwnURXFhmCmo3tYfW3iEoulkZJgYSDR2wZQ"
    "ACQ2e3v7+Pn5Nr78+l580g4HGdudGQYz8jAaJrwkyHS1zwTM6ACguzP6Kw5ihsGMdhWRrQ01OtzEgU7cz+MghkCGRCIBIKAh/Yoa"
    "defhG9evsCGYGe08AlKSPAE3tJ+J/ABydwYfYiK23pgvCEJUqjU8e76Nu9/dh9FVWDvQUYBGbwgoDsanXw8LLcWBjO3K2M6MfR/j"
    "+s7YFU12ZdMANJPbuJwaG3LigCduf/uYAIEMiUQCAQ3pFOikwCaTSUt3JikmXIchpwjuzWihJfGp3bQvEFO5wwCVah1bT57h+x8f"
    "xgMNYDTzUxfXb1+1n9UQ72VBRlQJBYh58A+4l4Oa6A2DGeOStG2cszLMeYn7s31sKQIZEuntFQEN6dRo5GCzfGXl1s1rpYlsBolk"
    "kpdJxz3jrfwbfaQB+NM1UECz+tMGNjaemKuUBzqqQxOOCmR0ILDPbkPKIICJgxk7fyZyWTHbo76PO54UgQyJRCKgIZ06jR5sLsuR"
    "CuY0bRiAo/9ZjTZISPcmDEygkbOY9BMKkAlVpk7cwE1gaB+ZVwGZfqABxIPJYbeHVT9XJQ504vaL+zMAAhkSiaREQEM6tRo12Ny8"
    "cXXlg1vRkQqAAhH1mQpJiQMGQYBKtYbVnzaxvrEl99NPKNON9WRfa0W+76PXe6lk3yOBjHj497mv4iL7/XnQzwZpmGszaD+CGBKJ"
    "dGgR0JBOvUbeeVgDG8AMNwUyx0Y9XZPa0MlKhQPN5tbAa4htiCdnLXU/L58AyMTpCHBz1J/rGuQQHWofghgSiTRMBDSk10ajBJvb"
    "l66t3Lx+deX9W9dLGa3cW69qEiEoFjJKIAgZ0DwcAjSCj4Qzow+NLDdrvwrIxGkA3Nh6mX83DgM1hghiSCTSUURAQ3rtNEKwwa2L"
    "137/l7+59XdXL1/6MJvNGBVKIh1GgIko2179aRMbm1scfFTIyfR1Eiy05PR+dNzef2uOjKgi+tVApp+OADivJAIXEol0HCKgIb22"
    "OmawMf63cOf2bz68evnSP125fPHD2JEKYJVOlSpzaNY2thAtIFLl1z3H+bHRbv5zo3uwBgUywCkEGRKJRHodRUBDeu11jGBjOzfh"
    "h7f/4rfnl5b++P6t5VKGj1QQCsIQ1UoND2RSsBlVEaGl/XbzHzjInAULLQHRWUsEMiQSifQKemf4LiTS6ZbTduG0XYxnzg7bdVge"
    "RwSCnpdfPF/d3PhDebvW6PWcG7nc9NTY2Fl5sHani0q1jnp9Tx6EVS31XrS77X/d3q/8Y89z9sFgJsl/TUBMB0ALwAF/tfhnYlyB"
    "PUQyAjJO2x12zSQSifRWiICG9MboGMCm3+eJyn79y9XNjT9UtmvNnuPcmMlNT509exbtdocDza4AmZ12t/Mv2/vlv285nYdg4SVe"
    "8w0PDFYIZEgkEumYRSEn0hurVwhF9ZtXJMHi5rtXV65fu/z7TCZdevjTJl6UK9uu5/7bTqP6RwBjYI5Mv6Tfnvai0BKJRCIdgwho"
    "SG+8RlAVJT+bTU9/FITBO3vd5j0wiLFBBmCQ4oOBiwsFMQQyJBKJdEwioCG9NTomsNH3EdOo34HqJfMOFMyEYKAi3Bn9pU+/JpAh"
    "kUikVxQBDemt0zFXRSWtl1EIBeXO2Nu4ydIACGRIJBLpZURAQ3prdUSw0d8PyrcBFKQEMF0aG2AIZEgkEumYREBDeus1BGzE+0GA"
    "o0uHlX4uDIEMiUQiHbMIaEgkrkOCjf1ZnOIcmEhJOIEMiUQiHZ/+H8V+62DUgM8RAAAAAElFTkSuQmCC")


def _david_image():
    import base64, io
    import pygame
    if _DAVID["img"] is None:
        img = pygame.image.load(io.BytesIO(base64.b64decode(DAVID_PNG)), "david.png")
        try:
            img = img.convert_alpha()
        except Exception:
            pass
        _DAVID["img"] = img
    return _DAVID["img"]


def draw_david(g, ax, ay, size=10):
    """Statue du David sur son piedestal, au centre de l'ilot du rond-point."""
    import pygame
    zoom = g['zoom']
    echelle = (1.35 if size >= 10 else 0.75) * (g['TILE_W'] * zoom / 2 ** 0.5) / DAVID_PX_PAR_CASE
    cle = round(echelle, 4)
    spr = _DAVID["cache"].get(cle)
    if spr is None:
        img = _david_image()
        w = max(1, round(img.get_width() * echelle)); h = max(1, round(img.get_height() * echelle))
        spr = img if (w, h) == img.get_size() else pygame.transform.smoothscale(img, (w, h))
        if len(_DAVID["cache"]) > 12:
            _DAVID["cache"].clear()
        _DAVID["cache"][cle] = spr
    cx, cy = g['grid_to_screen'](ax + size / 2, ay + size / 2)
    x0 = cx - DAVID_ANCRE[0] * echelle; y0 = cy - DAVID_ANCRE[1] * echelle
    ecran = g['ecran']
    if x0 > ecran.get_width() or y0 > ecran.get_height() or x0 + spr.get_width() < 0 or y0 + spr.get_height() < 0:
        return
    ecran.blit(spr, (round(x0), round(y0)))
